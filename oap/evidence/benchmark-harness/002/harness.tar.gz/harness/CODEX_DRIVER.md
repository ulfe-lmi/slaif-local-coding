# Codex execution: native /goal versus automated continuation

The kit supplies native slash-command text in ORCHESTRATOR_GOAL.txt and each
`tasks/*/SLASH_GOAL.txt`. In an interactive Codex session, paste that command.
The objective points to the task files so it stays below the documented 4,000
character goal limit. Native goal support must exist in the selected Codex build.

**A slash command is not a generic executable flag.** This kit does not invent
`codex exec --goal`, and does not send `/goal ...` as ordinary API text while
claiming native goal mode is active.

## Automatic scheduled mode (implemented)

`codex --dangerously-bypass-approvals-and-sandbox exec --json -` starts a subject
inside its isolated Docker container. The driver records `thread.started` and
continues ONLY that ID with `codex ... exec resume --json <ID> -` when the subject
has not declared completion. It sends the same fixed non-adaptive continuation,
up to the frozen continuation/time/observed-token budget. It never uses `--last`
in a shared home, starts a new session to avoid context stress, or relays hidden
judge feedback. All subject homes are fresh and separate.

Before container start, the driver writes a fresh `~/.codex/config.toml` and
copies `config/qwen-neumann-models.json` byte-for-byte into the home. It selects
provider `qwen-LSI-A100`, forces subject reasoning `xhigh`, uses the catalog's
262,144-token context and 222,000-token compaction threshold, and disables apps,
MCP apps and plugins. The only condition/lane-dependent provider field is the
declared DIRECT LAN or loopback-adapter URL. Credentials remain environment
injected and never enter either file.

Two invocations may run concurrently only when one holds lane 2 and one holds
lane 3. Each wave pairs the same condition across lanes. Both `run_case` calls
must return after backend drain before any judge or later wave starts.

This is a reproducible, bounded goal-following wrapper; it is **not** evidence
that native persistent-goal state was created. Do not compare some native-goal
runs with some wrapper runs in one cell. If native goals are scientifically
required, qualify a native driver separately before freezing; the supplied
automatic runner deliberately rejects other modes instead of pretending.

## What stops an application run

A valid `SUBMISSION.json` with `complete:true` is a subject completion claim.
The subject must continue coding/testing until its contract is satisfied; a
false claim will fail the independent judge. A normal turn without a submission
receives the fixed continuation. Nonzero Codex exit, timeout, token threshold,
missing session identity or a genuine infrastructure error ends/reconciles the
attempt. There is no hidden-judge repair loop.

For the context task the controller sends all frozen pressure phases in the
same session and the final fact query, irrespective of early submission files.
Formal frozen runs enforce their configured hard wall and check the token
threshold at observable turn boundaries. The current qualification site carries
an explicit human-authorized override disabling both stop causes; submission,
terminal subject/protocol/infrastructure states and fixed context phases still
terminate work. Backend token totals
include internal compiler requests and are reconciled after quiescence.

## Required installed-client checks

The reference product fixtures used Codex 0.149.0, but that is not a guarantee
for every binary/provider combination. Record actual `codex --version`,
`codex exec --help`, `codex exec resume --help`, provider settings, CLI flags,
Responses function-call continuation, image-view event shape and compaction
rollout shape. Do not upgrade a working client merely because a web doc is newer.
The worker image is built separately once and frozen by its Docker image ID.

Calibrate whether turn usage is a delta or session cumulative before choosing
`measurement.client_usage_semantics`. Output absence is unknown, not zero.
Native raw rollout files remain private; do not include credentials/auth files
in an exported evidence bundle. The installed version's native rollouts are
needed when exec JSON does not expose image/compaction events.

## Goal text

The task `/goal` contents are ready for interactive use; GOAL.md is also included
in the automatic driver's first prompt. The headless continuation text is fixed
in runner.py. Changes to any of these after pilot calibration create a new
protocol/freeze, not an invisible operational tweak.
