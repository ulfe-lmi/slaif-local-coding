# Benchmark system architecture — paired GPU2/GPU3 lanes

## Physical topology

```text
PHYSICAL GPU HOST 192.0.2.195
  protected DP2 service -> GPUs 0-1 -> port 8000 (out of scope)
  benchmark vLLM replica -> GPU2 A100-SXM4-80GB -> LAN:18042
  benchmark vLLM replica -> GPU3 A100-SXM4-80GB -> LAN:18043
  existing read-only recorder -> GPU2/GPU3 + both metrics endpoints
  |
  +-- TESTING VM 192.0.2.112
       controller Codex (separate model, never ports 18042/18043)
       at most one fresh subject container per measured lane
       optional adapters -> VM 127.0.0.1:18142 and :18143
       adapter upstreams -> corresponding host-LAN endpoint
       subject web apps -> VM 127.0.0.1:18242 and :18243
       evaluators only after BOTH subjects stop and BOTH backends drain
```

There are two measured lanes, numbered 2 and 3 to match their physical GPUs.
Lane 2 uses port 18042 and lane 3 uses port 18043. Exact GPU UUIDs are mandatory
site facts before inference. Port 8000 and GPUs 0-1 are never benchmark lanes.
No tunnel, vsock, port forwarding, loopback remapping or Gateway is in the path.

## Paired-wave blocked design

Each physical-lane block contains DIRECT, VISION, CACHE and BOTH exactly once.
GPU2 and GPU3 use the same randomized Williams condition order for a paired
block but distinct task seeds. At each sequence position the same condition
starts concurrently on both GPUs. Condition position and directed predecessor
transitions are balanced independently on each lane in every four-block cycle.

Every run receives a fresh workspace, Codex home, browser, adapter, adapter
tmpfs cache and unique session identity. The dispatcher holds a separate lane
lease for each run and a global dispatcher lease for the wave. Both run results
are preserved even if one lane fails. No next wave starts after broken
measurement, protocol violation or shared-infrastructure evidence.

The judge barrier is global: evaluators start only after both subjects have
stopped and both endpoint running/waiting gauges have drained to zero. Judges
remain model-free and never feed hidden results back to a subject.

## Data and control planes

Control: human -> controller -> Python dispatcher -> two isolated subject Codex
containers. Data: each DIRECT subject -> its host-LAN vLLM endpoint; each
adapter subject -> its unique VM-loopback adapter -> the same assigned endpoint.
Measurement: native Codex events, per-lane VM metric snapshots and synchronized
host recorder session. Judging: frozen evaluators after the global barrier.

## Identity and isolation

The immutable product OCI digest, source commit and wheel label are checked.
Experiment TOML is generated separately and hashed. Every worker receives the
same verbatim `qwen-neumann-models.json`, mandatory `xhigh` reasoning, 262,144
context, 222,000 automatic compaction threshold, and disabled apps/MCP apps/
plugins. Only provider URL and per-run identity vary as declared.

Subjects are non-root, capability-dropped containers with only fresh `/work`
and home mounts. They receive no Docker socket, controller, evaluators, answer
keys, other attempts or host credential file. The backend key is injected into
the worker environment for DIRECT or adapter environment for adapter arms. It
never enters `/work` or Git.

Host networking is used so subjects can reach their VM-loopback adapter/app
ports. It is not hostile-workload network isolation; only synthetic cooperative
qualification and benchmark tasks are in scope.

## Shared-host limitation

GPU2 and GPU3 share CPU, RAM, PCIe, storage and network with the protected GPU0-1
DP2 service. Synchronized recorder session `qualification-gpu23-01` is required
through qualification. Shared activity is recorded and disclosed as a possible
contamination covariate; two endpoints do not prove zero interference.

Qualification itself runs in paired waves. It demonstrates actual concurrent
Codex/tool/image/adapter/metrics/drain/isolation behavior without a separate
synthetic serial-versus-parallel campaign. Formal execution still requires a
new freeze, paired schedule and exact human stage approval.

## Lifecycle

`DRAFT -> INVENTORIED -> QUALIFYING -> QUALIFIED -> FROZEN ->`
`HUMAN_STAGE_APPROVED -> PREPARED -> WAVE_RUNNING -> BOTH_LANES_DRAINED ->`
`GRADED -> RECONCILED -> next approved wave OR STAGE_COMPLETE`.

Any measurement or infrastructure problem enters reconciliation. There is no
automatic retry; a permitted infrastructure retry needs a new attempt ID and
explicit linkage to the preserved original.

## Components

- `schedule.py`: Williams orders per lane and identical-condition paired waves.
- `configurations.py`: four treatment configurations and per-lane endpoints.
- `runner.py`: fresh state, two-worker dispatch, global drain/judge barrier.
- `metrics.py`: allowlisted Prometheus snapshots/deltas and reset detection.
- `host_lanes.py`: read-only GPU2/GPU3 attachment validation.
- `recorder.py`: GPU discovery and host/vLLM sampling; not started from the VM.
- `evaluators/`: independent browser, PTY and context judges.
- `analysis.py`: lane-stratified outcomes, paired effects and order fields.

## Non-goals

No product modification, Gateway evaluation, host-service management, vLLM or
GPU-stack installation, cache reset, model tuning, port 8000 use, claim of
four-lane balance, more than two concurrent subjects, or automatic formal-stage
promotion.
