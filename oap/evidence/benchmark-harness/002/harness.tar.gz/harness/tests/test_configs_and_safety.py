import copy,json,os,sys,tomllib
from pathlib import Path
import pytest
from benchkit.common import read_env,atomic_json,validate_site,redact,lease
from benchkit.configurations import adapter_toml,subject_config
from benchkit.host_lanes import validate
from benchkit.preflight import capability_probes
@pytest.mark.parametrize('lane_id', [2,3])
@pytest.mark.parametrize('condition', ['DIRECT','VISION','CACHE','BOTH'])
def test_feature_configs(site,condition,lane_id):
    c={'condition':condition,'lane':lane_id,'run_id':'test-001','task':'web'}
    text=adapter_toml(site,c)
    if condition=='DIRECT':assert text is None;return
    d=tomllib.loads(text);cache=condition in ('CACHE','BOTH');vision=condition in ('VISION','BOTH')
    assert d['gateway_ingress']['mode']=='disabled'
    assert d['server']['listen_host']=='127.0.0.1'
    lane=next(x for x in site['lanes'] if x['lane']==lane_id)
    assert d['upstream']['base_url']==lane['backend_url']
    assert d['compiler']['enabled']==cache
    assert d['constitution']['enabled']==cache
    assert d['constitution']['identity_source']=='static'
    assert d['routes'][0]['constitution_enabled']==cache
    assert d['routes'][0]['responses_tool_policy']=='passthrough'
    assert d['routes'][0]['image_overflow_policy']==('retain_newest' if vision else 'passthrough')
    assert ('max_images_per_request' in d['routes'][0])==vision
    if cache:assert d['constitution']['session']=='test-001'
    assert 'SLAIF_ADAPTER_SIGNING_SECRET' not in text
@pytest.mark.parametrize('lane_id', [2,3])
@pytest.mark.parametrize('condition', ['DIRECT','VISION','CACHE','BOTH'])
def test_codex_endpoint_only_variation(site,condition,lane_id):
    c={'condition':condition,'lane':lane_id,'run_id':'x','task':'web'}
    d=tomllib.loads(subject_config(site,c))
    lane=next(x for x in site['lanes'] if x['lane']==lane_id)
    expected=lane['backend_url'] if condition=='DIRECT' else f"http://127.0.0.1:{lane['adapter_port']}/v1"
    assert d['model_provider']=='qwen-LSI-A100'
    assert d['model_providers']['qwen-LSI-A100']['base_url']==expected
    assert d['model_providers']['qwen-LSI-A100']['wire_api']=='responses'
    assert d['model_providers']['qwen-LSI-A100']['env_key']=='BENCH_API_KEY'
    assert not d['model_providers']['qwen-LSI-A100']['requires_openai_auth']
    assert d['web_search']=='disabled'
    assert d['model_catalog_json']=='~/.codex/qwen-neumann-models.json'
    assert d['model_reasoning_effort']=='xhigh'
    assert d['model_auto_compact_token_limit']==222000
    assert d['features']=={'apps':False,'enable_mcp_apps':False,'plugins':False}
def test_site_good(site):validate_site(site)
@pytest.mark.parametrize('bad', ['placeholder','loopback','missing_lane','parallelism','duplicate_port','duplicate_gpu','wrong_endpoint','protected_port','unsafe_worker','userinfo','reasoning','override'])
def test_bad_site(site,bad):
    if bad=='placeholder':site['vllm_version']='CHANGE_ME'
    if bad=='loopback':site['host_lan_ip']='127.0.0.1'
    if bad=='missing_lane':site['lanes'].pop()
    if bad=='parallelism':site['max_parallel']=1
    if bad=='duplicate_port':site['lanes'][0]['adapter_port']=site['lanes'][0]['app_port']
    if bad=='duplicate_gpu':site['lanes'][1]['gpu_uuid']=site['lanes'][0]['gpu_uuid']
    if bad=='wrong_endpoint':site['lanes'][0]['backend_url']='http://192.0.2.20:18043/v1'
    if bad=='protected_port':site['lanes'][0]['backend_url']='http://192.0.2.20:8000/v1'
    if bad=='unsafe_worker':site['subject_worker_image']='worker:latest'
    if bad=='userinfo':site['lanes'][0]['backend_url']='http://user:secret@192.0.2.20:18042/v1'
    if bad=='reasoning':site['codex']['reasoning_effort']='medium'
    if bad=='override':site['codex']['additional_config']={'model_reasoning_effort':'low'}
    with pytest.raises(ValueError):validate_site(site)
def test_private_env(tmp_path):
    f=tmp_path/'x';f.write_text('TOKEN=abc\n');f.chmod(0o600)
    assert read_env(f)=={'TOKEN':'abc'}
    f.chmod(0o644)
    with pytest.raises(ValueError):read_env(f)
def test_env_no_shell_evaluation(tmp_path):
    f=tmp_path/'x';f.write_text('TOKEN=$(whoami)\n');f.chmod(0o600)
    assert read_env(f)['TOKEN']=='$(whoami)'
@pytest.mark.parametrize('text', ['TOKEN=\n','TOKEN=REPLACE_SECRET\n','TOKEN=a\nTOKEN=b\n','export TOKEN=a\n'])
def test_invalid_env(tmp_path,text):
    f=tmp_path/'x';f.write_text(text);f.chmod(0o600)
    with pytest.raises(ValueError):read_env(f)
def test_secret_redaction():assert redact('longsecret / secret',{'a':'secret','b':'longsecret'})=='[REDACTED] / [REDACTED]'
def test_atomic_no_overwrite(tmp_path):
    f=tmp_path/'x.json';atomic_json(f,{'a':1})
    with pytest.raises(FileExistsError):atomic_json(f,{'b':2})
    assert json.loads(f.read_text())=={'a':1}
    assert f.stat().st_mode&0o777==0o600
def test_lease_exclusion(tmp_path):
    f=tmp_path/'lock'
    with lease(f):
        with pytest.raises(RuntimeError):
            with lease(f):pass
def hostconfig():
    return {'mode':'attach','bind_ip':'192.0.2.20','lanes':[{'lane':2,'gpu_uuid':'GPU-20000000-0000-0000-0000-000000000002','port':18042},
            {'lane':3,'gpu_uuid':'GPU-30000000-0000-0000-0000-000000000003','port':18043}],
            'common_argv':['/ABSOLUTE/EXISTING/vllm'],'state_dir':'/ABSOLUTE/STATE'}
def test_attach_needs_no_executable():assert validate(hostconfig())==[]

def test_capability_probe_uses_valid_responses_image_detail(site,monkeypatch):
    env=Path(site['secret_env_file']);env.write_text('BENCH_BACKEND_API_KEY=test-only\n');env.chmod(0o600)
    payloads=[]
    def fake_request(url,key,body=None,timeout=60):
        payloads.append(body);return {'ok':True}
    monkeypatch.setattr('benchkit.preflight.request',fake_request)
    capability_probes(site)
    image_payloads=[p for p in payloads if isinstance(p,dict) and isinstance(p.get('input'),list)]
    assert len(image_payloads)==4
    for payload in image_payloads:
        images=[x for x in payload['input'][0]['content'] if x['type']=='input_image']
        assert images and all(x['detail']=='auto' for x in images)
        assert payload['max_output_tokens']==256
        assert payload['reasoning']=={'effort':'xhigh'}

def test_capability_probes_pair_each_probe_across_lanes(site,monkeypatch):
    import threading
    env=Path(site['secret_env_file']);env.write_text('BENCH_BACKEND_API_KEY=test-only\n');env.chmod(0o600)
    barrier=threading.Barrier(2);calls=[];lock=threading.Lock()
    def fake_request(url,key,body=None,timeout=60):
        barrier.wait(timeout=2)
        with lock:calls.append((url,body))
        return {'ok':True}
    monkeypatch.setattr('benchkit.preflight.request',fake_request)
    result=capability_probes(site)
    assert result['execution']=='paired_same_probe_on_gpu2_gpu3'
    assert len(calls)==8 and {x['lane'] for x in result['lanes']}=={2,3}

def test_launch_is_rejected_for_protected_existing_service(tmp_path):
    c=hostconfig();c.update(mode='launch',state_dir=str(tmp_path),common_argv=[sys.executable,'-m','vllm','--port','{port}',
        '--host','{bind_ip}','--tensor-parallel-size','1','--limit-mm-per-prompt','{"image":1}'])
    with pytest.raises(ValueError):validate(c)

def test_model_catalog_is_frozen_and_matches_site(site):
    import hashlib
    from benchkit.common import MODEL_CATALOG_SHA256
    source=Path(__file__).parents[1]/'config'/'qwen-neumann-models.json'
    assert hashlib.sha256(source.read_bytes()).hexdigest()==MODEL_CATALOG_SHA256
    catalog=json.loads(source.read_text());model=catalog['models'][0]
    assert model['slug']==site['served_model']
    assert model['default_reasoning_level']=='xhigh'
    assert {x['effort'] for x in model['supported_reasoning_levels']}=={'low','medium','xhigh'}
    assert model['context_window']==model['max_context_window']==site['context_window_tokens']==262144
    assert model['auto_compact_token_limit']==site['codex']['model_auto_compact_token_limit']==222000

def test_prepare_case_installs_model_catalog(site,tmp_path,monkeypatch):
    from benchkit.runner import prepare_case
    site['workspace_root']=str(tmp_path);monkeypatch.setattr('benchkit.runner.set_owner',lambda *args: None)
    case={'condition':'DIRECT','lane':2,'run_id':'catalog-copy-001','task':'terminal','task_seed':7}
    root=prepare_case(site,case);installed=root/'home'/'.codex'/'qwen-neumann-models.json'
    source=Path(__file__).parents[1]/'config'/'qwen-neumann-models.json'
    assert installed.read_bytes()==source.read_bytes() and installed.stat().st_mode&0o777==0o600
    assert set(json.loads((root/'codex_input_hashes.json').read_text()))=={'config.toml','qwen-neumann-models.json'}

def test_codex_trust_self_registration_is_the_only_allowed_config_change(site,tmp_path,monkeypatch):
    from benchkit.runner import prepare_case,codex_input_changes
    site['workspace_root']=str(tmp_path);monkeypatch.setattr('benchkit.runner.set_owner',lambda *args: None)
    case={'condition':'DIRECT','lane':2,'run_id':'trust-entry-001','task':'terminal','task_seed':7}
    root=prepare_case(site,case);config=root/'home'/'.codex'/'config.toml'
    assert codex_input_changes(site,case,root/'home')==[]
    config.write_text(config.read_text()+'\n[projects."/work"]\ntrust_level = "trusted"\n')
    assert codex_input_changes(site,case,root/'home')==[]
    config.write_text(config.read_text().replace('model_reasoning_effort = "xhigh"','model_reasoning_effort = "low"'))
    assert codex_input_changes(site,case,root/'home')==['config.toml']
