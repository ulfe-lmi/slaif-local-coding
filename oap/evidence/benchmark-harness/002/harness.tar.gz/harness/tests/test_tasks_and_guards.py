import copy,datetime as dt,json,os,subprocess,sys
from pathlib import Path
import pytest
from benchkit.common import ROOT,atomic_json,object_hash,sha256
from benchkit.cli import authorize
from benchkit.runner import capture_container_logs,stream_exec,pressure_prompt,execution_bounds
from benchkit.schedule import make_schedule
from oracle import Board
from context_judge import score

def test_oracle_flood_win():
    b=Board(3,3,[[0,0]]);b.reveal((2,2));assert b.status=='won' and len(b.revealed)==8

def test_oracle_flag_blocks_and_loss():
    b=Board(3,3,[[0,0]]);b.flag((0,0));b.reveal((0,0));assert b.status=='ready'
    b.flag((0,0));b.reveal((0,0));assert b.status=='lost';old=b.expected();b.reveal((2,2));assert b.expected()==old

def test_context_judge_controls():
    key=json.loads((ROOT/'evaluators/context_answer_key.json').read_text())
    assert score(copy.deepcopy(key),key)['functional_success']
    bad=copy.deepcopy(key);bad['facts'][0]['value']='WRONG';assert not score(bad,key)['functional_success']
    bad=copy.deepcopy(key);bad['facts'].append(bad['facts'][0]);assert not score(bad,key)['functional_success']
    assert score({},key)['facts_correct_with_source']==0

def test_subject_no_judges_or_solutions():
    for t in ('web','terminal','context'):
        d=ROOT/'tasks'/t
        for f in ('AGENTS.md','ARCHITECTURE.md','PROMPT.md','GOAL.md','SLASH_GOAL.txt'):assert (d/f).is_file()
        assert not any(p.suffix=='.py' for p in d.rglob('*'))
        assert len((d/'SLASH_GOAL.txt').read_text())<4000
    assert 'Playwright' in (ROOT/'tasks/web/ARCHITECTURE.md').read_text()
    assert 'Do not use Playwright' in (ROOT/'tasks/terminal/AGENTS.md').read_text()

def test_judge_controls_use_invoking_uid_gid():
    text=(ROOT/'scripts/judge_controls.py').read_text()
    assert "'--user',f'{os.getuid()}:{os.getgid()}'" in text

def test_judge_controls_run_as_vm_operator_not_remapped_container_root():
    text=(ROOT/'scripts/judge_controls.py').read_text()
    assert "'--user',f'{os.getuid()}:{os.getgid()}'" in text

def test_permission_preparation_is_scoped_to_explicit_run_prefix():
    text=(ROOT/'scripts/prepare_permissions.py').read_text()
    assert "p.add_argument('--run-prefix',required=True)" in text
    assert "d.name.startswith(a.run_prefix)" in text

def test_pressure_deterministic(site):
    c={'task_seed':1};a=pressure_prompt(site,c,1)
    assert a==pressure_prompt(site,c,1) and a!=pressure_prompt(site,c,2)
    assert len(a)>=site['context_task']['bytes_per_phase']

def test_human_qualification_override_disables_time_and_token_stops(site):
    site['qualification']['disable_time_token_stops']=True
    deadline,tokens=execution_bounds(site,'context',100.0)
    assert deadline==float('inf') and tokens is None
    site['qualification']['disable_time_token_stops']=False
    deadline,tokens=execution_bounds(site,'context',100.0)
    assert deadline==100.0+site['limits']['context_wall_seconds']
    assert tokens==site['limits']['max_observed_client_tokens']

def test_approval_binds_stage_and_schedule(tmp_path):
    f=tmp_path/'freeze.json';atomic_json(f,{'x':1});s={'stage':'pilot'}
    a={'schema':'slaif-stage-approval-v3-dual-lane','reviewed_by_human':True,'freeze_sha256':sha256(f),'schedule_sha256':object_hash(s),
       'stage':'pilot','allowed_wave_ids':['wave1'],'parallelism':2,
       'not_after':(dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=1)).isoformat()}
    p=tmp_path/'approval.json';atomic_json(p,a)
    authorize(p,f,s,'wave1',2)
    for altered,w,parallel in [({'stage':'main'},'wave1',2),(s,'wave2',2),(s,'wave1',1)]:
        with pytest.raises(ValueError):authorize(p,f,altered,w,parallel)

def test_expired_approval(tmp_path):
    f=tmp_path/'f';atomic_json(f,{});s={'stage':'main'}
    p=tmp_path/'a';atomic_json(p,{'schema':'slaif-stage-approval-v3-dual-lane','reviewed_by_human':True,'freeze_sha256':sha256(f),'schedule_sha256':object_hash(s),
      'stage':'main','allowed_wave_ids':['w'],'parallelism':2,'not_after':'2000-01-01T00:00:00+00:00'})
    with pytest.raises(ValueError):authorize(p,f,s,'w',2)

def test_stream_exec_real_subprocess_and_redaction(tmp_path):
    import time
    code='import json; print(json.dumps({"type":"thread.started","thread_id":"t1"})); print(json.dumps({"type":"message","text":"SECRET42"}))'
    o=tmp_path/'e';e=tmp_path/'stderr'
    r=stream_exec([sys.executable,'-c',code],'',o,e,time.monotonic()+5,{'key':'SECRET42'},10000)
    assert r['returncode']==0 and r['thread_id']=='t1' and not r['timeout']
    assert 'SECRET42' not in o.read_text() and '[REDACTED]' in o.read_text()

def test_stream_exec_deadline(tmp_path):
    import time
    r=stream_exec([sys.executable,'-c','import time; time.sleep(30)'],'',tmp_path/'e',tmp_path/'err',time.monotonic()+.1,{},1000)
    assert r['timeout']

def test_adapter_log_capture_is_private_bounded_and_redacted(tmp_path,monkeypatch):
    class Result:
        returncode=0;stdout='prefix SECRET42 '+('x'*200);stderr='suffix SECRET42'
    monkeypatch.setattr(subprocess,'run',lambda *a,**k:Result())
    path=tmp_path/'adapter.private.log'
    result=capture_container_logs('owned',path,{'key':'SECRET42'},64)
    assert result['truncated'] and result['bytes']==64
    assert 'SECRET42' not in path.read_text() and path.stat().st_mode&0o777==0o600

def test_schedule_cli(tmp_path):
    out=tmp_path/'s.json'
    p=subprocess.run([sys.executable,str(ROOT/'scripts/bench.py'),'schedule','--tasks','web,terminal','--blocks-per-lane','4','--out',str(out)],capture_output=True,text=True)
    schedule=json.loads(out.read_text())
    assert p.returncode==0 and schedule['logical_runs']==64 and schedule['max_parallel']==2

def test_inference_cli_requires_execute(site,tmp_path):
    f=tmp_path/'site';atomic_json(f,site)
    p=subprocess.run([sys.executable,str(ROOT/'scripts/bench.py'),'probe','--site',str(f),'--out',str(tmp_path/'p')],capture_output=True,text=True)
    assert p.returncode!=0 and '--execute required' in p.stderr
    assert not (tmp_path/'p').exists()

def test_wave_dispatch_is_concurrent_and_judges_after_both_drains(site,tmp_path,monkeypatch):
    import benchkit.runner as runner
    import threading
    site['workspace_root']=str(tmp_path)
    schedule=make_schedule(['web'],4,7,'pilot');run_map={r['run_id']:r for b in schedule['blocks'] for r in b['runs']}
    recorded=schedule['waves'][0];cases=[run_map[x] for x in recorded['run_ids']]
    wave={**recorded,'runs':cases};events=[];guard=threading.Lock();barrier=threading.Barrier(2)
    for case in cases:
        root=tmp_path/case['run_id'];root.mkdir();atomic_json(root/'case.json',case)
    def fake_run(_site,case,_root):
        with guard:events.append(('run_start',case['lane']))
        barrier.wait(timeout=2)
        with guard:events.append(('run_end',case['lane']))
        return {'measurement_valid':True,'case':case,'status':'SUBMITTED'}
    def fake_judge(_site,case,_root):events.append(('judge',case['lane']))
    monkeypatch.setattr(runner,'run_case',fake_run);monkeypatch.setattr(runner,'judge_case',fake_judge)
    results=runner.run_wave(site,wave,prepared=True)
    assert len(results)==2 and {x['case']['lane'] for x in results}=={2,3}
    first_judge=next(i for i,x in enumerate(events) if x[0]=='judge')
    assert {x for x in events[:first_judge] if x[0]=='run_end'}=={('run_end',2),('run_end',3)}

def test_wave_preserves_both_results_when_one_measurement_breaks(site,tmp_path,monkeypatch):
    import benchkit.runner as runner
    site['workspace_root']=str(tmp_path)
    schedule=make_schedule(['web'],4,8,'pilot');run_map={r['run_id']:r for b in schedule['blocks'] for r in b['runs']}
    recorded=schedule['waves'][0];cases=[run_map[x] for x in recorded['run_ids']];wave={**recorded,'runs':cases}
    for case in cases:
        root=tmp_path/case['run_id'];root.mkdir();atomic_json(root/'case.json',case)
    called=[]
    def fake_run(_site,case,_root):
        called.append(case['lane'])
        return {'measurement_valid':case['lane']==2,'case':case,'status':'SUBMITTED' if case['lane']==2 else 'INFRASTRUCTURE_ERROR'}
    monkeypatch.setattr(runner,'run_case',fake_run);monkeypatch.setattr(runner,'judge_case',lambda *_:None)
    results=runner.run_wave(site,wave,prepared=True)
    assert len(results)==2 and set(called)=={2,3}
    assert [x['measurement_valid'] for x in results]==[True,False]

def test_mixed_case_wave_requires_explicit_qualification_flag(site,tmp_path,monkeypatch):
    import benchkit.runner as runner
    site['workspace_root']=str(tmp_path)
    cases=[{'run_id':'mixed-l2','lane':2,'condition':'VISION','task':'web'},
           {'run_id':'mixed-l3','lane':3,'condition':'DIRECT','task':'terminal'}]
    for case in cases:
        root=tmp_path/case['run_id'];root.mkdir();atomic_json(root/'case.json',case)
    wave={'wave_id':'mixed','execution':'concurrent','max_parallel':2,'qualification_mixed_cases':True,'runs':cases}
    with pytest.raises(ValueError):runner.run_wave(site,wave,prepared=True)
    site['qualification']['allow_mixed_case_waves']=True
    monkeypatch.setattr(runner,'run_case',lambda _s,c,_r:{'measurement_valid':True,'case':c,'status':'SUBMITTED'})
    monkeypatch.setattr(runner,'judge_case',lambda *_:None)
    assert len(runner.run_wave(site,wave,prepared=True))==2
