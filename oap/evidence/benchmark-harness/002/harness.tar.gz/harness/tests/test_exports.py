import json,subprocess,sys
from pathlib import Path
from benchkit.common import ROOT,atomic_json
from benchkit.analysis import analyze

def make_result(root,run_id='main-web-l2-b01',condition='BOTH',block=1,lane=2):
    d=root/run_id;d.mkdir(parents=True)
    atomic_json(d/'result.json',{'case':{'run_id':run_id,'task':'web','condition':condition,'block':block,'lane':lane},
      'status':'SUBMITTED','measurement_valid':True,'measurement_start_ns':1000000000,
      'coding_wall_seconds':4,'backend_deltas':{
        'vllm:prompt_tokens_total':{'status':'ok','value':10},
        'vllm:generation_tokens_total':{'status':'ok','value':5},
        'vllm:request_success_total':{'status':'ok','value':2}}})
    atomic_json(d/'judge.json',{'status':'SCORED','functional_success':True})
    return d

def test_analysis_reports_completed_not_attempted_requests(tmp_path):
    runs=tmp_path/'runs';make_result(runs)
    report=analyze(runs,tmp_path/'out')
    assert report['groups'][0]['all_attempts']['backend_completed_requests']['mean']==2
    assert report['groups'][0]['all_attempts']['backend_gross_tokens']['mean']==15

def test_duplicate_cell_attempts_refused(tmp_path):
    import pytest
    runs=tmp_path/'runs';make_result(runs);make_result(runs,'main-web-b01-l0-attempt2')
    with pytest.raises(ValueError,match='Multiple attempts'):analyze(runs,tmp_path/'out')

def test_visual_merge_and_joint_success(tmp_path):
    runs=tmp_path/'runs';d=make_result(runs);mapping=tmp_path/'mapping.json'
    atomic_json(mapping,[{'case':'anonymous','run_id':d.name}]);ratings=tmp_path/'ratings'
    for name in ('rater1','rater2'):
        atomic_json(ratings/name/'rating.json',{'case':'anonymous','rater':name,'scores':[3,3,3,3,3]})
    cmd=[sys.executable,str(ROOT/'scripts/merge_visual_ratings.py'),'--runs',str(runs),'--mapping',str(mapping),'--ratings',str(ratings)]
    p=subprocess.run(cmd,capture_output=True,text=True);assert p.returncode==0,p.stderr
    assert json.loads((d/'visual-rating.json').read_text())['visual_score']==15
    analyze(runs,tmp_path/'out')
    assert 'True' in (tmp_path/'out/runs.csv').read_text()
    assert subprocess.run(cmd,capture_output=True).returncode!=0

def test_timeline_no_raw_payload(tmp_path):
    d=make_result(tmp_path/'runs');atomic_json(d/'metrics-before.json',{'series':{'vllm:prompt_tokens_total':10,'vllm:generation_tokens_total':2}})
    (d/'metrics.jsonl').write_text(json.dumps({'unix_ns':2000000000,'backend':{'series':{'vllm:prompt_tokens_total':20,'vllm:generation_tokens_total':7}}})+'\n')
    (d/'events-000.jsonl').write_text(json.dumps({'unix_ns':1500000000,'event':{'type':'item.completed','item':{'type':'command_execution','text':'RAW_PRIVATE_PAYLOAD'}}})+'\n')
    out=tmp_path/'timeline';p=subprocess.run([sys.executable,str(ROOT/'scripts/timeline.py'),'--run',str(d),'--out',str(out)],capture_output=True,text=True)
    assert p.returncode==0,p.stderr
    assert '15.0' in (out/'backend_timeline.csv').read_text() or ',15,' in (out/'backend_timeline.csv').read_text()
    assert 'RAW_PRIVATE_PAYLOAD' not in (out/'client_events.csv').read_text()
