import copy
import pytest
from benchkit.common import object_hash
from benchkit.qualification_plan import validate_plan


def plan(site):
    return {'schema':'slaif-mixed-qualification-plan-v1','site_sha256':object_hash(site),'waves':[
        {'wave_id':'q-w01','runs':[
            {'run_id':'q-w01-l2','lane':2,'task':'web','condition':'VISION','block':0,'task_seed':1,'sequence_position':1,'previous_condition':None},
            {'run_id':'q-w01-l3','lane':3,'task':'terminal','condition':'DIRECT','block':0,'task_seed':2,'sequence_position':1,'previous_condition':None}]}]}


def test_mixed_qualification_plan(site):validate_plan(site,plan(site))


@pytest.mark.parametrize('mutation',['same_task','same_lane','duplicate_run','wrong_site'])
def test_mixed_qualification_plan_fails_closed(site,mutation):
    p=copy.deepcopy(plan(site))
    if mutation=='same_task':p['waves'][0]['runs'][1]['task']='web'
    if mutation=='same_lane':p['waves'][0]['runs'][1]['lane']=2
    if mutation=='duplicate_run':p['waves'][0]['runs'][1]['run_id']=p['waves'][0]['runs'][0]['run_id']
    if mutation=='wrong_site':p['site_sha256']='0'*64
    with pytest.raises(ValueError):validate_plan(site,p)
