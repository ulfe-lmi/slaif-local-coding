from collections import Counter
import copy
import pytest
from benchkit.schedule import make_schedule,validate_schedule
from benchkit.common import CONDITIONS


@pytest.mark.parametrize('tasks', [['web','terminal'],['web','terminal','context']])
@pytest.mark.parametrize('blocks_per_lane', [4,12,16])
def test_balance(tasks,blocks_per_lane):
    s=make_schedule(tasks,blocks_per_lane,11,'main')
    assert s['logical_runs']==8*len(tasks)*blocks_per_lane
    assert len(s['blocks'])==2*len(tasks)*blocks_per_lane
    assert len(s['waves'])==4*len(tasks)*blocks_per_lane
    ids=set();counts=Counter();run_map={}
    for block in s['blocks']:
        assert block['lane'] in (2,3)
        assert {r['condition'] for r in block['runs']}==set(CONDITIONS)
        assert {r['lane'] for r in block['runs']}=={block['lane']}
        assert [r['condition'] for r in block['runs']]==block['condition_order']
        assert [r['sequence_position'] for r in block['runs']]==[1,2,3,4]
        assert [r['previous_condition'] for r in block['runs']]==[None,*block['condition_order'][:-1]]
        assert len({r['task_seed'] for r in block['runs']})==1
        for run in block['runs']:
            assert run['run_id'] not in ids;ids.add(run['run_id']);run_map[run['run_id']]=run
            counts[run['task'],run['lane'],run['condition']]+=1
    assert set(counts.values())=={blocks_per_lane}
    for task in tasks:
        for lane in (2,3):
            lane_blocks=[b for b in s['blocks'] if b['task']==task and b['lane']==lane]
            for cycle in range(blocks_per_lane//4):
                group=lane_blocks[cycle*4:(cycle+1)*4]
                for position in range(4): assert {b['condition_order'][position] for b in group}==set(CONDITIONS)
                transitions=[(a,b) for block in group for a,b in zip(block['condition_order'],block['condition_order'][1:])]
                assert len(transitions)==12 and len(set(transitions))==12
    wave_runs=[]
    for wave in s['waves']:
        runs=[run_map[x] for x in wave['run_ids']];wave_runs.extend(wave['run_ids'])
        assert {r['lane'] for r in runs}=={2,3}
        assert len({r['condition'] for r in runs})==1
        assert len({r['task'] for r in runs})==1
        assert wave['max_parallel']==2 and wave['execution']=='concurrent'
    assert len(wave_runs)==len(set(wave_runs))==s['logical_runs']


def test_reproducible():
    assert make_schedule(['web'],4,10,'pilot')==make_schedule(['web'],4,10,'pilot')
    assert make_schedule(['web'],4,10,'pilot')!=make_schedule(['web'],4,11,'pilot')
    assert make_schedule(['web'],4,10,'pilot')['max_parallel']==2


@pytest.mark.parametrize('blocks', [0,-4,1,3,10,15])
def test_reject_unbalanced(blocks):
    with pytest.raises(ValueError):make_schedule(['web'],blocks,1,'main')


@pytest.mark.parametrize('mutation', ['parallel','lane','order','carryover','duplicate','cross_condition','missing_wave','duplicate_wave_run','pair_seed'])
def test_reject_malformed_dual_lane_schedule(mutation):
    schedule=make_schedule(['web'],4,11,'main');bad=copy.deepcopy(schedule)
    if mutation=='parallel':bad['max_parallel']=1
    if mutation=='lane':bad['blocks'][0]['runs'][0]['lane']=3
    if mutation=='order':bad['blocks'][0]['condition_order'].reverse()
    if mutation=='carryover':bad['blocks'][0]['runs'][1]['previous_condition']=None
    if mutation=='duplicate':bad['blocks'][0]['runs'][1]['run_id']=bad['blocks'][0]['runs'][0]['run_id']
    if mutation=='cross_condition':
        ref=bad['waves'][0]['run_ids'][1]
        for block in bad['blocks']:
            for run in block['runs']:
                if run['run_id']==ref: run['condition']='CACHE' if run['condition']!='CACHE' else 'DIRECT'
    if mutation=='missing_wave':bad['waves'].pop()
    if mutation=='duplicate_wave_run':bad['waves'][0]['run_ids'][1]=bad['waves'][0]['run_ids'][0]
    if mutation=='pair_seed':
        pair=bad['blocks'][0]['pair_id'];paired=[b for b in bad['blocks'] if b['pair_id']==pair]
        paired[1]['task_seed']=paired[0]['task_seed']
        for run in paired[1]['runs']:run['task_seed']=paired[0]['task_seed']
    with pytest.raises(ValueError):validate_schedule(bad)
