# Setup and operation — GPU2/GPU3 paired deployment

Run VM commands from this package root. Nothing here installs or changes vLLM,
CUDA, drivers, torch, weights or host services. Port 8000 is out of scope.

## 1. Topology and private paths

The measured endpoints are `http://192.0.2.195:18042/v1` on GPU2 and
`http://192.0.2.195:18043/v1` on GPU3. DIRECT calls its assigned endpoint.
Adapter arms bind only `127.0.0.1:18142` or `:18143` in the VM and use the
corresponding LAN upstream. GPUs 0-1 and port 8000 remain out of scope.

Keep all secrets and run work outside this repository. The backend env file must
be an absolute, mode-0600-or-stricter, regular non-symlink file containing one
nonempty `BENCH_BACKEND_API_KEY=value` entry. The configured private locations
are:

```
/ABSOLUTE/PRIVATE/slaif-benchmark/secrets/backend-gpu3.env
/ABSOLUTE/PRIVATE/slaif-benchmark/runs
```

Never print the value, put it in argv, copy it into a workspace or mount the file
into a subject. `subject.env` contains a per-run value required for DIRECT, is
outside `/work`, mode 0600, and is deleted during cleanup.

## 2. VM prerequisites

Required: Docker Engine, Python 3.11+, pytest, Git and enough VM capacity for two
subject/Chromium processes plus controller and adapters. Add the operator to the
Docker group, then log out and back in before non-sudo qualification:

```bash
sudo usermod -aG docker "$USER"
docker version
python3 --version
python3 -m pytest --version
```

This does not install anything on the GPU host. Do not start a vLLM or recorder;
the dedicated GPU2/GPU3 services and recorder are operator-managed.

## 3. Immutable product and subject toolbox

Authenticate GHCR with a package-read credential over stdin and pull the exact
product digest. Never rebuild it.

```bash
printf '%s' "$SLAIF_GHCR_TOKEN" | docker login ghcr.io \
  -u "$SLAIF_GHCR_USERNAME" --password-stdin
docker pull ghcr.io/ulfe-lmi/slaif-local-coding@sha256:a3782915da58a403fd0f7991c57f9954b07bfb9377e4730715c0fb7398f901db
```

The subject toolbox is separate and contains no product or vLLM code. Build it
once in the VM, record the resulting image ID and do not rebuild during formal
runs:

```bash
CODEX_VERSION=0.149.0 bash scripts/build_subject_worker.sh
```

## 4. Site and offline checks

Copy `config/site.example.json` to `.local/site.gpu23.json` and fill exact facts. It
must define exactly lanes 2 and 3, `max_parallel: 2`, execution mode
`dual-lane-paired`, distinct GPU UUIDs, ports 18042/18043 and absolute private
paths. Every fresh worker receives the frozen catalog and mandatory `xhigh`.

```bash
python3 -m pytest -q
python3 -m compileall -q benchkit evaluators scripts host worker tests
python3 scripts/check_package.py
python3 scripts/validate_adapter_configs.py \
  --site .local/site.gpu23.json --out .local/adapter-config-check-gpu23.json
python3 scripts/judge_controls.py --worker-image sha256:<WORKER_IMAGE_ID> \
  --out .local/judge-controls.json --execute
```

Adapter validation uses the actual frozen product parser with Docker networking
disabled. Judge controls make no model calls. The historical delivery manifest
is intentionally not rewritten after pre-freeze harness changes; record a new
kit tree identity instead.

## 5. Read-only preflight (no inference)

```bash
python3 scripts/bench.py preflight \
  --site .local/site.gpu23.json --out .local/preflight-gpu23.json
```

Preflight reads `/health`, authenticated `/v1/models`, authenticated `/metrics`,
product identity and subject Codex help. Separately capture `ip route get
192.0.2.195`, interface/MAC, unauthenticated protected-model status without a
body, and confirmation that controller config does not target ports 18042/18043.

Obtain from the host operator content-free inventory/recorder evidence for GPU
UUID/name/VRAM, PID-to-GPU attribution, model revision, vLLM flags, all-GPU
background activity, actual sample timestamps and VM/host clock offset. Do not
inspect protected DP3 private configuration or manage the recorder from the VM.

## 6. Explicit inference boundary

The following commands send bounded inference and must not run until the human
explicitly authorizes bounded qualification requests in this VM session:

```bash
# BOUNDED INFERENCE — REQUIRES EXPLICIT AUTHORIZATION
python3 scripts/bench.py probe \
  --site .local/site.gpu23.json --out .local/capabilities-ATTEMPT_ID.json --execute

# PREPARE ONLY — no inference
python3 scripts/bench.py prepare-smoke-pair-block --site .local/site.gpu23.json \
  --task web --run-id smoke-paired-web-ATTEMPT_ID
sudo python3 scripts/prepare_permissions.py --site .local/site.gpu23.json --run-prefix smoke-paired-web-ATTEMPT_ID --execute

# BOUNDED SUBJECT INFERENCE — REQUIRES EXPLICIT AUTHORIZATION
python3 scripts/bench.py smoke-pair-block --site .local/site.gpu23.json \
  --task web --run-id smoke-paired-web-ATTEMPT_ID --execute
```

`smoke-pair-block` is one randomized four-period block per lane, dispatched as
four two-subject waves. This normal campaign is also the concurrency
qualification; there is no separate serial-versus-parallel study. Give every
probe/smoke a new attempt ID and preserve every outcome.
Qualify web, terminal and context paths, real tool continuation, native image
delivery, one/two-image behavior, governance/cache/rehydration, usage semantics,
typed compactions, isolation, capacity, recorder coverage and shared-host
contamination. No result from a config flag alone is a pass.

## 7. Schedule proposal

Schedules require per-lane block counts divisible by four. Each lane block has
four sequential positions; the matching condition at each position runs
concurrently on GPU2/GPU3. Williams orders balance position and predecessor
transitions independently on each lane.

```bash
python3 scripts/bench.py schedule --stage pilot --blocks-per-lane 4 --seed 20260922 \
  --out .local/pilot.schedule.gpu23.json
```

For all three tasks this is 96 logical runs in 48 paired waves. There is never
more than one subject per GPU or more than two total. Preparation creates fresh
per-run state but executes nothing:

```bash
python3 scripts/bench.py prepare --site .local/site.gpu23.json \
  --schedule .local/pilot.schedule.gpu23.json
sudo python3 scripts/prepare_permissions.py --site .local/site.gpu23.json --run-prefix pilot- --execute
```

## 8. Qualification, freeze and approval

Populate `.local/qualification.gpu23.json` only from measured evidence. Then, and only
then, freeze exact code/site/tasks/images/model/runtime/budgets/judges/evidence:

```bash
python3 scripts/site_fingerprint.py .local/site.gpu23.json
python3 scripts/bench.py freeze --site .local/site.gpu23.json --out .local/freeze.gpu23.json
```

Freeze is not stage authorization. A human-supplied approval must bind the exact
freeze file hash, canonical schedule hash, stage, `parallelism: 2`, allowed
wave IDs, expiry and retry policy. The controller never creates or signs
that approval.

```bash
python3 scripts/bench.py run-stage --site .local/site.gpu23.json \
  --schedule .local/pilot.schedule.gpu23.json --freeze .local/freeze.gpu23.json \
  --approval .local/pilot.approval.gpu23.json --execute
```

The dispatcher stops after a wave with broken measurement/protocol/shared
infrastructure evidence, preserves both attempts, drains both backends and
starts judges only after both subjects stop. No automatic or hidden retry exists.

## 9. Analysis and preservation

Preserve private raw events and every attempted run. Analyze stages separately,
report failure rates before successful-only efficiency, never add client and
backend token totals, and keep unavailable measures NULL. Include sequence
position, predecessor condition, backend warm-state and all-GPU shared-host
activity in limitations/sensitivity review.
