#!/usr/bin/env python3
from pathlib import Path
import argparse,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from benchkit.common import read_json
from benchkit.qualification_plan import execute_plan,prepare_plan

parser=argparse.ArgumentParser(description='Paired mixed-workload qualification; no formal benchmark authorization.')
parser.add_argument('action',choices=['prepare','execute']);parser.add_argument('--site',required=True);parser.add_argument('--plan',required=True)
parser.add_argument('--progress');parser.add_argument('--execute',action='store_true');args=parser.parse_args()
site=read_json(args.site);plan=read_json(args.plan)
if args.action=='prepare':
    paths=prepare_plan(site,plan);print(json.dumps({'prepared':len(paths)}));raise SystemExit(0)
if not args.execute:parser.error('explicit --execute required; no inference has occurred')
if not args.progress:parser.error('--progress is required for execution')
records=execute_plan(site,plan,Path(args.progress));print(json.dumps(records));raise SystemExit(0)
