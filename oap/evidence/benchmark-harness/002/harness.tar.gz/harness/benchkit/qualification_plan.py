"""Prepare and execute an explicitly authorized mixed-case qualification plan."""
from __future__ import annotations
from pathlib import Path
from .common import MEASURED_LANES,ROOT,TASKS,CONDITIONS,atomic_json,lease,object_hash,read_json,tree_hashes,utc,validate_site


def validate_plan(site: dict,plan: dict) -> None:
    if plan.get('schema')!='slaif-mixed-qualification-plan-v1': raise ValueError('unsupported qualification plan schema')
    if plan.get('site_sha256')!=object_hash(site): raise ValueError('qualification plan does not bind the exact site')
    waves=plan.get('waves',[])
    if not waves: raise ValueError('qualification plan has no waves')
    wave_ids=set();run_ids=set()
    for wave in waves:
        if wave.get('wave_id') in wave_ids: raise ValueError('duplicate qualification wave ID')
        wave_ids.add(wave.get('wave_id'));cases=wave.get('runs',[])
        if len(cases)!=2 or {c.get('lane') for c in cases}!=set(MEASURED_LANES): raise ValueError('each qualification wave needs lanes 2 and 3')
        if len({c.get('task') for c in cases})!=2: raise ValueError('qualification speed plan must pair different workloads')
        for case in cases:
            if case.get('run_id') in run_ids: raise ValueError('duplicate qualification run ID')
            run_ids.add(case.get('run_id'))
            if case.get('task') not in TASKS or case.get('condition') not in CONDITIONS: raise ValueError('unknown task or condition')
            if case.get('block')!=0 or case.get('sequence_position')!=1 or case.get('previous_condition') is not None:
                raise ValueError('qualification case metadata mismatch')


def prepare_plan(site: dict,plan: dict) -> list[str]:
    validate_site(site);validate_plan(site,plan)
    from .runner import prepare_case
    paths=[]
    for wave in plan['waves']:
        for case in wave['runs']: paths.append(str(prepare_case(site,case)))
    return paths


def execute_plan(site: dict,plan: dict,progress: Path) -> list[dict]:
    validate_site(site);validate_plan(site,plan)
    from .runner import run_wave
    records=[]
    with lease(Path(site['workspace_root'])/'.dispatcher.lock'):
        for wave in plan['waves']:
            runtime={**wave,'execution':'concurrent','max_parallel':2,
                     'qualification_mixed_cases':True,'possible_shared_host_interference':True}
            results=run_wave(site,runtime,prepared=True)
            record={'wave_id':wave['wave_id'],'finished_at':utc(),
                    'statuses':[x['status'] for x in results],
                    'measurement_valid':[x.get('measurement_valid') for x in results],
                    'protocol_violations':[x.get('protocol_violation') for x in results]}
            records.append(record)
            atomic_json(progress,{'schema':'slaif-mixed-qualification-progress-v1','plan_sha256':object_hash(plan),
                'kit_tree_sha256':object_hash(tree_hashes(ROOT)),'updated_at':utc(),'waves':records},overwrite=True)
            if any(not x.get('measurement_valid') or x.get('error_type') or x.get('protocol_violation') for x in results):
                raise RuntimeError('qualification wave requires reconciliation; no next wave dispatched')
    return records
