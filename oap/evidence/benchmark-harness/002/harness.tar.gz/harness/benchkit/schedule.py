"""Counterbalanced condition blocks dispatched as paired GPU2/GPU3 waves."""
from __future__ import annotations
import random
from .common import CONDITIONS, MEASURED_LANES, TASKS


def validate_schedule(schedule: dict) -> None:
    if schedule.get('schema')!='slaif-schedule-v3-dual-lane': raise ValueError('unsupported schedule schema')
    if schedule.get('execution_mode')!='dual-lane-paired' or schedule.get('max_parallel')!=2:
        raise ValueError('schedule must require dual-lane paired execution')
    tasks=schedule.get('tasks',[]);blocks_per_lane=schedule.get('blocks_per_lane')
    if not tasks or len(set(tasks))!=len(tasks) or any(t not in TASKS for t in tasks): raise ValueError('invalid schedule task set')
    if not isinstance(blocks_per_lane,int) or blocks_per_lane<=0 or blocks_per_lane%4:
        raise ValueError('blocks_per_lane must be a positive multiple of four')
    if schedule.get('conditions')!=list(CONDITIONS): raise ValueError('schedule condition set/order changed')
    blocks=schedule.get('blocks',[]);waves=schedule.get('waves',[])
    expected_blocks=len(tasks)*blocks_per_lane*len(MEASURED_LANES);expected_runs=4*expected_blocks
    if len(blocks)!=expected_blocks or schedule.get('logical_runs')!=expected_runs: raise ValueError('schedule run/block count mismatch')
    if len(waves)!=expected_runs//2: raise ValueError('schedule wave count mismatch')

    block_ids=set();run_ids=set();run_map={};block_map={};by_task_lane={
        (task,lane):[] for task in tasks for lane in MEASURED_LANES}
    for block in blocks:
        block_id=block.get('block_id');lane=block.get('lane');runs=block.get('runs',[]);order=block.get('condition_order')
        if block_id in block_ids: raise ValueError('duplicate block ID')
        block_ids.add(block_id)
        if lane not in MEASURED_LANES or block.get('execution')!='sequential_within_lane' or block.get('possible_backend_carryover') is not True:
            raise ValueError('invalid lane block execution metadata')
        if len(runs)!=4 or not isinstance(order,list) or set(order)!=set(CONDITIONS): raise ValueError('lane block must contain all four conditions once')
        if [r.get('condition') for r in runs]!=order: raise ValueError('recorded condition order mismatch')
        for position,run in enumerate(runs,1):
            run_id=run.get('run_id')
            if run_id in run_ids: raise ValueError('duplicate run ID')
            run_ids.add(run_id);run_map[run_id]=run;block_map[run_id]=block
            expected_previous=order[position-2] if position>1 else None
            if (run.get('lane')!=lane or run.get('sequence_position')!=position or
                run.get('previous_condition')!=expected_previous or run.get('task')!=block.get('task') or
                run.get('block')!=block.get('block') or run.get('task_seed')!=block.get('task_seed') or
                run.get('block_id')!=block_id or run.get('pair_id')!=block.get('pair_id')):
                raise ValueError('inconsistent lane-block run metadata')
        key=(block.get('task'),lane)
        if key not in by_task_lane: raise ValueError('block has unknown task or lane')
        by_task_lane[key].append(block)

    for (task,lane),lane_blocks in by_task_lane.items():
        lane_blocks.sort(key=lambda item:item['block'])
        if [b['block'] for b in lane_blocks]!=list(range(1,blocks_per_lane+1)):
            raise ValueError(f'noncanonical block numbers for {task} lane {lane}')
        for cycle in range(blocks_per_lane//4):
            group=lane_blocks[cycle*4:(cycle+1)*4]
            for position in range(4):
                if {b['condition_order'][position] for b in group}!=set(CONDITIONS): raise ValueError('condition-position balance broken')
            transitions=[pair for b in group for pair in zip(b['condition_order'],b['condition_order'][1:])]
            if len(transitions)!=12 or len(set(transitions))!=12: raise ValueError('first-order carryover balance broken')

    pair_groups={}
    for block in blocks: pair_groups.setdefault(block.get('pair_id'),[]).append(block)
    if len(pair_groups)!=len(tasks)*blocks_per_lane: raise ValueError('pair-block count mismatch')
    for pair in pair_groups.values():
        if len(pair)!=2 or {b['lane'] for b in pair}!=set(MEASURED_LANES): raise ValueError('pair block must cover both lanes')
        if len({b['task'] for b in pair})!=1 or len({tuple(b['condition_order']) for b in pair})!=1:
            raise ValueError('paired lane blocks must share task and condition order')
        if len({b['task_seed'] for b in pair})!=2: raise ValueError('paired lane blocks require distinct task seeds')

    wave_ids=set();seen_runs=[]
    for wave in waves:
        wave_id=wave.get('wave_id');refs=wave.get('run_ids',[])
        if wave_id in wave_ids: raise ValueError('duplicate wave ID')
        wave_ids.add(wave_id)
        if wave.get('execution')!='concurrent' or wave.get('max_parallel')!=2 or wave.get('possible_shared_host_interference') is not True:
            raise ValueError('wave must declare concurrent dual-lane execution and interference')
        if len(refs)!=2 or len(set(refs))!=2 or any(r not in run_map for r in refs): raise ValueError('wave must reference two known unique runs')
        runs=[run_map[r] for r in refs];blocks_for_wave=[block_map[r] for r in refs]
        if {r['lane'] for r in runs}!=set(MEASURED_LANES): raise ValueError('wave must use lanes 2 and 3 exactly once')
        if len({r['condition'] for r in runs})!=1 or len({r['task'] for r in runs})!=1:
            raise ValueError('wave must pair the same task and condition')
        if len({r['sequence_position'] for r in runs})!=1 or len({r['pair_id'] for r in runs})!=1:
            raise ValueError('wave pair metadata mismatch')
        if wave.get('pair_id')!=runs[0]['pair_id'] or wave.get('condition')!=runs[0]['condition'] or wave.get('task')!=runs[0]['task']:
            raise ValueError('wave summary differs from referenced runs')
        if len({b['pair_id'] for b in blocks_for_wave})!=1: raise ValueError('wave crosses pair blocks')
        seen_runs.extend(refs)
    if len(seen_runs)!=expected_runs or set(seen_runs)!=run_ids or len(set(seen_runs))!=expected_runs:
        raise ValueError('every run must appear in exactly one wave')


def make_schedule(tasks: list[str], blocks_per_lane: int, seed: int, stage: str) -> dict:
    if not tasks or len(set(tasks))!=len(tasks) or any(t not in TASKS for t in tasks): raise ValueError('invalid or duplicate task set')
    if blocks_per_lane<=0 or blocks_per_lane%4: raise ValueError('blocks_per_lane must be a positive multiple of four')
    if stage not in ('pilot','main','extension','smoke'): raise ValueError('invalid stage')
    rng=random.Random(seed);blocks=[];waves=[]
    williams=((0,1,3,2),(1,2,0,3),(2,3,1,0),(3,0,2,1))
    for cycle in range(blocks_per_lane//4):
        per_task={}
        for task in tasks:
            labels=list(CONDITIONS);rng.shuffle(labels);rows=list(range(4));rng.shuffle(rows)
            per_task[task]=[[labels[i] for i in williams[row]] for row in rows]
        for period in range(4):
            task_order=list(tasks);rng.shuffle(task_order)
            for task in task_order:
                block_no=cycle*4+period+1;order=per_task[task][period];pair_id=f'{stage}-{task}-pair-b{block_no:02d}';pair_blocks=[]
                for lane in MEASURED_LANES:
                    block_id=f'{stage}-{task}-l{lane}-b{block_no:02d}';task_seed=rng.randrange(1,2**31);runs=[]
                    for position,condition in enumerate(order,1):
                        prior=order[position-2] if position>1 else None
                        runs.append({'run_id':f'{block_id}-p{position:02d}-{condition.lower()}',
                            'lane':lane,'condition':condition,'task':task,'block':block_no,'block_id':block_id,
                            'pair_id':pair_id,'task_seed':task_seed,'sequence_position':position,'previous_condition':prior})
                    pair_blocks.append({'block_id':block_id,'pair_id':pair_id,'lane':lane,'task':task,
                        'block':block_no,'task_seed':task_seed,'execution':'sequential_within_lane',
                        'condition_order':order,'possible_backend_carryover':True,'runs':runs})
                blocks.extend(pair_blocks)
                for position,condition in enumerate(order,1):
                    refs=[next(b['runs'][position-1]['run_id'] for b in pair_blocks if b['lane']==lane) for lane in MEASURED_LANES]
                    waves.append({'wave_id':f'{pair_id}-p{position:02d}-{condition.lower()}',
                        'pair_id':pair_id,'task':task,'condition':condition,'sequence_position':position,
                        'execution':'concurrent','max_parallel':2,'possible_shared_host_interference':True,'run_ids':refs})
    schedule={'schema':'slaif-schedule-v3-dual-lane','stage':stage,'seed':seed,
        'execution_mode':'dual-lane-paired','max_parallel':2,
        'counterbalance':'identical-condition paired waves; randomized Williams orders independently balanced on each lane',
        'blocks_per_lane':blocks_per_lane,'tasks':tasks,'conditions':list(CONDITIONS),
        'logical_runs':8*blocks_per_lane*len(tasks),'blocks':blocks,'waves':waves}
    validate_schedule(schedule);return schedule
