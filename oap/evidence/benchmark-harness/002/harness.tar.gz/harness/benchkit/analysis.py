"""Descriptive and paired estimates. No fabricated performance or success claims."""
from __future__ import annotations
import csv,json,math,random,statistics
from collections import defaultdict
from pathlib import Path
from .common import read_json

def quantile(xs,p):
    xs=sorted(xs)
    if not xs:return None
    i=(len(xs)-1)*p;lo=int(i);hi=min(lo+1,len(xs)-1)
    return xs[lo]*(hi-i)+xs[hi]*(i-lo) if hi!=lo else xs[lo]

def describe(xs):
    xs=[float(x) for x in xs if x is not None and math.isfinite(x)]
    if not xs:return {'n':0,'mean':None,'sd':None,'median':None,'q1':None,'q3':None}
    return {'n':len(xs),'mean':statistics.mean(xs),'sd':statistics.stdev(xs) if len(xs)>1 else None,
            'median':statistics.median(xs),'q1':quantile(xs,.25),'q3':quantile(xs,.75)}

def paired_ratio(pairs,seed=1729,nboot=5000):
    logs=[math.log(a/b) for a,b in pairs if a is not None and b is not None and a>0 and b>0]
    if len(logs)<2:return {'n_pairs':len(logs),'ratio':math.exp(logs[0]) if logs else None,'ci95':None}
    rng=random.Random(seed)
    boot=[math.exp(statistics.mean(rng.choices(logs,k=len(logs)))) for _ in range(nboot)]
    return {'n_pairs':len(logs),'ratio':math.exp(statistics.mean(logs)),
            'ci95':[quantile(boot,.025),quantile(boot,.975)],'method':'paired-block bootstrap of mean log-ratio; exploratory finite-sample interval'}

def collect(root:Path):
    rows=[]
    for p in sorted(root.glob('*/result.json')):
        r=read_json(p);c=r['case'];j=read_json(p.parent/'judge.json') if (p.parent/'judge.json').exists() else {}
        visual=read_json(p.parent/'visual-rating.json') if (p.parent/'visual-rating.json').exists() else {}
        deltas=r.get('backend_deltas',{})
        def d(k):
            x=deltas.get(k,{})
            return x.get('value') if x.get('status')=='ok' else None
        a=d('vllm:prompt_tokens_total');b=d('vllm:generation_tokens_total')
        rows.append({'run_id':c['run_id'],'task':c['task'],'condition':c['condition'],'block':c['block'],'lane':c['lane'],
          'sequence_position':c.get('sequence_position'),'previous_condition':c.get('previous_condition'),
          'stage':c['run_id'].split('-',1)[0],'status':r['status'],
          'functional_success':j.get('functional_success'),'judge_status':j.get('status'),
          'wall_seconds':r.get('coding_wall_seconds'),'backend_input_tokens':a,'backend_output_tokens':b,
          'backend_gross_tokens':a+b if a is not None and b is not None else None,
          'backend_completed_requests':d('vllm:request_success_total'),
          'context_compactions':r.get('compactions',{}).get('count'),
          'context_exposure':r.get('context_exposure'),'measurement_valid':r.get('measurement_valid',False),
          'protocol_violation':r.get('protocol_violation'),'visual_score':visual.get('visual_score'),
          'visual_success':visual.get('visual_success'),'joint_web_success':(bool(j.get('functional_success')) and visual['visual_success']) if c['task']=='web' and 'visual_success' in visual else None})
    return rows

def analyze(root:Path,out:Path):
    if out.exists():raise FileExistsError('analysis directory exists; version each analysis')
    out.mkdir(parents=True)
    rows=collect(root)
    if not rows:raise ValueError('no result.json files')
    with (out/'runs.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    identities=set()
    for row in rows:
        if row['stage']=='smoke': continue
        key=(row['stage'],row['task'],row['lane'],row['block'],row['condition'])
        if key in identities: raise ValueError('Multiple attempts for one experimental cell; explicitly adjudicate attempts before analysis, never choose the best or last silently.')
        identities.add(key)
    metrics=('wall_seconds','backend_gross_tokens','backend_input_tokens','backend_output_tokens','backend_completed_requests')
    groups=defaultdict(list)
    for r in rows:groups[(r['stage'],r['task'],r['condition'],r['lane'])].append(r)
    summary=[]
    for key,rs in groups.items():
        success=sum(r['functional_success'] is True for r in rs)
        summary.append({'stage':key[0],'task':key[1],'condition':key[2],'lane':key[3],'n_attempts':len(rs),
          'functional_successes':success,'functional_score_available':sum(r['functional_success'] is not None for r in rs),
          'all_attempts':{m:describe([r[m] for r in rs if r['measurement_valid']]) for m in metrics},
          'successful_only_secondary':{m:describe([r[m] for r in rs if r['measurement_valid'] and r['functional_success'] is True]) for m in metrics}})
    comparisons=[]
    for stage,task in sorted({(r['stage'],r['task']) for r in rows}):
        if stage=='smoke': continue
        selected=[r for r in rows if r['stage']==stage and r['task']==task]
        for numerator,denominator in [('BOTH','CACHE'),('BOTH','VISION'),('BOTH','DIRECT'),('VISION','DIRECT'),('CACHE','DIRECT')]:
            aa={(r['lane'],r['block']):r for r in selected if r['condition']==numerator}
            bb={(r['lane'],r['block']):r for r in selected if r['condition']==denominator}
            for metric in metrics:
                paired=[(aa[k][metric],bb[k][metric]) for k in sorted(aa.keys()&bb.keys()) if aa[k]['measurement_valid'] and bb[k]['measurement_valid']
                        and aa[k]['functional_success'] is True and bb[k]['functional_success'] is True]
                comparisons.append({'stage':stage,'task':task,'numerator':numerator,'denominator':denominator,'metric':metric,
                  'interpretation':'secondary successful-pair efficiency only; report failure rates first; not a complete 2x2 factorial',**paired_ratio(paired)})
    report={'groups':summary,'comparisons':comparisons,'notes':[
      'No task pooling. Pilot and main remain separate stages.',
      'Functional and visual success are separate; visual ratings may still be missing.',
      'Client counters are never added to backend totals; compiler traffic is already included in backend totals.',
      'Bootstrap pairs preserve block pairing but are approximate with few blocks; inspect sequence-position and prior-condition effects.',
      'Do not interpret low consumption by failures as an efficiency benefit.',
      'Each physical lane retains complete within-lane condition blocks; matching conditions run concurrently on GPU2 and GPU3.',
      'GPU0-1 and shared host CPU/RAM/PCIe/network activity remain possible contamination and require telemetry review.',
      'Report lane-stratified results and serial-versus-concurrent qualification before combining lanes.']}
    (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    return report
