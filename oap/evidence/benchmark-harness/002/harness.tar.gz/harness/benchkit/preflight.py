from __future__ import annotations
import base64,concurrent.futures,json,time
from urllib.request import Request,urlopen
from .common import read_env,run,utc
from .dockerutil import assert_product,inspect_image
from .metrics import scrape,total

def request(url: str,key: str,body: dict|None=None,timeout: float=60) -> dict:
    headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'}
    req=Request(url,headers=headers,data=None if body is None else json.dumps(body).encode())
    start=time.monotonic()
    try:
        with urlopen(req,timeout=timeout) as r:
            data=json.loads(r.read(4*1024*1024))
        # Response body is used in memory only for capability/usage extraction.
        out=data.get('output',[]) if isinstance(data,dict) else []
        return {'ok':True,'elapsed_seconds':time.monotonic()-start,'usage':data.get('usage'),
                'object':data.get('object'),'output_types':[x.get('type') for x in out if isinstance(x,dict)],
                'model_ids':[x.get('id') for x in data.get('data',[]) if isinstance(x,dict)]}
    except Exception as e:
        return {'ok':False,'elapsed_seconds':time.monotonic()-start,'error_type':type(e).__name__,
                'http_status':getattr(e,'code',None)}

def inspect_site(site: dict) -> dict:
    key=read_env(site['secret_env_file'])['BENCH_BACKEND_API_KEY']
    facts={'created_at':utc(),'read_only':True,'product':assert_product(site),'worker':inspect_image(site['subject_worker_image'])['Id'],'lanes':[]}
    for lane in site['lanes']:
        origin=lane['backend_url'].removesuffix('/v1')
        health=request(origin+'/health',key)
        # /health may be empty, so use a status-only check separately.
        try:
            with urlopen(Request(origin+'/health',headers={'Authorization':'Bearer '+key}),timeout=5) as r: health={'ok':r.status==200,'status':r.status}
        except Exception as e: health={'ok':False,'error_type':type(e).__name__}
        metrics=scrape(lane['metrics_url'],key)
        required=site['measurement']['request_metrics_required']
        facts['lanes'].append({'lane':lane['lane'],'health':health,'models':request(lane['backend_url']+'/models',key),
          'metrics':{'ok':metrics['ok'],'series_count':len(metrics.get('series',{})),
                     'required_available':{m:total(metrics.get('series',{}),m) is not None for m in required},
                     'running':total(metrics.get('series',{}),'vllm:num_requests_running'),
                     'waiting':total(metrics.get('series',{}),'vllm:num_requests_waiting')}})
    # Probe help, without model requests and without mounting personal Codex home.
    for label,cmd in [('codex_version',['codex','--version']),('exec_help',['codex','exec','--help']),
                      ('resume_help',['codex','exec','resume','--help'])]:
        text=run(['docker','run','--rm','--network','none',site['subject_worker_image'],*cmd]).stdout
        facts[label]=text if label=='codex_version' else {'json_flag':'--json' in text,'stdin_prompt':'-' in text}
    facts['qualified']=False
    facts['note']='Read-only inventory is not full fixture qualification. Follow QUALIFICATION.md and supply measured evidence.'
    return facts

def capability_probes(site: dict) -> dict:
    from .common import ROOT
    key=read_env(site['secret_env_file'])['BENCH_BACKEND_API_KEY']
    img='data:image/png;base64,'+base64.b64encode((ROOT/'tests/fixtures/red.png').read_bytes()).decode()
    facts={'created_at':utc(),'bounded_inference':True,'execution':'paired_same_probe_on_gpu2_gpu3','lanes':[
        {'lane':lane['lane'],'images':{},'interpretation':'A two-image rejection makes image-disabled graphical comparisons capability/resilience comparisons, not equal-completion efficiency.'}
        for lane in site['lanes']]}
    lane_out={x['lane']:x for x in facts['lanes']};model=site['served_model']
    probes=[('text',None,{'model':model,'input':'Reply with READY.','reasoning':{'effort':'xhigh'},'max_output_tokens':256}),
      ('tool_declaration',None,{'model':model,'input':'Use the emit_status function once with status READY.',
       'tools':[{'type':'function','name':'emit_status','description':'Emit a readiness status',
                 'parameters':{'type':'object','properties':{'status':{'type':'string'}},'required':['status'],'additionalProperties':False}}],
       'tool_choice':'required','reasoning':{'effort':'xhigh'},'max_output_tokens':256})]
    for n in (1,2):
        probes.append(('images',str(n),{'model':model,'input':[{'role':'user','content':[
          {'type':'input_text','text':'Name the dominant color.'}]+[{'type':'input_image','image_url':img,'detail':'auto'} for _ in range(n)]}],
          'reasoning':{'effort':'xhigh'},'max_output_tokens':256}))
    for field,subfield,body in probes:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            pending={lane['lane']:pool.submit(request,lane['backend_url']+'/responses',key,body) for lane in site['lanes']}
            for lane_id,future in pending.items():
                if subfield is None: lane_out[lane_id][field]=future.result()
                else: lane_out[lane_id][field][subfield]=future.result()
    facts['qualified']=False
    facts['note']='Also execute a real Codex tool continuation + screenshot view; these bounded probes do not prove native Codex envelope compatibility.'
    return facts
