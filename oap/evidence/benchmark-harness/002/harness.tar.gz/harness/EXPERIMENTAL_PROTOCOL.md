# Standalone SLAIF Local Coding experiment — protocol v3.0 paired GPU2/GPU3 proposal

## 1. Scientific question and scope

Measure whether image-history adaptation and governance compilation/cache/
reinjection improve real Codex coding and long-context work with the SAME local
model backend. Success and quality are primary; computational cost is interpreted
alongside them, not used to reward early failure. This is an external consumer
study of an immutable release candidate, not a development task in the product
repository. There is no SLAIF API Gateway.

The original user plan supplied web Minesweeper, ncurses Minesweeper and long
AGENTS.md fact recovery, gross model traffic, tool/image/compaction measurements,
independent judging, repeated randomized blocks and per-run timelines. Later
user decisions add four feature/reference conditions, a VM, ordinary host-LAN
access and protected existing services. This revision uses two independent
A100 replicas on physical GPU2 and GPU3 in paired concurrent waves.
Concrete UI contracts, budgets, control fixtures, schedule implementation and
analysis rules below are new operational specifications supplied by this kit.
They are candidates for calibration before the first formal freeze, not
historical claims that these exact files existed in the original discussion.

## 2. Conditions and interpretable contrasts

| Condition | Image policy | Governance compiler/cache/rehydration | Adapter |
|---|---|---|---|
| DIRECT | Backend unchanged | Absent | Bypassed |
| VISION | retain_newest, maximum 1 | Disabled | Present |
| CACHE | passthrough, no max-images field | Enabled, static identity | Present |
| BOTH | retain_newest, maximum 1 | Enabled, static identity | Present |

All three adapter arms use the same RC7 image; all four arms use the same
model/runtime/decoding/limits/client/task prompt/judge. No hosted-tool filter is
secretly enabled only in adapter arms. Gateway ingress is disabled and the
adapter binds VM loopback. Its backend URL is the physical host LAN address.
Both the proxy and internal compiler use the same lane and backend key.

Primary within-adapter contrasts: BOTH versus CACHE (add vision with cache
held on), BOTH versus VISION (add cache with vision held on). Practical reference
contrast: BOTH versus DIRECT. VISION/DIRECT and CACHE/DIRECT include transport
and any other adapter behavior. VISION/CACHE changes two features simultaneously;
it is not a pure vision or pure cache effect. With no PLAIN adapter arm this is
not a complete 2x2 factorial and cannot isolate a pure proxy overhead or a full
interaction term. Do not claim otherwise.

## 3. Fixed workload definitions

### Web Minesweeper
A real responsive polished browser game in local HTML/CSS/JS. The subject must
implement game rules, controls and stable DOM/test interfaces in its task
ARCHITECTURE.md. It must use Playwright, produce desktop/update/mobile/crop
screenshots, and actually send images through its image-view tool for reasoning.
Creating PNGs alone is not vision exposure. Preserve earlier screenshot context;
do not add a synthetic client workaround for the disabled vision arms.
The independent judge tests rules through DOM actions and an independent oracle,
checks errors/difficulty/restart, and captures final desktop/mobile screenshots.
A blinded visual rubric measures quality separately from functionality.

### ncurses Minesweeper
The same game family with a genuine Python curses UI and PTY testing. No browser,
Playwright, screenshots or model image calls. Task architecture fixes controls,
board symbols, CLI and deterministic diagnostic state so evaluation is not
subjective. The judge checks both screen and state; a state-file-only facade
is not acceptable. It is a negative control for the vision transformation.

### Long-context AGENTS.md fact recovery
Retain the original third task separately from the two app-building tasks.
The seed has four root facts and twelve delegated facts (sixteen total), with an
external answer key. The controller supplies a frozen sequence of substantial
synthetic audit inputs in the same session, then requests exact facts and sources.
Governance remains available; rereading is allowed and its cost is measured.
The supplied pressure generator is synthetic and inserts data directly into the
conversation so an efficient shell script cannot entirely evade context load.
This is a disclosed stress fixture, not a claim that natural development always
loads context that way. Calibrate its size against the actual model/tokenizer.

Target at least three observed natural compactions in the DIRECT control during
calibration. Record actual counts in every arm. Do not infer compaction from
wall time, a token estimate or a subject saying it happened. If a cache-enabled
arm needs fewer compactions on the same fixed workload, preserve that as an
outcome; do not exclude it post hoc for missing the target. If baseline exposure
never reaches the intended regime, revise the pressure fixture before main.
If the client does not expose trustworthy compaction events, label the outcome
unavailable and do not claim a post-compaction mechanism result.

Task seeds contain instructions and contracts, not a prewritten game solution.
All condition copies of a given task/block receive identical content and task
seed. Runtime app ports differ by lane only. Hidden judge code/answer keys and
other runs are not mounted during subject coding.

## 4. Hardware layout and paired execution

Measured replicas are physical GPU2 on `192.0.2.195:18042` and GPU3 on
`192.0.2.195:18043`, both NVIDIA A100-SXM4-80GB, TP=1 and identically
configured. Exact UUIDs are site facts. GPU0-1 and port 8000 belong to protected
DP2 and are never benchmark endpoints. No vLLM, CUDA, driver, model,
quantization, attention or clock change is authorized.

Maximum subject concurrency is two: exactly one subject per measured GPU.
DIRECT calls the assigned LAN endpoint; adapter arms call a unique VM-loopback
adapter with that same lane upstream. Each wave runs the same condition on both
lanes. Both running/waiting gauges must drain before the next wave, and no judge
starts until both subjects stop and both backends drain.

Synchronized recorder session `qualification-gpu23-01` covers GPU2, GPU3, both
metrics endpoints and protected-lane/host activity. Shared CPU, RAM, PCIe,
storage and network activity is preserved as a contamination covariate. Actual
sample timestamps and process attribution are required.

## 5. Randomization, blocking and repetitions

Each physical-lane block contains all four conditions once with one task seed.
The paired block on the other lane uses a distinct seed and the same condition
order. At each sequence position the matching condition runs concurrently on
both lanes. Williams cycles balance positions and predecessor transitions
independently on each lane. Record pair/wave ID, condition order, sequence
position, previous condition, lane/GPU UUID, task, block and stage.

Default balanced sizes:

| Scope | Pilot n=8/cell (4/lane) | Main n=24/cell (12/lane) | Optional total n=32/cell (16/lane) |
|---|---:|---:|---:|
| Two coding tasks only | 64 runs / 32 paired waves | 192 runs / 96 paired waves | 256 runs / 128 paired waves |
| Original three-task study | 96 runs / 48 paired waves | 288 runs / 144 paired waves | 384 runs / 192 paired waves |

The default site includes all three tasks. Excluding context is an explicit
pre-freeze task-set choice, not a missing deliverable. Pilot is for measurement,
judge, budget and workload calibration. Default main excludes pilot data.
Set main sample size using pilot variability before looking at main effects.
The optional n=16 stage is four additional balanced blocks, not a second full
16-block run. If extension is chosen after looking at main outcomes, report it
as such and do not pretend a conventional fixed-sample CI retains a sequential
coverage guarantee. Never stop because a favorable effect first becomes significant.

## 6. Run start, persistence and completion

Fresh workspace, Git seed, Codex home and adapter/cache per run. Frozen subject
container image and Codex build. Controller instructions do not enter the subject
workspace. The controller must not help implement the game or provide adaptive
hints. Same initial prompt/goal and fixed continuation rules in all arms.

Scheduled execution uses the documented headless exec/resume driver; native
interactive /goal texts are also supplied, but modes must not be mixed. Persist
the same session ID for continued work and context pressure. No --last across
shared homes. The controller permits ordinary subject coding inside the outer
container, never privileged access to the host. Main work stops on declared
submission, terminal subject error, frozen wall/token/continuation limit, or an
infrastructure blocker. A declaration is not a pass. Independent judging occurs
after both subjects in the wave stop and both endpoints drain; hidden judge feedback is
never fed back to the subject. Visible self-tests are encouraged and count as
subject work.

Initial proposed hard wall budgets: web 7,200 s, terminal 5,400 s, context
14,400 s; up to eight fixed continuations for app tasks; a 2,000,000 observed
client-token soft limit and 128 MiB per-invocation raw event cap. These are
engineering starting values, not justified power/budget facts: calibrate and
freeze before main. The token soft limit is checked at turn boundaries; the
wall timer is the hard bound. Record every exceeded limit and consumed cost.

## 7. State reset and backend caches

Recreate the subject and adapter for every run, producing clean client history,
browser state, adapter tmpfs cache and rehydration map. Use unique static session
identity. No cross-run adapter reuse. These are cold ADAPTER-cache trials;
compilation/reuse within a run is part of the treatment.

Do not conflate that cache with vLLM prefix/KV caching. The existing backend
policy remains unchanged, with no endpoint cache-reset request or model restart.
Record its flags, prefix-cache counters if exposed, warmup/order and hit rates.
The primary workload is therefore cold adapter / existing backend warm state.
Balanced ordering helps but does not prove absence of backend carryover. If a
cold-backend study is wanted, it requires separately authorized dedicated
instances and a new frozen policy; do not silently reset protected servers.

## 8. Outcomes and attribution

Primary per-task outcomes: functional success; browser visual-quality score
and joint functional/visual success; sixteen-fact value/source accuracy for
context. Judge controls must accept known-correct implementations and reject
deliberately defective ones before subject scoring. Keep judge version fixed.

Primary resource outcomes: total backend input and output tokens across the
entire run window, their gross sum, and coding wall time. Backend totals include
adapter compiler calls. Client usage is a separate view of overlapping traffic,
not extra traffic to be added. Distinguish cached/uncached and image-token
subcomponents only when empirically exposed; unavailable is NULL.

Secondary outcomes: request count, median/p95 model latency (histogram estimates
labeled approximate), tool category counts, image creation and actual image-view
counts, screenshot bytes/dimensions, API failures/retries, compaction count,
AGENTS rereads/searches and post-compaction recovery traffic/time. Native event
schemas must be calibrated; the supplied parser intentionally does not invent
all these metrics when the client does not expose them. A tool label or PNG
file is not proof that the model received an image. Complete the metadata-only
extractors during qualification, then freeze; retain original private events.

Host recorder samples all four GPUs' utilization, used/total VRAM, power, temperature,
clocks, compute PID attribution, host CPU/memory and numeric vLLM series. No
installation or service change is needed. GPU energy is a trapezoidal integral
of sampled power, with explicit clock-offset and coverage limits. It is not
whole-host/VM energy. Missing sensors stay unavailable. Recording overhead must
be present in every arm and measured during qualification.

VM endpoint snapshots bracket only subject generation and drain, excluding
independent evaluator inference/screenshots (judges make no model calls).
Metric series resets, disappearing labels, failed scrapes and contamination
are invalid measurements, not zeros. Do not poll model inference for readiness;
use /health, /readyz and queue/metric observations.

## 9. Capability versus efficiency

Before Task 1, test one- and two-image requests on the exact backend. If the
unmodified model only accepts one image, CACHE and DIRECT can fail once Codex
sends accumulated history. That is a real capability/resilience outcome, not an
unfair reason to secretly disable screenshots or increase backend capacity in
those arms. Report success/failure first. A failed 200-token run is not more
efficient than a completed 20,000-token run. Secondary efficiency ratios are
restricted to paired successful outcomes and explicitly disclose selection.
If vision is unsupported entirely, graphical vision-benefit testing is blocked;
do not silently substitute a text-only model and claim the planned test ran.

## 10. Failure and contamination rules

Preserve every attempt with stage/task/block/condition/lane IDs. Terminal
statuses distinguish SUBMITTED (claim), INCOMPLETE, SUBJECT_ERROR, TIMEOUT,
TOKEN_BUDGET, INFRASTRUCTURE_ERROR, missing session identity, protocol violation
and judge infrastructure error. Derived task pass is a separate judge field.

Unexpected server restart/counter reset, unrelated GPU work, wrong endpoint,
changed image/config, tampered seed instructions or crossed session IDs require
reconciliation. If a shared infrastructure failure occurs within a block, stop
the remaining sequence and mark the block for reconciliation. Do not delete
its task outcomes. No automatic retry: a proven infrastructure retry has a new
attempt ID, original evidence and an explicit adjudication. Ordinary model/task
failures stay in the assigned arm. Reporting only successful retries is prohibited.

## 11. Statistical reporting

Report by task and stage, never one pooled benchmark score. Show success counts,
judgment availability, mean/SD and median/IQR of valid resource measures.
Show all-attempt consumption and successful-only consumption separately.
For paired success/resource contrasts use within-block log ratios with a
paired-block bootstrap CI; the bundled analysis script implements this
exploratory estimate. Report missing pairs and small sample limitations.
Inspect sequence-position, previous-condition and background-load effects and,
for a formal paper, predeclare a blocked analysis respecting the randomized
schedule. Counterbalancing alone is not a license for an unblocked t-test.

Primary mechanistic contrasts are BOTH/CACHE on graphical work and BOTH/VISION
on context recovery; practical BOTH/DIRECT remains a key outcome. On no-image
tasks, BOTH/CACHE is the direct negative-control contrast for adding vision;
VISION/DIRECT still includes adapter transport. If claiming equivalence, define
an equivalence margin in advance; a nonsignificant difference is not equality.
State the multiplicity policy before main; report intervals and effect sizes
rather than searching many outcomes for significance. The kit does not choose
an unsupported precision/power guarantee from the old run counts.

## 12. Provenance, privacy and outputs

Freeze product digest/source/wheel; worker image/client version; backend model
revision/runtime/flags/GPU identities; task prompts/seeds; all configurations;
controller/judges; schedule/seed; budgets and qualification evidence. Do not
freeze credentials. Store private raw synthetic Codex JSONL/rollouts and task
artifacts for later extraction, as requested in the original plan. Backend
telemetry and exported summaries contain numeric/allowlisted metadata only.
Redact known credentials; scan native rollouts before sharing. No real customer
workspaces or protected service keys are placed in subjects.

Deliver the frozen manifest, approvals, every run result, independent judgments,
blinded visual ratings, reconciled backend/client ledgers, host telemetry and
clock evidence, per-run cumulative-token timelines, per-task distributions,
paired effects, failure taxonomy and limitations. No generated report may say
benchmark complete when required judgments or measurements are absent.

## 13. Stage gates

Inventory -> offline tests -> actual RC config validation -> known-good/bad
judge controls -> explicitly authorized paired model/tools/vision/metrics probes
-> paired two-lane smoke blocks and carryover/contamination review
-> complete qualification -> freeze
-> human pilot approval -> pilot -> revised/frozen main protocol -> human main
approval -> main -> analysis -> separately approved extension, if any.

Preparing artifacts is this request's deliverable. It does not itself authorize
host service replacement, a scientific pilot, a final public release, or
production cutover.
