# Sources and design provenance

This file preserves historical design provenance. The current executable
proposal is the paired A100 GPU2/GPU3 design in `EXPERIMENTAL_PROTOCOL.md`;
the earlier four-V100 decision below is not current authorization or topology.

## User-supplied requirements (authoritative scope)

- Original plan: web Minesweeper with screenshot-assisted design; terminal
  Minesweeper; long-session AGENTS.md recovery; gross token/time/tool/image/
  context measures; independent judges; randomized blocked repetitions.
  The original pasted transcript is retained under references/ as historical
  input, not as the current executable specification.
- Later explicit choices: standalone/no Gateway; DIRECT, VISION, CACHE, BOTH;
  four V100 lanes; separate orchestrator and coding subjects in a VM; inference
  via the physical host LAN; existing vLLM installation is not to be changed.
- The current authoritative deployment uses measured A100 GPU2/GPU3 lanes on
  ports 18042/18043. Matching conditions run concurrently while complete
  Williams blocks remain balanced on each lane. GPUs 0-1/port 8000 are protected
  and out of scope.
- This kit supplies new implementation details (contracts, initial budgets,
  launcher/controller code, operational safety, judge controls and freeze).
  They require setup/smoke validation before the scientific protocol is frozen.

## Frozen product primary source

Repository: https://github.com/ulfe-lmi/slaif-local-coding
Source: ae6271318627703785f42de57d893c9be3b980c9
Merged record view: d0bf3a47eec6b52b0127f8cac5e483c8c0f5b13c/packaging/rc_record.json
Configuration law: src/slaif_local_coding/config.py at that source, including
loopback-only unsigned ingress, arbitrary validated HTTP(S) upstream, static
identity, compiler/constitution/route dependencies, and passthrough image limits.
The RC7 image was pulled by immutable digest and its source/wheel/Gateway labels
were verified in this VM. Merged ledger 005 and post-merge CI/CodeQL were also
verified. Prior RC2 identity and failed qualification evidence remain preserved
under their original identity; `config/product-rc2.json` is historical only.

## External primary documentation consulted 2026-09-22

- Codex CLI reference / slash commands:
  https://developers.openai.com/codex/cli/reference
  https://developers.openai.com/codex/cli/slash-commands
  Native /goal objectives attach to interactive chats; headless exec/resume
  is a separate documented path. Installed-version capability probes prevail.
- Codex non-interactive execution:
  https://developers.openai.com/codex/noninteractive
  JSON event output and resuming a specific session; not an invented --goal flag.
- vLLM Prometheus metrics:
  https://docs.vllm.ai/en/stable/design/metrics/
  Server counters/histograms and /metrics. Field availability is version-specific.
- NVIDIA nvidia-smi reference:
  https://docs.nvidia.com/deploy/nvidia-smi/index.html
  Read-only GPU query fields; some fields may be unsupported by a device/driver.
- Playwright Python Docker guide:
  https://playwright.dev/python/docs/docker
  Browser image/package compatibility and container execution guidance.

These live documents do not authorize upgrading the user's existing software
or imply that any model fits one V100. No new vLLM install recipe is included.
