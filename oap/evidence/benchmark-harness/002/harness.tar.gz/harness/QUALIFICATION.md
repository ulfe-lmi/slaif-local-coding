# Evidence required before a formal two-lane freeze

A healthy endpoint or green source test is not qualification. The corrected
candidate has one qualification campaign, executed on GPU2 and GPU3 in paired
waves. There is no additional serial-versus-parallel campaign.

| Check | Required evidence from the paired campaign |
|---|---|
| measured lanes | exact GPU2/GPU3 UUIDs and A100 identities; ports 18042/18043 and PID mapping; TP=1; port 8000 excluded |
| exact model/runtime | `qwen3.8-27b`, immutable Qwen3.8-27B-FP8 revision, vLLM 0.28.0+cu129, identical 262144 contexts and relevant flags |
| LAN routing | VM route plus health, authenticated models and metrics on both host-LAN endpoints; no remapping |
| protected API | unauthenticated model access fails on both without logging bodies or credentials |
| controller separation | controller uses neither measured endpoint and has no benchmark key |
| paired execution | at most one subject per GPU; matching condition on both lanes; distinct task seeds; both attempts preserved |
| Responses/tool loop | pinned Codex runs local commands and continues the same session on both lanes |
| model catalog | verbatim catalog in every fresh home; `xhigh`, 262144 context and 222000 compaction threshold observed by Codex |
| vision exposure | native model-directed image views on both lanes, not merely PNG creation |
| multi-image behavior | one/two-image behavior classified without changing treatment limits |
| governance/cache | root/delegated instructions observed; compiler, injection, reuse and reconstruction evidenced in CACHE/BOTH |
| metrics attribution | distinct per-endpoint before/after counters include compiler work; reset/missing behavior checked |
| client usage | paired same-session turns establish delta versus cumulative semantics |
| compaction | typed compaction events under fixed pressure; prose or token estimates do not count |
| context sequence | at least the control reaches the complete fixed pressure sequence and final fact query; early parser/upstream termination is a failed gate |
| judge controls | correct web/terminal/context fixtures accepted and defective fixtures rejected |
| judge barrier | no judge starts until both subjects stop and both endpoints drain |
| qualification dispatch | two different required workload cells run concurrently; every attempt and drain barrier recorded |
| endpoint exclusivity | recorder PID/load evidence for GPU2 and GPU3; no unrelated process on either measured GPU |
| shared host | synchronized `qualification-gpu23-01` samples cover both lanes plus protected GPU0-1 activity and host resources |
| recorder | actual timestamps, cadence distribution, scrape duration, required families and process attribution remeasured |
| clock alignment | host/VM offset and uncertainty measured around the campaign |
| isolation | fresh work/home, non-root, no Docker socket, judge, answer key, other run or secret-file mount |
| VM capacity | CPU/RAM and two simultaneous browser/subject processes observed |

## Normal qualification sequence

1. Offline regressions and immutable product/config parsing.
2. Model-free positive and negative judge controls.
3. Read-only preflight on both endpoints.
4. Paired bounded capability probes: the same text/tool/image probe starts on
   GPU2 and GPU3 together.
5. Paired web, terminal and context smoke blocks using the ordinary dispatcher.
   These runs simultaneously qualify workload behavior and concurrency.
6. Reconcile Codex events, endpoint counters, recorder windows, isolation,
   clock/cadence and judge results.

Every attempt receives a new ID and remains in the ledger. No hidden retry is
allowed. Ordinary subject/task failure is an outcome; infrastructure retry needs
a proven cause, preserved original, explicit rule and new ID.

## Publication boundary

Outcomes from the human-invalidated harness remain private. Once this corrected
campaign is complete and reconciled, its qualification and task outcomes may be
published as **preliminary results**, including failures, missing observations,
resource use and limitations. Qualification success still does not authorize a
pilot.

## Freeze boundary

Do not freeze until all required checks are backed by the exact dual-lane site
and evidence files. Freeze code, site, catalog, product/worker images, runtime,
tasks, judges, schedule semantics, budgets and evidence—never credentials.
The formal schedule is validated separately for counterbalanced per-lane order;
qualification does not repeat a full formal Williams cycle. Formal
pilot/main/extension dispatch then needs one human approval binding the
exact freeze hash, canonical paired schedule fingerprint, allowed wave IDs,
parallelism two, expiry and retry policy.
