# SLAIF standalone coding benchmark kit

**Independent benchmark, separate VM, no SLAIF API Gateway, immutable product RC.**

This package prepares and dispatches paired Codex coding sessions against two
independent one-GPU vLLM endpoints on physical GPU2 and GPU3. Each concurrent
wave runs the same condition on both lanes; each lane retains complete
four-condition blocks in counterbalanced order.
It does not install, update, patch, or reconfigure vLLM, CUDA, drivers, models,
or existing host services. Host scripts default to read-only attachment.

## Start here

1. Read [SETUP.md](SETUP.md) and [EXPERIMENTAL_PROTOCOL.md](EXPERIMENTAL_PROTOCOL.md).
2. Start the orchestration Codex in this directory with
   [ORCHESTRATOR_PROMPT.md](ORCHESTRATOR_PROMPT.md). Root [AGENTS.md](AGENTS.md)
   is its constitution; subject instructions live separately under `tasks/`.
3. Fill a new dual-lane site record from the example using the actual host LAN
   address, GPU2/GPU3 ports and UUIDs, model/runtime facts and frozen subject
   toolbox. Never overwrite the invalidated single-lane site record.
4. Qualify the environment, judges and a bounded smoke before freezing anything.
5. Dispatch only the human-authorized stage. No benchmark has run merely because
   a schedule or a freeze record exists.

## Conditions

| Arm | Image-history workaround | Governance/cache/reinjection | Path |
|---|---|---|---|
| DIRECT | No | No | Codex -> host LAN vLLM |
| VISION | Yes | No | Codex -> VM-loopback adapter -> host LAN vLLM |
| CACHE | No (passthrough) | Yes | Same adapter path |
| BOTH | Yes | Yes | Same adapter path |

`DIRECT` is not an adapter-with-neither-features factorial cell: transport is
also removed. `BOTH/CACHE` isolates adding vision within the adapter;
`BOTH/VISION` isolates adding governance/cache within the adapter.

## Workloads

- [Web Minesweeper](tasks/web/ARCHITECTURE.md): full app, Playwright screenshots
  AND model image viewing, functional judge and blinded visual rubric.
- [Terminal Minesweeper](tasks/terminal/ARCHITECTURE.md): Python curses, PTY
  interaction, no browser or vision.
- [Long-context fact recovery](tasks/context/ARCHITECTURE.md): retained original
  third task, fixed pressure phases and 16 root/delegated governance facts.
  This is a separate context task, not a third coding application. It can be
  deselected before freezing if the first campaign is the two coding tasks only.

## Package map

`AGENTS.md`, `ARCHITECTURE.md`, `ORCHESTRATOR_PROMPT.md`, `ORCHESTRATOR_GOAL.txt`:
controller instructions. `tasks/*/`: clean task seeds, architecture, coding
prompts, goals and native `/goal` text. `benchkit/`: executable controller,
scheduling, config rendering, measurements, host attachment and analysis.
`host/`: existing-vLLM attachment checker and read-only GPU/vLLM recorder.
`evaluators/`: withheld judges and visual rubric, never mounted during coding.
`tests/`: offline tests and deliberately good/bad judge controls.
`worker/`: benchmark subject toolbox only; not vLLM or the product image.
`config/qwen-neumann-models.json`: verbatim custom Codex metadata copied into
every fresh worker home. Subject reasoning is fixed to `xhigh`; apps, MCP apps
and plugins are disabled.
`KIT_IDENTITY_GPU23.json`: current pre-freeze dual-lane candidate identity; the
earlier kit identities and invalidated evidence remain unchanged.

## Frozen product

```
0.1.0-rc7
source: ae6271318627703785f42de57d893c9be3b980c9
ghcr.io/ulfe-lmi/slaif-local-coding@sha256:a3782915da58a403fd0f7991c57f9954b07bfb9377e4730715c0fb7398f901db
```

Identity is in [config/product-rc7.json](config/product-rc7.json). Pull, do not
rebuild. Experiment configs are separate mounted inputs and are hashed per run.
The product image uses VM-host networking; its upstream address is the GPU
host's LAN IP, never the VM's `127.0.0.1`. This differs from the product's
same-host installation example and must pass the VM-side smoke.

## Execution and goals

Native `/goal` text is supplied for the controller and every subject task.
The automatic dispatcher uses explicit `codex exec --json` and **same-session
resume** with fixed continuation prompts and budgets. It does not pretend that
sending `/goal` as an exec prompt invokes the interactive slash command. See
[CODEX_DRIVER.md](CODEX_DRIVER.md). Do not mix drivers within a campaign.

## Validation boundary

Historical validation-result files are withheld from this public archive; run the current offline suite locally.
Your existing vLLM binaries, GPU2/GPU3, GHCR permissions, installed Codex wire
format and full VM/browser execution must be qualified on your infrastructure.
Nothing in this archive certifies an unobserved GPU/model configuration.
