# Blinded browser-game visual evaluation

Score post-run evaluator screenshots, not the subject's chosen screenshots.
Shuffle and anonymize filenames with scripts/blind_visuals.py. Hide condition,
lane, success, token cost and run duration from raters. Use two independent
raters where possible. Resolve disagreements using the same fixed rubric;
report inter-rater agreement and each original score.

Five dimensions, each 0..4:
1. Hierarchy and typography: readable primary actions, board/status distinction.
2. Spacing and alignment: consistent grid, padding, responsive structure.
3. State communication: cells, flags, numbers, win/loss and focus distinguishable.
4. Coherent visual design: palette, contrast, restraint, integrated controls.
5. Mobile usability: no unusable clipping, readable board, usable touch controls.

Anchors: 0 absent/unusable; 1 substantial faults; 2 adequate; 3 good;
4 notably polished with no material observed defect. Total /20.
Predeclared aesthetic threshold: >=14/20 AND no dimension below 2.
A screenshot cannot prove keyboard accessibility or interaction correctness;
those are separate functional tests. Missing rating is NULL, not zero.
Report functional success and visual success separately, then a joint
browser-task success outcome requiring both. Do not reward fewer tokens for
an incomplete or unusable game.

## Machine-readable rating collection
Each anonymous case has rating.json. Give copies to independent raters without
the private mapping. Each fills rater and all five integer scores. Keep each
rater's directory separately. The supplied merger uses the predeclared equal-
rater mean per dimension, total >=14 and all dimension means >=2. Preserve raw
scores and report disagreement; changing aggregation requires a pre-main
protocol decision. It writes visual-rating.json without rewriting functional
judgments. Missing ratings remain unavailable.
