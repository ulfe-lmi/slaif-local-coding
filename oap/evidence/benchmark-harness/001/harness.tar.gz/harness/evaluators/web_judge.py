#!/usr/bin/env python3
from __future__ import annotations
import argparse,contextlib,json,os,random,socket,subprocess,time
from pathlib import Path
from oracle import Board

class JudgeInfrastructureError(RuntimeError):
    pass


def judge(work: Path,out: Path) -> dict:
    from playwright.sync_api import sync_playwright
    checks=[];console=[];server=None
    def check(name,fn):
        try: fn();checks.append({'check':name,'passed':True})
        except Exception as e:checks.append({'check':name,'passed':False,'error_type':type(e).__name__,'detail':str(e)[:300]})
    def require(test,msg):
        if not test:raise AssertionError(msg)
    with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    try:
        server=subprocess.Popen(['python3','-m','http.server',str(port),'--bind','127.0.0.1'],cwd=work,
                                stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        time.sleep(.4)
        with sync_playwright() as pw:
            launch_args={'headless':True}
            if os.environ.get('BENCH_CHROMIUM_EXECUTABLE'):
                launch_args['executable_path']=os.environ['BENCH_CHROMIUM_EXECUTABLE']
            try: browser=pw.chromium.launch(**launch_args)
            except Exception as exc: raise JudgeInfrastructureError("Chromium could not launch") from exc
            # The override is for explicit local judge-control validation only.
            # Official runs use the frozen worker's bundled Chromium.
            page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
            page.set_default_timeout(3000)
            page.on('pageerror',lambda e:console.append(str(e)[:200]))
            try: page.goto(f'http://127.0.0.1:{port}/?test=1',wait_until='networkidle',timeout=15000)
            except Exception as exc:
                if 'ERR_BLOCKED_BY_ADMINISTRATOR' in str(exc): raise JudgeInfrastructureError('Browser environment blocks local test pages') from exc
                raise
            page.wait_for_function('window.__MS_TEST__ && typeof window.__MS_TEST__.reset === "function"',timeout=5000)
            def reset(rows,cols,mines):
                page.evaluate('(x)=>window.__MS_TEST__.reset(x)',{'rows':rows,'cols':cols,'mines':mines})
                return Board(rows,cols,mines)
            def state_check(board):
                state=page.evaluate('window.__MS_TEST__.state()')
                require(not board.check(state),'state differs: '+','.join(board.check(state)))
                for r in range(board.rows):
                    for c in range(board.cols):
                        el=page.get_by_test_id(f'cell-{r}-{c}')
                        require(el.count()==1,'unique cell selector missing')
                        p=(r,c)
                        expected='flagged' if p in board.flagged else 'mine' if p in board.revealed&board.mines else 'revealed' if p in board.revealed else 'hidden'
                        require(el.get_attribute('data-state')==expected,'DOM state differs')
                        if expected=='revealed':require(el.get_attribute('data-count')==str(board.count(p)),'DOM count differs')
            def basic():
                b=reset(3,3,[[0,0]]);state_check(b)
                page.get_by_test_id('cell-0-1').click();b.reveal((0,1));state_check(b)
            check('reveal_and_neighbors',basic)
            def flags():
                b=reset(3,3,[[0,0]])
                page.get_by_test_id('cell-0-0').click(button='right');b.flag((0,0));state_check(b)
                page.get_by_test_id('cell-0-0').click();b.reveal((0,0));state_check(b)
                page.get_by_test_id('cell-0-0').click(button='right');b.flag((0,0));state_check(b)
            check('flag_unflag_and_protected_reveal',flags)
            def loss():
                b=reset(3,3,[[0,0]]);page.get_by_test_id('cell-0-0').click();b.reveal((0,0));state_check(b)
                page.get_by_test_id('cell-1-1').evaluate('(el)=>el.click()');b.reveal((1,1));state_check(b)
            check('loss_and_terminal_board',loss)
            def win():
                b=reset(3,3,[[0,0]]);page.get_by_test_id('cell-2-2').click();b.reveal((2,2));state_check(b)
                require(b.status=='won','oracle fixture must flood to win')
            check('flood_and_win',win)
            def randomized():
                rng=random.Random(602211)
                for _ in range(4):
                    mines=[list(divmod(x,5)) for x in rng.sample(range(25),4)]
                    b=reset(5,5,mines)
                    # Mix flags and safe reveals, then force a terminal case.
                    for n in range(20):
                        if b.status in ('won','lost'): break
                        cell=(rng.randrange(5),rng.randrange(5));isflag=n%3==0
                        page.get_by_test_id(f'cell-{cell[0]}-{cell[1]}').click(button='right' if isflag else 'left')
                        b.flag(cell) if isflag else b.reveal(cell);state_check(b)
            check('independent_randomized_rule_sequences',randomized)
            def restart():
                page.get_by_test_id('new-game').click()
                state=page.evaluate('window.__MS_TEST__.state()')
                require(state['status']=='ready' and not state['revealed'] and not state['flagged'],'restart not clean')
            check('restart',restart)
            def sizes():
                for name,r,c,n in [('beginner',9,9,10),('intermediate',16,16,40),('expert',16,30,99)]:
                    page.get_by_test_id('difficulty').select_option(name)
                    state=page.evaluate('window.__MS_TEST__.state()')
                    require((state['rows'],state['cols'],state['mine_count'])==(r,c,n),'difficulty wrong')
            check('difficulty_sizes',sizes)
            check('no_browser_errors',lambda:require(not console,'browser errors seen'))
            # Post-run evaluator screenshots are NOT subject images/token usage.
            page.goto(f'http://127.0.0.1:{port}/',wait_until='networkidle')
            page.screenshot(path=str(out/'desktop.png'))
            page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(out/'mobile.png'))
            browser.close()
    finally:
        if server:
            server.terminate()
            with contextlib.suppress(subprocess.TimeoutExpired):server.wait(timeout=5)
            if server.poll() is None:server.kill()
    return {'status':'SCORED','functional_success':all(x['passed'] for x in checks) and bool(checks),
            'functional_passed':sum(x['passed'] for x in checks),'functional_total':len(checks),'checks':checks,
            'visual_score':None,'visual_status':'BLINDED_RATING_REQUIRED','judge_screenshots_are_excluded_from_run_metrics':True}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--work',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    path=Path(a.output);path.parent.mkdir(parents=True,exist_ok=True)
    try:r=judge(Path(a.work),path.parent)
    except (ImportError,JudgeInfrastructureError) as e:r={'status':'JUDGE_INFRASTRUCTURE_ERROR','error_type':type(e).__name__}
    except Exception as e:r={'status':'SCORED','functional_success':False,'functional_passed':0,'functional_total':8,'error_type':type(e).__name__}
    path.write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':main()
