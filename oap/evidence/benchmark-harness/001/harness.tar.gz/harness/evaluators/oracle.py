"""Independent tiny Minesweeper rule oracle, NEVER copied into subject workspaces."""
from __future__ import annotations
from collections import deque

class Board:
    def __init__(self,rows,cols,mines):
        self.rows=rows;self.cols=cols;self.mines={tuple(x) for x in mines}
        self.revealed=set();self.flagged=set();self.status='ready'
    def neighbors(self,p):
        r,c=p
        return {(a,b) for a in range(max(0,r-1),min(self.rows,r+2))
                for b in range(max(0,c-1),min(self.cols,c+2)) if (a,b)!=p}
    def count(self,p): return len(self.neighbors(p)&self.mines)
    def flag(self,p):
        p=tuple(p)
        if self.status in ('won','lost') or p in self.revealed: return
        if p in self.flagged:self.flagged.remove(p)
        else:self.flagged.add(p)
    def reveal(self,p):
        p=tuple(p)
        if self.status in ('won','lost') or p in self.flagged or p in self.revealed:return
        if p in self.mines:
            self.revealed.add(p);self.status='lost';return
        self.status='playing';q=deque([p])
        while q:
            x=q.popleft()
            if x in self.revealed or x in self.flagged or x in self.mines:continue
            self.revealed.add(x)
            if not self.count(x):q.extend(self.neighbors(x)-self.revealed-self.mines)
        if len(self.revealed-self.mines)==self.rows*self.cols-len(self.mines):self.status='won'
    def expected(self):
        return {'rows':self.rows,'cols':self.cols,'mine_count':len(self.mines),'status':self.status,
                'revealed':sorted(self.revealed),'flagged':sorted(self.flagged),
                'visible_numbers':{f'{r},{c}':self.count((r,c)) for r,c in self.revealed-self.mines}}
    def check(self,state):
        expected=self.expected();errors=[]
        for k in ('rows','cols','mine_count','status'):
            if state.get(k)!=expected[k]:errors.append(k)
        for k in ('revealed','flagged'):
            try:got={tuple(x) for x in state[k]}
            except (KeyError,TypeError):got=None
            if got!=set(expected[k]):errors.append(k)
        if state.get('visible_numbers')!=expected['visible_numbers']:errors.append('visible_numbers')
        return errors
