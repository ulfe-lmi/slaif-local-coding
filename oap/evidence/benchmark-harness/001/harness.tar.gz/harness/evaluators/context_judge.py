#!/usr/bin/env python3
import argparse,json
from pathlib import Path

def score(data,key):
    rows=data.get('facts',[]) if isinstance(data,dict) else []
    if not isinstance(rows,list):rows=[]
    ids=[r.get('id') for r in rows if isinstance(r,dict)]
    got={r.get('id'):r for r in rows if isinstance(r,dict)}
    checks=[]
    for expected in key['facts']:
        ident=expected['id'];actual=got.get(ident,{})
        unique=ids.count(ident)==1
        checks.append({'id':ident,'correct_value':unique and str(actual.get('value'))==str(expected['value']),
                       'correct_source':unique and actual.get('source')==expected['source']})
    joint=sum(x['correct_value'] and x['correct_source'] for x in checks)
    return {'status':'SCORED','functional_success':joint==len(checks),'facts_correct_with_source':joint,
            'facts_total':len(checks),'checks':checks,'unexpected_ids':sorted(str(k) for k in got if k not in {x['id'] for x in key['facts']})}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--work',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    p=Path(a.work)/'facts.json';key=json.loads((Path(__file__).parent/'context_answer_key.json').read_text())
    try:
        if p.is_symlink() or p.stat().st_size>1048576:raise ValueError('unsafe answer file')
        data=json.loads(p.read_text())
    except (OSError,ValueError):data={}
    Path(a.output).write_text(json.dumps(score(data,key),indent=2)+'\n')
if __name__=='__main__':main()
