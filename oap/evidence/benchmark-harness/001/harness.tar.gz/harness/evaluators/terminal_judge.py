#!/usr/bin/env python3
from __future__ import annotations
import argparse,contextlib,json,os,time
from pathlib import Path
from oracle import Board

def judge(work:Path,out:Path)->dict:
    import pexpect,pyte
    state_path=out/'terminal-state.json';checks=[]
    def check(name,fn):
        try:fn();checks.append({'check':name,'passed':True})
        except Exception as e:checks.append({'check':name,'passed':False,'error_type':type(e).__name__,'detail':str(e)[:250]})
    def session(actions):
        with contextlib.suppress(FileNotFoundError):state_path.unlink()
        env=os.environ.copy();env['TERM']='xterm-256color'
        child=pexpect.spawn('python3',['-m','minesweeper','--rows','3','--cols','3','--mines','1',
          '--test-layout','0,0','--state-file',str(state_path)],cwd=str(work),env=env,
          encoding='utf-8',timeout=4,dimensions=(24,80))
        screen=pyte.Screen(80,24);stream=pyte.Stream(screen);b=Board(3,3,[[0,0]]);cursor=[0,0]
        def drain():
            end=time.monotonic()+.3
            while time.monotonic()<end:
                try:stream.feed(child.read_nonblocking(65536,timeout=.05))
                except pexpect.TIMEOUT:pass
                except pexpect.EOF:break
        def verify():
            drain()
            state=json.loads(state_path.read_text())
            errors=b.check(state)
            if errors:raise AssertionError('diagnostic state differs: '+','.join(errors))
            if state.get('cursor')!=cursor:raise AssertionError('cursor differs')
            for r in range(3):
                for c in range(3):
                    p=(r,c);expected='F' if p in b.flagged else '*' if p in b.revealed&b.mines else (str(b.count(p)) if b.count(p) else '.') if p in b.revealed else '#'
                    if screen.display[2+r][c]!=expected:raise AssertionError('PTY board differs from oracle')
            if b.status.upper() not in '\n'.join(screen.display):raise AssertionError('status missing on terminal')
        try:
            until=time.monotonic()+4
            while not state_path.exists() and time.monotonic()<until:drain()
            verify()
            for key in actions:
                child.send(key)
                if key=='r':b=Board(3,3,[[0,0]]);cursor=[0,0]
                elif b.status not in ('won','lost'):
                    if key=='h':cursor[1]=max(0,cursor[1]-1)
                    elif key=='l':cursor[1]=min(2,cursor[1]+1)
                    elif key=='j':cursor[0]=min(2,cursor[0]+1)
                    elif key=='k':cursor[0]=max(0,cursor[0]-1)
                    elif key=='f':b.flag(cursor)
                    elif key==' ':b.reveal(cursor)
                verify()
            child.send('q');child.expect(pexpect.EOF);child.close()
            if child.exitstatus!=0:raise AssertionError('nonzero exit on quit')
        finally:
            if child.isalive():child.terminate(force=True)
    check('movement_reveal_neighbors',lambda:session('l '))
    check('flags_and_protected_reveal',lambda:session('f f'))
    check('loss_and_restart',lambda:session(' r'))
    check('flood_win_and_restart',lambda:session('lljj r'))
    check('quit_from_initial_state',lambda:session(''))
    return {'status':'SCORED','functional_success':all(x['passed'] for x in checks),
            'functional_passed':sum(x['passed'] for x in checks),'functional_total':len(checks),'checks':checks}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--work',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    p=Path(a.output);p.parent.mkdir(parents=True,exist_ok=True)
    try:r=judge(Path(a.work),p.parent)
    except ImportError as e:r={'status':'JUDGE_INFRASTRUCTURE_ERROR','error_type':type(e).__name__}
    except Exception as e:r={'status':'SCORED','functional_success':False,'error_type':type(e).__name__}
    p.write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':main()
