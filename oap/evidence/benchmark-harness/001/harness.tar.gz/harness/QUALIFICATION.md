# Evidence required before a formal freeze

A healthy endpoint, source validator or old CI result is not full qualification.
Every check below needs evidence from this VM and the exact frozen inputs.

| Check | Required evidence |
|---|---|
| one measured GPU lane | GPU3 UUID, A100-SXM4-80GB identity, port 18043/PID mapping and TP=1; port 8000 excluded |
| exact model/runtime | `qwen3.8-27b`, immutable Qwen3.8-27B-FP8 checkpoint/revision, vLLM 0.28.0+cu129, 262144 context and relevant flags |
| LAN routing | VM route plus GET `/health`, authenticated `/v1/models` and authenticated `/metrics` at `192.0.2.195:18043`; no remapping |
| protected API | unauthenticated protected model API fails without logging body or credential |
| controller separation | controller config does not use port 18043 and has no benchmark key |
| Responses/tool loop | pinned subject Codex runs a local command and continues in the same session through lane 0 |
| vision exposure | native image-view produces model-directed image evidence, not merely a PNG file |
| multi-image capacity | one-image and accumulated/two-image behavior classified without changing arm limits |
| governance/cache activation | root/delegated instructions observed, compiler succeeds, governance injects, later turn reuses or reconstructs |
| metrics attribution | before/after counters include compiler work; semantics and reset/missing behavior checked |
| client usage semantics | known two-turn/resume calibration distinguishes per-turn from session-cumulative values |
| driver behavior | exact exec/resume ID continuity, bounds, termination and image/tool event shapes |
| compaction signals | actual typed events under calibrated context pressure; estimates are not events |
| judge controls | correct web/terminal/context fixtures accepted and defective fixtures rejected |
| sequential design | one active subject only; condition order and previous condition recorded; drain before next run |
| carryover | bounded counterbalanced calibration and prefix-cache/warm-state metrics reviewed; no backend reset |
| GPU3 exclusivity | ownership/lease plus before/during/after PID/load evidence; no unrelated GPU3 process |
| shared-host contamination | all-GPU and host telemetry reviewed against a predeclared acceptance criterion |
| recorder coverage | actual timestamps, cadence distribution, scrape duration, required families and process attribution remeasured |
| clock alignment | host/VM offsets and uncertainty measured around qualification/campaign windows |
| subject isolation | only fresh `/work` and home mounted; non-root; no Docker socket, judges, other runs or host secret file |
| VM capacity | CPU/RAM/browser behavior observed for the one-subject design |

## Order and carryover

Schedules use randomized Williams orders in four-block cycles. Across each cycle,
every condition appears once in each sequence position and every directed
first-order transition occurs once. This controls known order structure but does
not make backend warm state disappear. Record order, prefix-cache counters and
shared-host activity, and include order/predecessor sensitivity in analysis.

Backend caches are never flushed. Every run recreates the subject, workspace,
Codex home, browser, adapter and adapter cache. These are cold adapter-cache runs
on the backend's existing sequential warm state.

## Explicit NOT RUN boundary

Offline tests, config parsing and read-only preflight are not inference evidence.
Until the human explicitly authorizes bounded inference in this VM session, do
not call `/responses`, chat/completions, Codex through lane 0, capability probes,
smokes or context pressure. Prepared commands and schedules do not authorize them.

## Calibrating corpus and budgets

Pressure bytes are not tokens. Calibrate the fixed pressure sequence against the
selected tokenizer/context and require typed compaction events. Preserve the same
workload across arms. Make web vision actual with screenshot -> image view ->
later screenshot/crop in the same history. When event fields are unavailable,
retain raw private events and report NULL rather than modifying the product.

## Judge controls and code corrections

Run positive and defective fixtures in the exact subject toolbox with no model
calls. A failed control blocks scoring. Pre-freeze harness defects may be fixed
with regression tests and a new kit identity. After freeze, substantive changes
require a new protocol/freeze; prior evidence keeps its original identity.
