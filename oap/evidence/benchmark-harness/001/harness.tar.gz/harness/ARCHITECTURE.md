# Benchmark system architecture — single measured lane

## Physical topology

```
PHYSICAL GPU HOST 192.0.2.195
  protected DP3 service -> GPUs 0-2 -> port 8000 (out of scope)
  benchmark vLLM replica -> GPU3 A100-SXM4-80GB -> LAN:18043
  existing read-only recorder -> all four GPUs + port 18043 metrics
  |
  +-- TESTING VM 192.0.2.112
       controller Codex (separate model, never port 18043)
       one fresh subject container at a time
       optional standalone adapter -> VM 127.0.0.1:18143
       adapter upstream -> 192.0.2.195:18043/v1
       subject web app -> VM 127.0.0.1:18243
       independent evaluator only after generation and backend drain
```

There is one measured lane, numbered 0 in the harness and physically mapped to
GPU3 UUID `GPU-REDACTED-BENCHMARK-LANE`. Port 8000 and GPUs 0-2 are
not benchmark lanes. No tunnel, vsock, port forwarding, loopback remapping or
Gateway is part of the data path.

## Sequential blocked design

Each task/block contains DIRECT, VISION, CACHE and BOTH exactly once. The four
runs execute serially on lane 0. Randomized Williams orders balance condition
position and directed first-order predecessor transitions within every
four-block cycle. Each block records its condition order, sequence position and
previous condition. This reduces but cannot eliminate backend warm-state and
shared-host carryover, so order and telemetry remain analysis covariates.

Every run gets a fresh task workspace, Codex home, browser process, adapter,
adapter tmpfs cache and unique static session identity. The dispatcher waits for
backend running/waiting gauges to reach zero after a run before the next run.
A broken measurement, protocol violation or shared infrastructure fault stops
the block. Judges start only after generation has stopped and drain checks have
completed for all attempted runs.

## Data and control planes

Control: human -> controller -> Python dispatcher -> isolated subject Codex.
Data: subject -> GPU3 directly (DIRECT), or subject -> VM-loopback adapter ->
GPU3 (VISION/CACHE/BOTH). Measurement: native Codex events, VM metrics snapshots
and the existing host recorder. Judging: frozen evaluators with no model key and
no active subject generation.

## Identity and isolation

The product OCI digest is immutable. Source commit and wheel labels are checked;
experiment TOML is generated separately and hashed per run. Subjects are
non-root, capability-dropped containers with only fresh `/work` and home mounts,
no Docker socket, controller, evaluators, answer keys, other attempts or host
secret file. The backend key is injected only into the worker environment (for
DIRECT) or adapter environment and is never mounted into the subject workspace.

Host networking is used so subjects can reach VM-loopback adapters and app
ports. It is not hostile-workload network isolation. Only synthetic cooperative
tasks are in scope.

## Shared-host limitation

GPU3 is the only measured accelerator, but GPUs 0-2 share host CPU, RAM, PCIe,
storage and network and may run the protected DP3 service. The recorder must
capture all four GPUs and numeric host metrics throughout measured intervals.
Background activity is contamination evidence to review, not another lane and
not proof of exclusivity. An acceptance criterion must be predeclared before
freeze.

## Lifecycle

`DRAFT -> INVENTORIED -> QUALIFYING -> QUALIFIED -> FROZEN ->`
`HUMAN_STAGE_APPROVED -> PREPARED -> BLOCK_RUNNING -> BLOCK_DRAINED ->`
`GRADED -> RECONCILED -> next approved block OR STAGE_COMPLETE`.

Any measurement/infrastructure problem enters a blocked reconciliation state.
There is no automatic retry; an allowed infrastructure retry needs a new
attempt ID and explicit linkage.

## Components

- `schedule.py`: randomized Williams condition orders for one serial lane.
- `configurations.py`: the four frozen condition configurations.
- `runner.py`: fresh per-run state, serial dispatch, drain gates and judging.
- `metrics.py`: allowlisted Prometheus snapshots/deltas and reset handling.
- `host_lanes.py`: read-only attachment validation for GPU3.
- `recorder.py`: actual GPU discovery and host/vLLM sampling.
- `evaluators/`: independent browser, PTY and context judges.
- `analysis.py`: per-task/stage results, paired block effects and order fields.

## Non-goals

No product modifications, Gateway evaluation, host-service management, vLLM or
GPU-stack installation, backend cache reset, model tuning, use of port 8000,
claim of four-lane balancing, or automatic promotion to a formal stage.
