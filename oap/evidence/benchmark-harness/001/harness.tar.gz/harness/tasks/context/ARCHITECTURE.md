# Long-session audit and fact recovery
This is a context-stress task, not a third Minesweeper application.
Each supplied phase is a synthetic record-audit problem. Check its records,
write a compact phase summary under results/, and continue in the SAME session.
Do not open a new session to avoid long-context behavior. Context compactions
may happen naturally; read governing files again when needed.
On the final request, write facts.json as:
{"facts": [{"id": "release_channel", "value": "...", "source": "AGENTS.md"}, ...]}.
No external facts are needed. The source path must be the file actually owning
the fact, relative to /work. Do not guess a source from the fact's name.
