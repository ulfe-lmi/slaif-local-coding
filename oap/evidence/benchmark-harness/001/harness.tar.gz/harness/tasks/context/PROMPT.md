Read the governing repository files and prepare for the sequence of synthetic
data-audit phases. Complete phases in this same conversation and write each
short result under results/. Later you will be asked for exact governance facts.
Do not answer the final fact questions until that final request arrives.
