# Gamma governance

These exact facts are owned by this file.
- gamma_output_format = jsonl-v2
- gamma_retention_days = 29
- gamma_marker = silver-reed
