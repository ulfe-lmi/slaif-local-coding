# Alpha governance

These exact facts are owned by this file.
- alpha_retry_limit = 5
- alpha_region = north-basin
- alpha_checksum = birch-41
