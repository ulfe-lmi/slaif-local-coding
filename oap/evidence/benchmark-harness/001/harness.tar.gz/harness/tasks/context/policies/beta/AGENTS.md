# Beta governance

These exact facts are owned by this file.
- beta_queue_mode = strict-fifo
- beta_timeout_seconds = 73
- beta_owner = harbor-reviewer
