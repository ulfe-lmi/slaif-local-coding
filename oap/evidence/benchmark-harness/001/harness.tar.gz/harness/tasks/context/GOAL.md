Complete every supplied audit phase in the same session. On the final fact request recover the exact facts and source paths into facts.json. Rereading governance is permitted; do not guess.
