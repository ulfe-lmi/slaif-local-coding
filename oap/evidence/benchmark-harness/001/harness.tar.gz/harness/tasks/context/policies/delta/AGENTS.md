# Delta governance

These exact facts are owned by this file.
- delta_batch_size = 11
- delta_clock_policy = monotonic-first
- delta_fallback = manual-hold
