Complete the browser Minesweeper deliverable described by AGENTS.md,
ARCHITECTURE.md and PROMPT.md. Keep implementing, testing, viewing Playwright
screenshots and repairing defects until the game is functionally correct,
visually polished and the required visual rounds are complete. Do not stop at
a scaffold or a plan. Respect the controller's budget and all safety boundaries.
Record an honest SUBMISSION.json when finished or a precise external blocker.
