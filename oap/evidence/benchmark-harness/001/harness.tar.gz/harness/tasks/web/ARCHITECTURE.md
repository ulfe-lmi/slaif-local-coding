# Browser Minesweeper architecture and acceptance contract

## Deliverable
Build a polished, responsive, accessible Minesweeper game, not a demo scaffold.
Files: `index.html`, local CSS/JavaScript as needed, `README.md`, your own tests,
`artifacts/visual/`, and final `SUBMISSION.json`. No server-side application or
framework is required. No external fonts/CDNs/network requests. Serve with:

```bash
python3 -m http.server <app_port from runtime.json> --bind 127.0.0.1
```

Separate pure board/rule logic from DOM rendering and event handling. Keep game
state explicit. The same real game logic must serve normal play and test mode.

## Game requirements
Default Beginner 9x9/10 mines; Intermediate 16x16/40; Expert 16x30/99.
Left click reveals; right click toggles flags without a browser context menu;
keyboard-accessible cells; a mobile flag mode; zero-cell flood reveal;
correct adjacent-mine counts; win after all non-mine cells are revealed;
loss on mine; no board mutation after win/loss except new game; new game and
restart reset state and timer. Random games have a safe first reveal.
Mine counter must not become nonsensical. Explain controls visibly.

Visual design: strong hierarchy, coherent spacing/type/color, clear states,
legible numbers, usable touch targets, responsive overflow handling, visible
focus, compact helpful status. Do not confuse decorative polish with correctness.

## Stable interaction contract (not an implementation)
Use DOM `data-testid` values:
- `new-game`: button resetting the current difficulty.
- `difficulty`: select with values `beginner`, `intermediate`, `expert`.
- `board`: board container; each cell is a button.
- `cell-<row>-<col>`: zero-based board cell buttons.
- `status`: text containing Ready/Playing/Won/Lost as appropriate.
- `timer`: readable elapsed seconds.
Cells expose `data-state="hidden|flagged|revealed|mine"`.
Revealed safe cells expose `data-count="0".."8"`. Coordinates never shift.

For evaluation URL `/?test=1` ONLY, expose `window.__MS_TEST__`:
- `reset({rows, cols, mines})`, where mines is an explicit list of `[row,col]`.
  It resets the SAME engine and DOM; forced boards do NOT relocate the first
  mine (the test must be able to check loss deterministically).
- `state()` returns a JSON object with `rows`, `cols`, `mine_count`,
  `status` (`ready|playing|won|lost`), sorted or unsorted coordinate lists
  `revealed`, `flagged`, and `visible_numbers` mapping `"r,c"` to count.
No mine layout is leaked to ordinary play. Do not special-case known sequences.

## Required visual workflow
Use the preinstalled Playwright browser automation and screenshot helper below.
Read `runtime.json`. Launch your application, then:
```bash
python3 /opt/bench-tools/capture.py --url http://127.0.0.1:<port>/ \
  --output artifacts/visual/01-desktop.png --width 1440 --height 900
```
View that PNG with Codex's image-view tool, describe specific problems, fix them,
and capture/view another state. Also capture/view mobile at 390x844.
The helper's `--crop x y width height` produces a later crop for image-history
exercise. Do not delete prior image context, combine images into a workaround,
or avoid required image viewing because the model/backend rejects images.
Report such a failure honestly; do not alter the testing setup.

Write your own logic tests and run them. Check browser console errors, clicks,
flags, loss, win and responsive layout. The external judge remains separate.

## Forced-board diagnostic detail
In the explicit test interface, `revealed` contains only cells actually revealed
by clicks/flood expansion. On loss it adds the triggered mine, not every mine.
Decorative reveal of other mines may be shown separately in normal play, but
the forced-board DOM/PTY and diagnostic state follow this exact contract.
Flags do not start play or change `ready` to `playing`; a safe reveal does.
Restarting a forced board keeps its layout and resets all reveal/flag state.
