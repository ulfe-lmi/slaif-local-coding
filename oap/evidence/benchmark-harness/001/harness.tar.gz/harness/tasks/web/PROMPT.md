Create a genuinely good-looking, fully functional browser Minesweeper game in
this repository. Follow AGENTS.md and ARCHITECTURE.md, including the stable
interaction/test contract. Implement the complete game, self-test it, use
Playwright screenshots AND actually view those screenshots to improve the UI.
Perform the required desktop/update/mobile/crop inspection sequence. Continue
working through implementation and repairs until the requirements are met or
an actual external blocker prevents progress. Finish with an honest submission.
