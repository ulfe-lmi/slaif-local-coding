Build a complete, usable ncurses Minesweeper game in Python in this repository.
Follow AGENTS.md and ARCHITECTURE.md. Implement the engine and real terminal UI,
exercise it through a PTY, write/run your own tests, and repair any defects.
Do not use a browser, Playwright, screenshots or vision. Keep working until
requirements are met or an actual external blocker is established, then submit.
