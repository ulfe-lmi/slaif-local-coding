Finish the terminal Minesweeper package required by AGENTS.md, ARCHITECTURE.md
and PROMPT.md. Implement, test through a real PTY, fix and repeat until movement,
reveal, flood, flags, win/loss, restart, quit and terminal restoration work.
Do not stop after a plan or scaffold. No vision or browser tools. Stay within
the controller's finite budget and record an honest SUBMISSION.json.
