# ncurses Minesweeper architecture and acceptance contract

## Deliverable
Create Python package `minesweeper/` runnable by `python3 -m minesweeper`.
Use Python standard-library `curses`, no third-party app dependencies.
Separate the rule engine from curses rendering/input; include your own tests
and a concise README. It must be a real interactive terminal application.

## Rules
Default 9x9/10 mines, support `--rows`, `--cols`, `--mines`, `--seed`.
Arrow keys or h/j/k/l move cursor; Space or Enter reveals; f toggles flag;
r restarts; q quits. Do not reveal flagged cells. Flood zero cells; correct
neighbor counts; win after all safe cells revealed; loss on mine; after
win/loss permit restart/quit but no further game moves. Random boards have a
safe first reveal. Handle a small terminal politely and restore terminal mode
on quit and exceptions. Display status, mine count and controls.

## Terminal representation
A board begins at screen row 2, column 0, with ONE cell character per column.
Hidden=`#`, flagged=`F`, revealed zero=`.`, counts=`1`..`8`, mine=`*`.
The cursor must be visibly highlighted without replacing the cell character.
Status text includes `READY`, `PLAYING`, `WON` or `LOST` outside the board.
Color is encouraged but must not be the only state indicator.

## Deterministic diagnostic interface
For PTY testing support `--test-layout 'r,c;r,c;...'` and
`--state-file /path/to/state.json`. With explicit test layout use exactly those
mines, do NOT relocate the first reveal, and restart the same forced board.
Write state atomically after input processing, including:
`rows`, `cols`, `mine_count`, `status` (lowercase), `cursor` `[r,c]`,
`revealed`, `flagged` (coordinate lists), and `visible_numbers` (`"r,c"`:count).
This diagnostic path uses the SAME engine and curses rendering as ordinary
play. It is not a substitute for drawing the board: tests compare PTY screen
and the diagnostic state. Normal play need not write a state file.

Example (use a PTY, not a pipe):
```bash
python3 -m minesweeper --rows 3 --cols 3 --mines 1 \
  --test-layout '0,0' --state-file artifacts/self-state.json
```

Run logic tests and PTY interaction tests. Do not claim visual/browser evidence.
Write SUBMISSION.json only after completing and checking the app.

## Forced-board diagnostic detail
In the explicit test interface, `revealed` contains only cells actually revealed
by clicks/flood expansion. On loss it adds the triggered mine, not every mine.
Decorative reveal of other mines may be shown separately in normal play, but
the forced-board DOM/PTY and diagnostic state follow this exact contract.
Flags do not start play or change `ready` to `playing`; a safe reveal does.
Restarting a forced board keeps its layout and resets all reveal/flag state.
