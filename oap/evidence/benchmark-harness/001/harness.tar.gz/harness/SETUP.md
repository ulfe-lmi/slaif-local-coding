# Setup and operation — GPU3 single-lane deployment

Run VM commands from this package root. Nothing here installs or changes vLLM,
CUDA, drivers, torch, weights or host services. Port 8000 is out of scope.

## 1. Topology and private paths

The only measured endpoint is `http://192.0.2.195:18043/v1`, mapped to GPU3
`GPU-REDACTED-BENCHMARK-LANE`. DIRECT calls it directly. Adapter
arms bind only `127.0.0.1:18143` in the VM and use that same LAN upstream.

Keep all secrets and run work outside this repository. The backend env file must
be an absolute, mode-0600-or-stricter, regular non-symlink file containing one
nonempty `BENCH_BACKEND_API_KEY=value` entry. The configured private locations
are:

```
/ABSOLUTE/PRIVATE/slaif-benchmark/secrets/backend-gpu3.env
/ABSOLUTE/PRIVATE/slaif-benchmark/runs
```

Never print the value, put it in argv, copy it into a workspace or mount the file
into a subject. `subject.env` contains a per-run value required for DIRECT, is
outside `/work`, mode 0600, and is deleted during cleanup.

## 2. VM prerequisites

Required: Docker Engine, Python 3.11+, pytest, Git and enough VM capacity for one
subject/Chromium process plus controller and adapter. Add the operator to the
Docker group, then log out and back in before non-sudo qualification:

```bash
sudo usermod -aG docker "$USER"
docker version
python3 --version
python3 -m pytest --version
```

This does not install anything on the GPU host. Do not start a vLLM or recorder;
the dedicated GPU3 service and existing recorder are operator-managed.

## 3. Immutable product and subject toolbox

Authenticate GHCR with a package-read credential over stdin and pull the exact
product digest. Never rebuild it.

```bash
printf '%s' "$SLAIF_GHCR_TOKEN" | docker login ghcr.io \
  -u "$SLAIF_GHCR_USERNAME" --password-stdin
docker pull ghcr.io/ulfe-lmi/slaif-local-coding@sha256:a3782915da58a403fd0f7991c57f9954b07bfb9377e4730715c0fb7398f901db
```

The subject toolbox is separate and contains no product or vLLM code. Build it
once in the VM, record the resulting image ID and do not rebuild during formal
runs:

```bash
CODEX_VERSION=0.149.0 bash scripts/build_subject_worker.sh
```

## 4. Site and offline checks

Copy `config/site.example.json` to `.local/site.json` and fill exact facts. It
must define exactly lane 0, `max_parallel: 1`, execution mode
`single-lane-sequential`, GPU3 UUID, port 18043 and absolute private paths.

```bash
python3 -m pytest -q
python3 -m compileall -q benchkit evaluators scripts host worker tests
python3 scripts/check_package.py
python3 scripts/validate_adapter_configs.py \
  --site .local/site.json --out .local/adapter-config-check.json
python3 scripts/judge_controls.py --worker-image sha256:<WORKER_IMAGE_ID> \
  --out .local/judge-controls.json --execute
```

Adapter validation uses the actual frozen product parser with Docker networking
disabled. Judge controls make no model calls. The historical delivery manifest
is intentionally not rewritten after pre-freeze harness changes; record a new
kit tree identity instead.

## 5. Read-only preflight (no inference)

```bash
python3 scripts/bench.py preflight \
  --site .local/site.json --out .local/preflight.json
```

Preflight reads `/health`, authenticated `/v1/models`, authenticated `/metrics`,
product identity and subject Codex help. Separately capture `ip route get
192.0.2.195`, interface/MAC, unauthenticated protected-model status without a
body, and confirmation that controller config does not target port 18043.

Obtain from the host operator content-free inventory/recorder evidence for GPU
UUID/name/VRAM, PID-to-GPU attribution, model revision, vLLM flags, all-GPU
background activity, actual sample timestamps and VM/host clock offset. Do not
inspect protected DP3 private configuration or manage the recorder from the VM.

## 6. Explicit inference boundary

The following commands send bounded inference and must not run until the human
explicitly authorizes bounded qualification requests in this VM session:

```bash
# BOUNDED INFERENCE — REQUIRES EXPLICIT AUTHORIZATION
python3 scripts/bench.py probe \
  --site .local/site.json --out .local/capabilities-ATTEMPT_ID.json --execute

# PREPARE ONLY — no inference
python3 scripts/bench.py prepare-smoke-block --site .local/site.json \
  --task web --run-id smoke-sequential-web-ATTEMPT_ID
python3 scripts/prepare_permissions.py --site .local/site.json --execute

# BOUNDED SUBJECT INFERENCE — REQUIRES EXPLICIT AUTHORIZATION
python3 scripts/bench.py smoke-block --site .local/site.json \
  --task web --run-id smoke-sequential-web-ATTEMPT_ID --execute
```

`smoke-block` is one randomized four-period serial block on lane 0. Give every
probe/smoke a new attempt ID and preserve every outcome.
Qualify web, terminal and context paths, real tool continuation, native image
delivery, one/two-image behavior, governance/cache/rehydration, usage semantics,
typed compactions, isolation, capacity, recorder coverage and shared-host
contamination. No result from a config flag alone is a pass.

## 7. Schedule proposal

Schedules require block counts divisible by four. Each task/block has four serial
runs on lane 0. Randomized Williams orders balance every condition across the
four sequence positions and every directed predecessor transition per four-block
cycle.

```bash
python3 scripts/bench.py schedule --stage pilot --blocks 4 --seed 20260922 \
  --out .local/pilot.schedule.json
```

For all three tasks this is 48 logical runs in 12 sequential blocks. There is
never more than one subject. Preparation creates fresh per-run state but executes
nothing:

```bash
python3 scripts/bench.py prepare --site .local/site.json \
  --schedule .local/pilot.schedule.json
python3 scripts/prepare_permissions.py --site .local/site.json --execute
```

## 8. Qualification, freeze and approval

Populate `.local/qualification.json` only from measured evidence. Then, and only
then, freeze exact code/site/tasks/images/model/runtime/budgets/judges/evidence:

```bash
python3 scripts/site_fingerprint.py .local/site.json
python3 scripts/bench.py freeze --site .local/site.json --out .local/freeze.json
```

Freeze is not stage authorization. A human-supplied approval must bind the exact
freeze file hash, canonical schedule hash, stage, allowed block IDs,
`parallelism: 1`, expiry and retry policy. The controller never creates or signs
that approval.

```bash
python3 scripts/bench.py run-stage --site .local/site.json \
  --schedule .local/pilot.schedule.json --freeze .local/freeze.json \
  --approval .local/pilot.approval.json --execute
```

The dispatcher stops a block at broken measurement/protocol/shared
infrastructure evidence, drains after each run and starts judges only after
generation has stopped. No automatic or hidden retry exists.

## 9. Analysis and preservation

Preserve private raw events and every attempted run. Analyze stages separately,
report failure rates before successful-only efficiency, never add client and
backend token totals, and keep unavailable measures NULL. Include sequence
position, predecessor condition, backend warm-state and all-GPU shared-host
activity in limitations/sensitivity review.
