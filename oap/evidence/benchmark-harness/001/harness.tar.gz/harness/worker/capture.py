#!/usr/bin/env python3
"""Required screenshot helper: image metadata only in stdout; output is a task artifact."""
import argparse,json,time
from pathlib import Path
from urllib.parse import urlsplit

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--output',required=True)
    ap.add_argument('--width',type=int,default=1440);ap.add_argument('--height',type=int,default=900)
    ap.add_argument('--crop',nargs=4,type=int);a=ap.parse_args()
    u=urlsplit(a.url)
    if u.hostname not in ('127.0.0.1','localhost','::1'): ap.error('only the local app is allowed')
    out=Path(a.output).resolve()
    if not out.is_relative_to(Path('/work').resolve()): ap.error('output must stay in /work')
    out.parent.mkdir(parents=True,exist_ok=True)
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True)
        page=browser.new_page(viewport={'width':a.width,'height':a.height},device_scale_factor=1)
        page.goto(a.url,wait_until='networkidle');page.wait_for_timeout(300)
        options={'path':str(out)}
        if a.crop:
            x,y,w,h=a.crop;options['clip']={'x':x,'y':y,'width':w,'height':h}
        page.screenshot(**options);browser.close()
    event={'kind':'subject_screenshot','path':str(out.relative_to('/work')),'width':a.crop[2] if a.crop else a.width,
           'height':a.crop[3] if a.crop else a.height,'bytes':out.stat().st_size,'unix_ns':time.time_ns()}
    # User-controlled image artifacts are NOT evidence of actual model image ingestion.
    with Path('/work/artifacts/screenshot-events.jsonl').open('a') as f: f.write(json.dumps(event)+'\n')
    print(json.dumps(event))
if __name__=='__main__': main()
