Initialize this independent benchmark repository. Follow root AGENTS.md.

Prepare a reproducible standalone four-condition experiment using the existing
host vLLM installation, one A100 GPU3 LAN endpoint and an immutable
SLAIF Local Coding RC7. The host is also the hypervisor of this testing VM.
Do not touch the vLLM installation or existing services. Do not use Gateway.

Read the supplied protocol, setup, task contracts, judges and driver notes.
Inspect this kit; run its offline tests; fill local site facts from actual
read-only host/VM observations rather than guessing launch flags or model fit.
Build/freeze only the VM's separate subject toolbox if needed. Pull the exact
product digest; never rebuild it. Attach to current endpoints. The optional
host vLLM and recorder are attach-only and must not be managed from the VM.

Qualify the generated configurations against the actual product image, judge
positive/negative controls, native Codex tooling, screenshot delivery, cache
activation, accounting semantics, context signal, sequential carryover and shared-host contamination.
Use only bounded setup/smoke operations the human has authorized. Produce a
measured qualification record and a proposed freeze. Do not launch a pilot or
main campaign until a human approval file binds its exact schedule/freeze.

When a stage IS explicitly approved, dispatch it with the supplied controller,
keep counterbalanced four-condition serial blocks, preserve every attempt, wait
for lane 0 and backend drain before grading, and reconcile measurements. Continue until that stage
finishes or a genuine blocker requires intervention. Do not solve subject tasks,
read their outputs to give corrective hints, change protocols after seeing
results, run product publication work, or expand into unrelated infrastructure.
