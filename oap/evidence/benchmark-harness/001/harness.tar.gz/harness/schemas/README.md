# Data contracts

Runtime validators are in benchkit/common.py and benchkit/cli.py. These JSON
Schemas document the external schedule and stage-approval exchange formats.
They supplement, rather than replace, runtime hash, expiry, ownership and
human-authorization checks. No approval template grants permission.
