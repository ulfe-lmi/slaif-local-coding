# GPU, vLLM and Codex observation contract

`host/a100_parameter_recorder.py` is the requested A100-parameter recorder, made
GPU-family-neutral. On this deployment it records all physical GPUs, including
the measured A100 GPU3. Device families are never silently pooled in analysis.

It reads nvidia-smi (GPU + compute PID fields), /proc/meminfo, /proc/stat,
load average, and configured existing vLLM /metrics endpoints. No NVML install,
DCGM deployment, driver change, service restart, profiler injection, hook,
request proxy or model change is required. Missing fields/errors are recorded.
It writes a new private JSONL and manifest; it refuses to overwrite evidence.

## Token ledgers

1. Backend ledger: per-instance Prometheus counters bracketed around subject
   generation/drain. This includes ordinary client calls and internal compiler
   calls. vLLM request_success_total is successful/completed requests, not every
   attempted HTTP call. Counters cannot by themselves identify arbitrary API
   rejections before scheduling.
2. Client ledger: native Codex usage/events. Delta-versus-cumulative semantics
   require calibration. It may omit internal compiler traffic. Never sum it
   with backend traffic, and never sum cached_input_tokens on top of input_tokens
   when it is a subset.
3. Adapter ledger: existing numeric metrics, no new instrumentation. Labels and
   measured states can demonstrate feature activation. Failed compilation with
   original-body preservation is a meaningful treatment outcome, not assumed
   successful caching.

Per-run model input/output totals are obtainable from available counters;
image-token counts, per-request input sizes, TTFT, API latencies, AGENTS rereads
and precise model-directed screenshot counts depend on the actual exported
metrics/client records. The kit preserves sources but reports unsupported
fields as unavailable. It does NOT promise a per-request metric the existing
vLLM does not expose. Do not enable new server flags behind the user's back.

Numeric scrape labels are allowlisted; unknown/request-ID labels are omitted
rather than converted into an unbounded raw log. Backend response bodies and
image/prompt text are never stored in host telemetry. Source task code and raw
synthetic subject events are retained privately in the VM as requested, with
known credentials redacted from streamed logs. Native Codex rollout files can
still contain raw task content: mode-0700 homes, restricted storage and export
secret scans are required. Do not archive auth.json or real credential files.

## Timing and energy

Every sample has wall-clock Unix ns, UTC and monotonic ns. VM run windows use VM
Unix ns; align with a measured host-minus-VM offset and uncertainty. Repeat offset
measurement afterward to bound drift. `join_gpu_telemetry.py` refuses an energy
number if coverage/clock limits fail. Integrate device power only; shared CPU,
VM and network energy are not magically attributed to one GPU lane.

Median/p95 estimates from counter/histogram differences are approximations at
bucket resolution. Missing buckets, counter resets or label changes invalidate
that estimate. Do not average cumulative histogram quantiles across runs.

## Host startup parameters

`host/inventory.py` reads a strict allowlist of process arguments and hardware
facts. It never logs the complete command line or environment. For attached
services, supplement it with the operator's existing version/model/config
record, especially flags only present in a parent launcher/environment. The
deployment is attach-only. Inventory does not infer missing precision/context
settings or change them to match a template.
