#!/usr/bin/env python3
"""Historical requested name; records actual V100/A100 identities automatically."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from benchkit.recorder import main
if __name__ == '__main__':
    raise SystemExit(main())
