#!/usr/bin/env python3
"""Read-only host inventory; never prints raw process command lines or env secrets."""
import argparse,json,os,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from benchkit.common import atomic_json,read_json,sha256,utc
from benchkit.recorder import nvidia_query,host_stats
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args()
allowed={'--model','--host','--port','--served-model-name','--dtype','--quantization','--max-model-len',
'--tensor-parallel-size','--pipeline-parallel-size','--data-parallel-size','--gpu-memory-utilization',
'--max-num-seqs','--kv-cache-dtype','--cpu-offload-gb','--swap-space','--tool-call-parser','--reasoning-parser',
'--enable-prefix-caching','--disable-prefix-caching','--enable-auto-tool-choice','--limit-mm-per-prompt'}
g=nvidia_query(('index','uuid','name','memory.total'));procs=nvidia_query(('gpu_uuid','pid','used_gpu_memory'),'compute-apps');facts=[]
for item in procs.get('rows',[]):
    try:
        pid=int(item['pid']);cmd=Path(f'/proc/{pid}/cmdline').read_bytes().decode(errors='replace').split('\0');flags={}
        for i,v in enumerate(cmd):
            k,sep,value=v.partition('=')
            if k not in allowed:continue
            if sep:flags[k]=value
            elif i+1<len(cmd) and not cmd[i+1].startswith('-'):flags[k]=cmd[i+1]
            else:flags[k]=True
        facts.append({'pid':pid,'gpu_uuid':item['gpu_uuid'],'approved_startup_parameters':flags})
    except (OSError,ValueError):facts.append({'gpu_uuid':item.get('gpu_uuid'),'process_parameters':'unavailable'})
atomic_json(Path(a.out),{'created_at':utc(),'unix_ns':time.time_ns(),'read_only':True,'gpus':g,'processes':facts,'host':host_stats()})
