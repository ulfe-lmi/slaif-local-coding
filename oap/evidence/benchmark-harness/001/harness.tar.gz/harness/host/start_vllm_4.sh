#!/usr/bin/env bash
set -euo pipefail
# Historical filename; current implementation is read-only single-lane attach.
# RUN ON THE PHYSICAL HOST ONLY. No install/update/restart of existing services.
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
exec "${BENCH_PYTHON:-python3}" -m benchkit.host_lanes "$@"
