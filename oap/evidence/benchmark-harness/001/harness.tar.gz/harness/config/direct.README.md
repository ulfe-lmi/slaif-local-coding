DIRECT launches no Local Coding container. The subject provider base_url is the assigned physical-host LAN endpoint /v1. The same model/subject configuration and task seed remain fixed.
