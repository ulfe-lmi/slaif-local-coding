"""Read-only attachment checks for one existing measured vLLM lane."""
from __future__ import annotations
import argparse,ipaddress,json,socket
from .common import read_json
from .recorder import nvidia_query

def listening(host: str,port: int) -> bool:
    with socket.socket() as sock:
        sock.settimeout(1)
        return sock.connect_ex((host,port))==0

def validate(config: dict) -> list[list[str]]:
    if 'CHANGE_ME' in json.dumps({'bind_ip':config['bind_ip'],'lanes':config['lanes']}):
        raise ValueError('host LAN/lane configuration contains placeholders')
    address=ipaddress.ip_address(config['bind_ip'])
    if address.is_loopback or address.is_unspecified:
        raise ValueError('use the host LAN IP, not a loopback/unspecified address')
    lanes=config['lanes']
    if len(lanes)!=1 or lanes[0].get('lane')!=0:
        raise ValueError('exactly one measured lane 0 is required')
    if config.get('mode')!='attach':
        raise ValueError('this deployment is attach-only; do not launch or manage host vLLM')
    return []

def main(argv=None) -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['plan','status','start'])
    parser.add_argument('--config',required=True)
    args=parser.parse_args(argv)
    config=read_json(args.config);validate(config)
    if args.action=='plan':
        print(json.dumps({'mode':'attach','installation_mutations':False,
                          'commands':[],'note':'read-only attachment; no host process management'},indent=2))
        return 0
    print(json.dumps({'action':'read_only_attach','ports':[
        {'lane':lane['lane'],'port':lane['port'],'listening':listening(config['bind_ip'],lane['port'])}
        for lane in config['lanes']],
        'gpus':nvidia_query(('index','uuid','name','memory.total')),
        'compute_processes':nvidia_query(('gpu_uuid','pid','used_gpu_memory'),'compute-apps')},indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
