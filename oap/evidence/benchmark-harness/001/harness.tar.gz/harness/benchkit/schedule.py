"""Counterbalanced four-condition blocks executed serially on one lane."""
from __future__ import annotations
import random
from .common import CONDITIONS, TASKS

def validate_schedule(schedule: dict) -> None:
    if schedule.get('schema')!='slaif-schedule-v2-single-lane': raise ValueError('unsupported schedule schema')
    if schedule.get('execution_mode')!='single-lane-sequential' or schedule.get('max_parallel')!=1:
        raise ValueError('schedule must require single-lane sequential execution')
    tasks=schedule.get('tasks',[]);blocks=schedule.get('blocks_per_cell')
    if not tasks or len(set(tasks))!=len(tasks) or any(t not in TASKS for t in tasks): raise ValueError('invalid schedule task set')
    if not isinstance(blocks,int) or blocks<=0 or blocks%4: raise ValueError('schedule blocks must be a positive multiple of four')
    if schedule.get('conditions')!=list(CONDITIONS): raise ValueError('schedule condition set/order changed')
    schedule_blocks=schedule.get('blocks',[])
    if len(schedule_blocks)!=len(tasks)*blocks or schedule.get('logical_runs')!=4*len(schedule_blocks): raise ValueError('schedule run/block count mismatch')
    block_ids=set();run_ids=set();by_task={task:[] for task in tasks}
    for item in schedule_blocks:
        if item.get('block_id') in block_ids: raise ValueError('duplicate block ID')
        block_ids.add(item.get('block_id'));runs=item.get('runs',[]);order=item.get('condition_order')
        if item.get('execution')!='sequential' or item.get('possible_backend_carryover') is not True:
            raise ValueError('block must record sequential execution and possible carryover')
        if len(runs)!=4 or not isinstance(order,list) or set(order)!=set(CONDITIONS): raise ValueError('block must contain all four conditions once')
        if [r.get('condition') for r in runs]!=order: raise ValueError('recorded condition order mismatch')
        for position,run in enumerate(runs,1):
            if run.get('run_id') in run_ids: raise ValueError('duplicate run ID')
            run_ids.add(run.get('run_id'))
            expected_previous=order[position-2] if position>1 else None
            if (run.get('lane')!=0 or run.get('sequence_position')!=position or
                run.get('previous_condition')!=expected_previous or run.get('task')!=item.get('task') or
                run.get('block')!=item.get('block') or run.get('task_seed')!=item.get('task_seed')):
                raise ValueError('inconsistent serial run metadata')
        if item.get('task') not in by_task: raise ValueError('block has unknown task')
        by_task[item['task']].append(item)
    for task,task_blocks in by_task.items():
        task_blocks.sort(key=lambda item:item['block'])
        if [b['block'] for b in task_blocks]!=list(range(1,blocks+1)): raise ValueError(f'noncanonical block numbers for {task}')
        for cycle in range(blocks//4):
            group=task_blocks[cycle*4:(cycle+1)*4]
            for position in range(4):
                if {w['condition_order'][position] for w in group}!=set(CONDITIONS): raise ValueError('condition-position balance broken')
            transitions=[pair for w in group for pair in zip(w['condition_order'],w['condition_order'][1:])]
            if len(transitions)!=12 or len(set(transitions))!=12: raise ValueError('first-order carryover balance broken')

def make_schedule(tasks: list[str], blocks: int, seed: int, stage: str) -> dict:
    if not tasks or len(set(tasks))!=len(tasks) or any(t not in TASKS for t in tasks): raise ValueError('invalid or duplicate task set')
    if blocks<=0 or blocks%4: raise ValueError('blocks must be a positive multiple of four')
    if stage not in ('pilot','main','extension','smoke'): raise ValueError('invalid stage')
    rng=random.Random(seed)
    schedule_blocks=[]
    # Four Williams orders balance condition position and every directed
    # first-order transition once per four blocks. Labels and row order are
    # independently randomized in each cycle without changing that balance.
    williams=((0,1,3,2),(1,2,0,3),(2,3,1,0),(3,0,2,1))
    for cycle in range(blocks//4):
        per_task={}
        for task in tasks:
            labels=list(CONDITIONS);rng.shuffle(labels)
            rows=list(range(4));rng.shuffle(rows)
            per_task[task]=[[labels[i] for i in williams[row]] for row in rows]
        # Interleave task blocks within each period. Every run uses lane 0.
        for period in range(4):
            task_order=list(tasks);rng.shuffle(task_order)
            for task in task_order:
                block=cycle*4+period+1
                block_id=f'{stage}-{task}-b{block:02d}'
                task_seed=rng.randrange(1,2**31)
                order=per_task[task][period]
                runs=[]
                for position,condition in enumerate(order,1):
                    prior=order[position-2] if position>1 else None
                    runs.append({'run_id':f'{block_id}-p{position:02d}-{condition.lower()}',
                        'lane':0,'condition':condition,'task':task,'block':block,
                        'task_seed':task_seed,'sequence_position':position,
                        'previous_condition':prior})
                schedule_blocks.append({'block_id':block_id,'task':task,'block':block,
                    'task_seed':task_seed,'execution':'sequential','condition_order':order,
                    'possible_backend_carryover':True,'runs':runs})
    schedule={'schema':'slaif-schedule-v2-single-lane','stage':stage,'seed':seed,
            'execution_mode':'single-lane-sequential','max_parallel':1,
            'counterbalance':'randomized Williams orders in four-block cycles; position and directed first-order carryover balanced',
            'blocks_per_cell':blocks,'tasks':tasks,'conditions':list(CONDITIONS),
            'logical_runs':4*blocks*len(tasks),'blocks':schedule_blocks}
    validate_schedule(schedule)
    return schedule
