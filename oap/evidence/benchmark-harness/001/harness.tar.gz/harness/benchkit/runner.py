from __future__ import annotations
import contextlib,hashlib,json,os,random,re,selectors,shutil,signal,subprocess,time
from pathlib import Path
from urllib.request import Request,urlopen
from .common import ROOT,atomic_json,lease,object_hash,read_env,read_json,redact,run,sha256,utc,validate_site
from .configurations import adapter_toml,subject_config
from .dockerutil import assert_product,common_container,inspect_image,remove_owned,start_adapter,start_subject
from .events import event_summary,rollout_compactions
from .metrics import scrape,counter_delta,histogram_quantile_delta,total


def set_owner(path: Path, uid: int,gid: int) -> None:
    # Default UID/GID should match the VM operator. Never sudo automatically.
    if path.stat().st_uid!=uid or path.stat().st_gid!=gid: os.chown(path,uid,gid)

def capture_container_logs(name: str,path: Path,secrets: dict[str,str],max_bytes: int=1048576) -> dict:
    """Preserve bounded private controller evidence from an owned container."""
    proc=subprocess.run(['docker','logs','--tail','5000',name],text=True,capture_output=True,timeout=30)
    data=redact(proc.stdout+'\n'+proc.stderr,secrets).encode('utf-8','replace')
    truncated=len(data)>max_bytes
    if truncated:data=data[-max_bytes:]
    path.write_bytes(data);os.chmod(path,0o600)
    return {'returncode':proc.returncode,'bytes':len(data),'truncated':truncated}

def prepare_case(site: dict, case: dict) -> Path:
    if not re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,95}',case['run_id']): raise ValueError('unsafe run ID')
    root=Path(site['workspace_root'])/case['run_id']
    if root.exists(): raise FileExistsError(f'run exists; choose a new attempt ID, never overwrite: {root}')
    root.mkdir(parents=True,mode=0o700)
    work=root/'work';shutil.copytree(ROOT/'tasks'/case['task'],work)
    home=root/'home';(home/'.codex').mkdir(parents=True,mode=0o700)
    lane=next(x for x in site['lanes'] if x['lane']==case['lane'])
    atomic_json(work/'runtime.json',{'app_port':lane['app_port'],'task_seed':case['task_seed']})
    (home/'.codex'/'config.toml').write_text(subject_config(site,case));os.chmod(home/'.codex'/'config.toml',0o600)
    shutil.copyfile(ROOT/'config'/'qwen-neumann-models.json',home/'.codex'/'qwen-neumann-models.json')
    os.chmod(home/'.codex'/'qwen-neumann-models.json',0o600)
    atomic_json(root/'codex_input_hashes.json',{
        'config.toml':sha256(home/'.codex'/'config.toml'),
        'qwen-neumann-models.json':sha256(home/'.codex'/'qwen-neumann-models.json'),
    })
    # Git repository with no human/global configuration is local trial state only.
    e=os.environ.copy();e['GIT_CONFIG_GLOBAL']='/dev/null';e['GIT_CONFIG_NOSYSTEM']='1'
    run(['git','init','-q',str(work)],env=e)
    run(['git','-C',str(work),'-c','user.name=Benchmark','-c','user.email=benchmark@invalid',
         'add','.'],env=e)
    run(['git','-C',str(work),'-c','user.name=Benchmark','-c','user.email=benchmark@invalid',
         'commit','-q','-m','Frozen task seed'],env=e)
    for p in [work,home,*work.rglob('*'),*home.rglob('*')]:
        if not p.is_symlink(): set_owner(p,site['worker_uid'],site['worker_gid'])
    cfg=adapter_toml(site,case)
    if cfg:
        p=root/'adapter.toml';p.write_text(cfg);os.chmod(p,0o600)
        # Product image uid is 10001. VM operator may need one explicit admin
        # ownership step; no silent world-readable config fallback.
        try: os.chown(p,10001,10001)
        except PermissionError:
            print(f'Needs explicit VM admin ownership step: {p} -> uid/gid 10001; see prepare_permissions.py')
    atomic_json(root/'case.json',case)
    atomic_json(root/'seed_hashes.json',{p.relative_to(work).as_posix():sha256(p) for p in work.rglob('*') if p.is_file() and '.git' not in p.parts})
    return root

def wait_ready(port: int, timeout: float=90) -> None:
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        try:
            with urlopen(f'http://127.0.0.1:{port}/readyz',timeout=3) as r:
                if r.status==200: return
        except Exception: pass
        time.sleep(1)
    raise RuntimeError('adapter readiness did not become healthy')

def stream_exec(argv: list[str], prompt: str, out: Path, err: Path, deadline: float,
                secrets: dict, raw_limit: int) -> dict:
    start=time.monotonic();thread=None;bytes_seen=0;buffer=b'';timed_out=False
    with err.open('wb') as ef, out.open('w') as of:
        os.chmod(err,0o600);os.chmod(out,0o600)
        p=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=ef,start_new_session=True)
        try:
            # Prompt may be large (context stress); writing in a feeder avoids
            # blocking the deadline loop on pipe capacity.
            import threading
            def feed():
                try: p.stdin.write(prompt.encode());p.stdin.close()
                except (BrokenPipeError,OSError): pass
            feeder=threading.Thread(target=feed,daemon=True);feeder.start()
            sel=selectors.DefaultSelector();sel.register(p.stdout,selectors.EVENT_READ)
            while sel.get_map():
                if err.stat().st_size > raw_limit:
                    raise RuntimeError('stderr log budget exceeded')
                if time.monotonic()>deadline:
                    timed_out=True;os.killpg(p.pid,signal.SIGTERM);break
                for key,_ in sel.select(.2):
                    data=os.read(key.fileobj.fileno(),65536)
                    if not data: sel.unregister(key.fileobj);continue
                    buffer+=data;bytes_seen+=len(data)
                    if bytes_seen>raw_limit: raise RuntimeError('raw event log budget exceeded')
                    while b'\n' in buffer:
                        line,buffer=buffer.split(b'\n',1)
                        safe=redact(line.decode('utf-8','replace'),secrets)
                        try: event=json.loads(safe)
                        except ValueError: event={'type':'unparsed','line':safe}
                        if event.get('type')=='thread.started': thread=event.get('thread_id')
                        of.write(json.dumps({'utc':utc(),'unix_ns':time.time_ns(),'event':event})+'\n');of.flush()
            if buffer:
                of.write(json.dumps({'utc':utc(),'unix_ns':time.time_ns(),'event':{'type':'unparsed','line':redact(buffer.decode(errors='replace'),secrets)}})+'\n')
            try: p.wait(timeout=10)
            except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL);p.wait()
        finally:
            if p.poll() is None:
                with contextlib.suppress(ProcessLookupError): os.killpg(p.pid,signal.SIGTERM)
            # Outer caller removes the OWNED subject container: killing docker
            # exec alone does not reliably kill the process inside it.
    err.write_text(redact(err.read_text(errors='replace'),secrets))
    return {'returncode':p.returncode,'thread_id':thread,'wall_seconds':time.monotonic()-start,'timeout':timed_out,'bytes':bytes_seen}

def pressure_prompt(site: dict, case: dict, phase: int) -> str:
    rng=random.Random(case['task_seed']+phase*7919)
    rows=[];n=0
    target=site['context_task']['bytes_per_phase']
    while n<target:
        a=rng.randrange(10000);b=rng.randrange(10000);label=''.join(rng.choice('abcdefghijklmnopqrstuvwxyz') for _ in range(28))
        line=f'{len(rows):05d},{label},{a},{b},{a+b}\n';rows.append(line);n+=len(line)
    return (f'Phase {phase}: audit the following synthetic CSV (id,label,a,b,total). '
            f'Check all totals, count rows, and write results/phase-{phase:02d}.json with your findings. '
            'Stay in the same session. This is not the final fact query.\n\n'+''.join(rows))

def run_case(site: dict,case: dict,root: Path) -> dict:
    validate_site(site)
    if read_json(root/'case.json')!=case: raise ValueError('case manifest mismatch')
    lane=next(x for x in site['lanes'] if x['lane']==case['lane'])
    name='sb-'+hashlib.sha256(case['run_id'].encode()).hexdigest()[:16]
    worker=name+'-subject';adapter=name+'-adapter'
    if (root/'result.json').exists(): raise FileExistsError('result already exists')
    secret=read_env(site['secret_env_file']);backend=secret['BENCH_BACKEND_API_KEY']
    epath=root/'subject.env';epath.write_text('BENCH_API_KEY='+ (backend if case['condition']=='DIRECT' else 'loopback-only-no-auth')+'\n');os.chmod(epath,0o600)
    metrics_stop=False;metric_path=root/'metrics.jsonl';sample_pool=None
    result={'schema':'slaif-run-result-v1','case':case,'product':site['product'],'site_sha256':object_hash(site),
            'started_at':utc(),'status':'INFRASTRUCTURE_ERROR','invocations':[],'backend_url':lane['backend_url'],
            'backend_cache_policy':site['measurement']['backend_cache_policy']}
    with lease(Path(site['workspace_root'])/f'.lane-{case["lane"]}.lock'):
        try:
            assert_product(site)
            if case['condition']!='DIRECT':
                start_adapter(site,case,root/'adapter.toml',Path(site['secret_env_file']),adapter)
                wait_ready(lane['adapter_port'])
            start_subject(site,case,root/'work',root/'home',epath,worker)
            v=run(['docker','exec',worker,'codex','--version']).stdout.strip()
            if site['codex_version'] not in v: raise RuntimeError('subject Codex version mismatch')
            before=scrape(lane['metrics_url'],backend)
            if not before['ok'] and not site['measurement']['allow_missing_backend_metrics']: raise RuntimeError('backend metrics unavailable')
            if before.get('ok'):
                running=total(before['series'],'vllm:num_requests_running');waiting=total(before['series'],'vllm:num_requests_waiting')
                if running!=0 or waiting!=0: raise RuntimeError('backend is busy or idle counters are unavailable before this run')
            atomic_json(root/'metrics-before.json',before)
            result['measurement_start_ns']=time.time_ns()
            timed_start=time.monotonic();deadline=timed_start+site['limits'][case['task']+'_wall_seconds']
            import threading
            def sampler():
                with metric_path.open('w') as f:
                    os.chmod(metric_path,0o600)
                    while not metrics_stop:
                        row={'unix_ns':time.time_ns(),'backend':scrape(lane['metrics_url'],backend)}
                        if case['condition']!='DIRECT': row['adapter']=scrape(f'http://127.0.0.1:{lane["adapter_port"]}/metrics')
                        f.write(json.dumps(row)+'\n');f.flush()
                        time.sleep(site['measurement']['scrape_interval_seconds'])
            sample_pool=threading.Thread(target=sampler,daemon=True);sample_pool.start()
            thread=None;paths=[];base_prompt=(root/'work'/'PROMPT.md').read_text()
            goal=(root/'work'/'GOAL.md').read_text()
            if case['task']=='context':
                prompts=[base_prompt]+[pressure_prompt(site,case,i) for i in range(1,site['context_task']['phases']+1)]
                prompts.append((root/'work'/'FINAL_PROMPT.md').read_text())
            else:
                prompts=[base_prompt+'\n\nPersistent objective:\n'+goal]+[
                    'Continue the SAME task under AGENTS.md and GOAL.md. Inspect your own progress, run your own tests, repair defects, and finish. No hidden evaluator feedback is available.'
                    for _ in range(site['codex']['max_continuations'])]
            result['status']='INCOMPLETE'
            for i,prompt in enumerate(prompts):
                if time.monotonic()>=deadline: result['status']='TIMEOUT';break
                cmd=['docker','exec','-i','-w','/work',worker,'codex','--dangerously-bypass-approvals-and-sandbox']
                for k,v in site['codex'].get('additional_config',{}).items(): cmd+=['-c',f'{k}={json.dumps(v)}']
                cmd+=['exec']
                if thread: cmd+=['resume','--json',thread,'-']
                else: cmd+=['--json','-']
                path=root/f'events-{i:03d}.jsonl';paths.append(path)
                inv=stream_exec(cmd,prompt,path,root/f'stderr-{i:03d}.txt',deadline,
                                secret,site['limits']['raw_stdout_limit_bytes'])
                result['invocations'].append(inv)
                if inv['thread_id']:
                    if thread is not None and thread!=inv['thread_id']: raise RuntimeError('resume started another thread')
                    thread=inv['thread_id']
                if inv['timeout']: result['status']='TIMEOUT';break
                if inv['returncode']!=0: result['status']='SUBJECT_ERROR';break
                summary=event_summary(paths,site['measurement']['client_usage_semantics'])
                totals=summary.get('client_token_totals')
                if totals and totals['input_tokens']+totals['output_tokens']>site['limits']['max_observed_client_tokens']:
                    result['status']='TOKEN_BUDGET';break
                submitted=root/'work'/'SUBMISSION.json'
                complete=False
                if submitted.is_file() and not submitted.is_symlink():
                    try: complete=read_json(submitted).get('complete') is True
                    except (ValueError,AttributeError): pass
                if complete and (case['task']!='context' or i==len(prompts)-1):
                    result['status']='SUBMITTED';break
                if not thread: result['status']='MISSING_THREAD_ID';break
            result['coding_wall_seconds']=time.monotonic()-timed_start
            result['events']=event_summary(paths,site['measurement']['client_usage_semantics'])
            result['compactions']=rollout_compactions(root/'home' / '.codex')
            if case['task']=='context' and result['compactions']['count']<site['context_task']['minimum_compactions']:
                result['context_exposure']='FEWER_THAN_TARGET_OBSERVED_COMPACTIONS_DO_NOT_EXCLUDE_TREATMENT'
            else: result['context_exposure']='qualified' if case['task']=='context' else 'not_applicable'
        except Exception as e:
            result['error_type']=type(e).__name__
            result['error']=redact(str(e),secret)[:1000]
        finally:
            # Stop all subject processes before final backend drain. No evaluator
            # or next serial run starts while this run is generating.
            remove_owned(worker,case['run_id'])
            metrics_stop=True
            if sample_pool: sample_pool.join(timeout=15)
            drain_end=time.monotonic()+30;idle=False
            while time.monotonic()<drain_end:
                snap=scrape(lane['metrics_url'],backend)
                if snap.get('ok'):
                    running=total(snap['series'],'vllm:num_requests_running');waiting=total(snap['series'],'vllm:num_requests_waiting')
                    if running==0 and waiting==0: idle=True;break
                time.sleep(1)
            result['backend_idle_after']=idle
            after=scrape(lane['metrics_url'],backend);atomic_json(root/'metrics-after.json',after)
            result['measurement_end_ns']=time.time_ns()
            if (root/'metrics-before.json').exists() and after.get('ok'):
                b=read_json(root/'metrics-before.json')
                if b.get('ok'):
                    result['backend_deltas']={k:counter_delta(b['series'],after['series'],k) for k in (
                        'vllm:prompt_tokens_total','vllm:generation_tokens_total','vllm:request_success_total')}
                    result['backend_p95_latency_seconds']=histogram_quantile_delta(b['series'],after['series'],'vllm:e2e_request_latency_seconds')
            if case['condition']!='DIRECT':
                result['adapter_final_metrics']=scrape(f'http://127.0.0.1:{lane["adapter_port"]}/metrics')
                try: result['adapter_log_capture']=capture_container_logs(adapter,root/'adapter.private.log',secret)
                except Exception as e: result['adapter_log_capture']={'error_type':type(e).__name__}
            remove_owned(adapter,case['run_id'])
            with contextlib.suppress(FileNotFoundError): epath.unlink()
            result['finished_at']=utc()
            result['measurement_valid']=bool(result.get('backend_idle_after')) and all(
                result.get('backend_deltas',{}).get(k,{}).get('status')=='ok' for k in ('vllm:prompt_tokens_total','vllm:generation_tokens_total'))
            # Important immutable task seed/instructions must not be modified.
            seed=read_json(root/'seed_hashes.json');changes=[]
            for rel,digest in seed.items():
                p=root/'work'/rel
                if p.is_symlink() or not p.is_file() or sha256(p)!=digest: changes.append(rel)
            result['immutable_task_file_changes']=changes
            if changes: result['protocol_violation']='task_instructions_changed'
            codex_seed=read_json(root/'codex_input_hashes.json');codex_changes=[]
            for rel,digest in codex_seed.items():
                p=root/'home'/'.codex'/rel
                if p.is_symlink() or not p.is_file() or sha256(p)!=digest: codex_changes.append(rel)
            result['immutable_codex_input_changes']=codex_changes
            if codex_changes: result['protocol_violation']='codex_inputs_changed'
            atomic_json(root/'result.json',result)
    return result

def judge_case(site: dict,case: dict,root: Path) -> dict:
    if (root/'judge.json').exists(): return read_json(root/'judge.json')
    name='sj-'+hashlib.sha256(case['run_id'].encode()).hexdigest()[:16]
    out=root/'evaluation';out.mkdir(mode=0o700)
    cmd=['docker','run','--rm','--name',name,'--label',f'slaif.benchmark.run={case["run_id"]}',
         '--network','none','--cap-drop','ALL','--security-opt','no-new-privileges',
         '--pids-limit','512','--memory',site['worker_memory'],'--cpus',str(site['worker_cpus']),
         '--user',f"{site['worker_uid']}:{site['worker_gid']}",'--read-only','--tmpfs','/tmp:rw,size=1g','--tmpfs','/dev/shm:rw,size=512m',
         '-v',f'{root/"work"}:/work','-v',f'{ROOT/"evaluators"}:/judge:ro','-v',f'{out}:/out',
         '-w','/work',site['subject_worker_image'],'python3',f'/judge/{case["task"]}_judge.py',
         '--work','/work','--output','/out/judge.json']
    # No API key, Codex home, registry credential, controller or Docker socket.
    try:
        run(cmd,timeout=180)
        judgment=read_json(out/'judge.json')
    except Exception as e: judgment={'status':'JUDGE_INFRASTRUCTURE_ERROR','error_type':type(e).__name__}
    finally: remove_owned(name,case['run_id'])
    atomic_json(root/'judge.json',judgment)
    return judgment

def run_block(site: dict,block: dict, *, prepared: bool=False) -> list[dict]:
    if site.get('max_parallel')!=1 or site.get('execution_mode')!='single-lane-sequential':
        raise ValueError('block dispatch requires single-lane sequential site configuration')
    if any(c.get('lane')!=0 for c in block['runs']): raise ValueError('every block run must use measured lane 0')
    if [c['condition'] for c in block['runs']]!=block.get('condition_order'):
        raise ValueError('block run order differs from recorded condition_order')
    roots={}
    for c in block['runs']:
        root=Path(site['workspace_root'])/c['run_id']
        roots[c['run_id']]=root if prepared else prepare_case(site,c)
        if read_json(roots[c['run_id']]/'case.json')!=c: raise ValueError('prepared case mismatch')
    results=[]
    for c in block['runs']:
        result=run_case(site,c,roots[c['run_id']])
        results.append(result)
        # A broken measurement or protocol violation stops the block before
        # another condition can start. Ordinary subject/task failure remains
        # an observed outcome and does not become an invisible retry.
        if not result.get('measurement_valid') or result.get('error_type') or result.get('protocol_violation'):
            break
    # Grading starts only after serial generation has stopped and each attempted
    # run has completed its backend-drain check.
    for c in block['runs'][:len(results)]: judge_case(site,c,roots[c['run_id']])
    return results
