from __future__ import annotations
import json,subprocess
from pathlib import Path
from .common import run

def inspect_image(image: str) -> dict:
    return json.loads(run(['docker','image','inspect',image]).stdout)[0]

def assert_product(site: dict) -> dict:
    expected=site['product'];image=inspect_image(expected['image'])
    labels=image['Config'].get('Labels') or {}
    checks={'org.opencontainers.image.revision':expected['source_commit'],
            'slaif-local-coding.wheel.sha256':expected['wheel_sha256']}
    for k,v in checks.items():
        if labels.get(k)!=v: raise ValueError(f'product label mismatch: {k}')
    if image.get('Architecture')!='amd64' or image.get('Os')!='linux': raise ValueError('expected linux/amd64 product')
    if expected['image'] not in image.get('RepoDigests',[]): raise ValueError('registry RepoDigest not present; pull exact product digest first')
    return {'id':image['Id'],'repo_digests':image['RepoDigests'],'labels':labels}

def remove_owned(name: str, run_id: str) -> None:
    p=subprocess.run(['docker','inspect',name],text=True,capture_output=True)
    if p.returncode: return
    info=json.loads(p.stdout)[0]
    if info.get('Config',{}).get('Labels',{}).get('slaif.benchmark.run')!=run_id:
        raise RuntimeError('refusing to remove a container not owned by this run')
    run(['docker','rm','-f',name])

def common_container(name: str, run_id: str, network: str='host') -> list[str]:
    return ['docker','run','-d','--name',name,'--label',f'slaif.benchmark.run={run_id}',
            '--network',network,'--cap-drop','ALL','--security-opt','no-new-privileges',
            '--read-only','--pids-limit','512','--tmpfs','/tmp:rw,nosuid,size=1g',
            '--tmpfs','/dev/shm:rw,nosuid,size=512m']

def start_subject(site: dict, case: dict, work: Path, home: Path, env: Path, name: str) -> None:
    cmd=common_container(name,case['run_id'])
    cmd+=['--user',f"{site['worker_uid']}:{site['worker_gid']}",'--cpus',str(site['worker_cpus']),
          '--memory',site['worker_memory'],'--env-file',str(env),
          '-e','HOME=/home/runner','-e','CODEX_HOME=/home/runner/.codex','-e','TERM=xterm-256color',
          '-v',f'{work}:/work','-v',f'{home}:/home/runner','-w','/work',site['subject_worker_image'],'sleep','infinity']
    run(cmd)

def start_adapter(site: dict, case: dict, cfg: Path, env: Path, name: str) -> None:
    cmd=common_container(name,case['run_id'])
    cmd+=['--memory','1g','--env-file',str(env),'-v',f'{cfg}:/etc/slaif/adapter.toml:ro',site['product']['image'],
          '--config=/etc/slaif/adapter.toml']
    run(cmd)
