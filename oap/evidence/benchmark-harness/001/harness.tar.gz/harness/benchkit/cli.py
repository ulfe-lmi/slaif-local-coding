from __future__ import annotations
import argparse,datetime as dt,json,os,random,sys
from pathlib import Path
from .common import CONDITIONS,ROOT,atomic_json,lease,object_hash,read_json,sha256,tree_hashes,utc,validate_site
from .schedule import make_schedule,validate_schedule

def require_freeze(site: dict, frozen: dict) -> None:
    if frozen['site_sha256']!=object_hash(site): raise ValueError('site changed after freeze')
    if frozen['kit_hashes']!=tree_hashes(ROOT): raise ValueError('benchmark package changed after freeze')

def authorize(file: Path, freeze: Path,schedule: dict,block_id: str,parallel: int) -> None:
    a=read_json(file)
    if a.get('schema')!='slaif-stage-approval-v2-single-lane': raise ValueError('unsupported approval schema')
    if a.get('reviewed_by_human') is not True: raise ValueError('human approval required')
    if a.get('freeze_sha256')!=sha256(freeze): raise ValueError('approval does not bind this freeze')
    if a.get('schedule_sha256')!=object_hash(schedule): raise ValueError('approval does not bind this exact schedule')
    if a.get('stage')!=schedule['stage']: raise ValueError('approval stage mismatch')
    if block_id not in a.get('allowed_block_ids',[]): raise ValueError('block not authorized')
    if a.get('parallelism')!=parallel: raise ValueError('approval parallelism mismatch')
    expires=dt.datetime.fromisoformat(a['not_after'].replace('Z','+00:00'))
    if expires.tzinfo is None or dt.datetime.now(dt.timezone.utc)>=expires: raise ValueError('approval expired')

def main(argv=None) -> int:
    p=argparse.ArgumentParser(description='External standalone benchmark. No vLLM installation or product mutation.')
    sp=p.add_subparsers(dest='cmd',required=True)
    q=sp.add_parser('schedule');q.add_argument('--tasks',default='web,terminal,context');q.add_argument('--blocks',type=int,default=4)
    q.add_argument('--seed',type=int,default=20260922);q.add_argument('--stage',choices=['pilot','main','extension','smoke'],default='pilot');q.add_argument('--out',required=True)
    for name in ('preflight','probe','freeze','prepare','run-block','run-stage','smoke','prepare-smoke','smoke-block','prepare-smoke-block'):
        q=sp.add_parser(name);q.add_argument('--site',required=True)
        if name in ('preflight','probe','freeze'): q.add_argument('--out',required=True)
        if name in ('probe','smoke','smoke-block','run-block','run-stage'): q.add_argument('--execute',action='store_true')
        if name in ('prepare','run-block','run-stage'): q.add_argument('--schedule',required=True)
        if name in ('run-block','run-stage'):
            q.add_argument('--freeze',required=True);q.add_argument('--approval',required=True)
        if name=='run-block': q.add_argument('--block',required=True)
        if name in ('smoke','prepare-smoke','smoke-block','prepare-smoke-block'):
            q.add_argument('--task',choices=['web','terminal','context'],default='web');q.add_argument('--condition',choices=['DIRECT','VISION','CACHE','BOTH'],default='BOTH');q.add_argument('--lane',type=int,default=0);q.add_argument('--run-id',required=True)
    a=p.parse_args(argv)
    if a.cmd=='schedule':
        s=make_schedule(a.tasks.split(','),a.blocks,a.seed,a.stage);atomic_json(Path(a.out),s)
        print(f"{s['logical_runs']} runs / {len(s['blocks'])} serial blocks written to {a.out}");return 0
    site=read_json(a.site);validate_site(site)
    if a.cmd in ('probe','smoke','smoke-block','run-block','run-stage') and not a.execute:
        p.error('explicit --execute required; no inference/runs have occurred')
    if a.cmd in ('preflight','probe'):
        from .preflight import inspect_site,capability_probes
        result=inspect_site(site) if a.cmd=='preflight' else capability_probes(site)
        atomic_json(Path(a.out),result);print(f'{a.cmd} evidence: {a.out}');return 0
    if a.cmd=='freeze':
        qualification=Path(site['qualification']['fixture_record'])
        if not qualification.is_absolute(): qualification=ROOT/qualification
        r=read_json(qualification)
        required=set(read_json(ROOT/'config/qualification.example.json')['checks'])
        if 'context' not in site['tasks']: required.discard('compaction_signal_calibrated')
        if r.get('qualified') is not True or not required.issubset(r.get('checks',{})) or not all(r['checks'][k] is True for k in required):
            raise ValueError('fixture qualification incomplete; do not fabricate passes')
        if r['site_sha256']!=object_hash(site): raise ValueError('qualification is not for this exact site')
        if site['measurement']['client_usage_semantics'] not in ('per_turn_delta','session_cumulative'):
            raise ValueError('calibrate client usage semantics first')
        evidence={}
        for name in r.get('evidence_files',[]):
            ep=Path(name)
            if not ep.is_absolute(): ep=ROOT/ep
            evidence[str(ep)]=sha256(ep)
        if not evidence: raise ValueError('qualification needs actual evidence files')
        from .dockerutil import assert_product,inspect_image
        f={'schema':'slaif-freeze-v2-single-lane','created_at':utc(),'site_sha256':object_hash(site),'kit_hashes':tree_hashes(ROOT),
           'product_inspection':assert_product(site),'worker_id':inspect_image(site['subject_worker_image'])['Id'],
           'qualification_sha256':sha256(qualification),'evidence_sha256':evidence,'site':site}
        atomic_json(Path(a.out),f);print('Freeze recorded; no campaign is authorized by freezing.');return 0
    from .runner import prepare_case,run_case,judge_case,run_block
    if a.cmd in ('smoke','prepare-smoke','smoke-block','prepare-smoke-block'):
        if not a.run_id.startswith('smoke-'): p.error('smoke run ID must start smoke-')
        if 'block' in a.cmd:
            order=list(CONDITIONS)
            random.Random(f'{site["seed"]}:{a.run_id}').shuffle(order)
            cases=[{'run_id':f'{a.run_id}-p{i:02d}-{condition.lower()}','task':a.task,
                    'condition':condition,'lane':0,'block':0,'task_seed':site['seed'],
                    'sequence_position':i,'previous_condition':order[i-2] if i>1 else None}
                   for i,condition in enumerate(order,1)]
            block={'block_id':a.run_id,'execution':'sequential','condition_order':order,
                  'possible_backend_carryover':True,'runs':cases}
            if a.cmd=='prepare-smoke-block':
                for c in cases: prepare_case(site,c)
                return 0
            r=run_block(site,block,prepared=True);print(json.dumps([x['status'] for x in r]));return 0
        c={'run_id':a.run_id,'task':a.task,'condition':a.condition,'lane':a.lane,'block':0,'task_seed':site['seed']}
        root=Path(site['workspace_root'])/c['run_id']
        if not root.exists(): prepare_case(site,c)
        if read_json(root/'case.json')!=c: raise ValueError('smoke case mismatch')
        if a.cmd=='prepare-smoke': print(root);return 0
        r=run_case(site,c,root);judge_case(site,c,root);print(json.dumps({'status':r['status'],'path':str(root)}));return 0
    schedule=read_json(a.schedule)
    validate_schedule(schedule)
    if schedule['tasks']!=site['tasks']: raise ValueError('schedule task set differs from frozen site')
    if a.cmd=='prepare':
        for block in schedule['blocks']:
            for c in block['runs']: prepare_case(site,c)
        print('Prepared all cases. Ensure adapter config ownership via scripts/prepare_permissions.py before dispatch.');return 0
    frozen=read_json(a.freeze);require_freeze(site,frozen)
    blocks=schedule['blocks'] if a.cmd=='run-stage' else [b for b in schedule['blocks'] if b['block_id']==a.block]
    if not blocks: raise ValueError('serial block not found')
    with lease(Path(site['workspace_root'])/'.dispatcher.lock'):
        for block in blocks:
            authorize(Path(a.approval),Path(a.freeze),schedule,block['block_id'],site['max_parallel'])
            require_freeze(site,frozen)
            r=run_block(site,block,prepared=True)
            print(json.dumps({'block':block['block_id'],'statuses':[x['status'] for x in r]}),flush=True)
            if any(not x.get('measurement_valid') or x.get('error_type') or x.get('protocol_violation') for x in r):
                raise RuntimeError('block requires reconciliation; no next block dispatched')
    return 0

if __name__=='__main__':
    try: raise SystemExit(main())
    except (ValueError,RuntimeError,FileNotFoundError,FileExistsError,PermissionError) as e:
        print(f'BLOCKED: {e}',file=sys.stderr);raise SystemExit(2)
