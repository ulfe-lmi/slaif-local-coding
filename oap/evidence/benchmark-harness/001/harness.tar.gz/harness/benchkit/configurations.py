from __future__ import annotations
import json
from .common import CONDITIONS

def toml_string(s: str) -> str: return json.dumps(s)

def adapter_toml(site: dict, case: dict) -> str|None:
    condition=case['condition']
    if condition not in CONDITIONS: raise ValueError('unknown condition')
    if condition=='DIRECT': return None
    lane=next(x for x in site['lanes'] if x['lane']==case['lane'])
    cache=condition in ('CACHE','BOTH');vision=condition in ('VISION','BOTH')
    tf=lambda x: 'true' if x else 'false'
    # Config is an EXPERIMENT input, not a mutation of the immutable product.
    text=f'''[server]
listen_host = "127.0.0.1"
listen_port = {lane['adapter_port']}
request_body_max_bytes = 67108864
response_body_max_bytes = 67108864
json_max_nesting_depth = 128

[gateway_ingress]
mode = "disabled"

[upstream]
base_url = {toml_string(lane['backend_url'])}
api_key_env = "BENCH_BACKEND_API_KEY"
model = {toml_string(site['served_model'])}
connect_timeout_seconds = 10
request_timeout_seconds = 600
write_timeout_seconds = 60
pool_timeout_seconds = 60

[compiler]
enabled = {tf(cache)}
api_key_env = "BENCH_BACKEND_API_KEY"
reasoning_effort = "low"
prompt_policy_version = "constitutional-rank-v2"
timeout_seconds = 120
max_attempts = 2
max_parallel_calls = 1
max_output_tokens = 3000

[cache]
root = "/dev/shm/slaif-local-coding"
max_total_bytes = 67108864
max_entry_bytes = 65536
max_pinned_bytes = 8388608
max_entries = 4096
ttl_seconds = 604800
max_scan_entries = 4096

[constitution]
enabled = {tf(cache)}
identity_source = "static"
'''
    if cache:
        text+=f'principal = "benchmark"\nsession = {toml_string(case["run_id"])}\nrepository = {toml_string(case["task"])}\n'
    text+='''max_injected_bytes = 16384
candidate_max_count = 128
working_set_max_entries = 128
acquisition_max_count = 128
entry_render_max_bytes = 8192
max_dependency_acquisitions = 4

[constitution.rehydration]
'''+f'enabled = {tf(cache)}\n'
    text+=f'''\n[[routes]]
name = "benchmark"
model = {toml_string(site['served_model'])}
image_overflow_policy = "{'retain_newest' if vision else 'passthrough'}"
'''
    if vision: text+='max_images_per_request = 1\n'
    # No hidden hosted-tool filtering in any adapter arm; it would confound DIRECT.
    text+=f'''responses_tool_policy = "passthrough"
enable_responses = true
enable_chat_completions = true
observation_enabled = {tf(cache)}
constitution_enabled = {tf(cache)}

[observability]
log_level = "INFO"
log_raw_payloads = false
metrics_enabled = true
metrics_host = "127.0.0.1"
'''
    return text

def subject_config(site: dict, case: dict) -> str:
    lane=next(x for x in site['lanes'] if x['lane']==case['lane'])
    url=lane['backend_url'] if case['condition']=='DIRECT' else f"http://127.0.0.1:{lane['adapter_port']}/v1"
    # All endpoint-independent subject settings are IDENTICAL across arms.
    s=f'''model = {toml_string(site['served_model'])}
model_provider = "qwen-LSI-A100"
model_catalog_json = "~/.codex/qwen-neumann-models.json"
model_reasoning_effort = {toml_string(site['codex']['reasoning_effort'])}
model_context_window = {int(site['context_window_tokens'])}
model_auto_compact_token_limit = {int(site['codex']['model_auto_compact_token_limit'])}
approval_policy = "never"
sandbox_mode = "danger-full-access"
web_search = "disabled"

[model_providers.qwen-LSI-A100]
name = "Qwen 3.8 27B benchmark measured lane"
base_url = {toml_string(url)}
env_key = "BENCH_API_KEY"
wire_api = "responses"
requires_openai_auth = false

[features]
apps = false
enable_mcp_apps = false
plugins = false
'''
    # Additional config overrides are passed via -c at launch, not text appended
    # under the provider table. Their exact values are frozen in the site record.
    return s
