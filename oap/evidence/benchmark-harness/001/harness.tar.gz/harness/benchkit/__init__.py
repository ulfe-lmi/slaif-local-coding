"""Standalone, external SLAIF experiment controller. No vLLM installation code."""
__version__ = "1.0.0"
