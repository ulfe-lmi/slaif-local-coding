"""Small Prometheus text parser. It stores only allowlisted numeric series."""
from __future__ import annotations
import math,re
from urllib.request import Request,urlopen

NAME=re.compile(r'^([A-Za-z_:][A-Za-z0-9_:]*)(?:\{(.*)\})?\s+([-+0-9.eE]+|[+-]?Inf|NaN)(?:\s+\S+)?$')
LABEL=re.compile(r'([A-Za-z_][A-Za-z0-9_]*)="((?:\\.|[^"\\])*)"')
ALLOWED_LABELS={'model_name','engine','engine_id','finished_reason','finish_reason','le','cache_type','reason','endpoint','route','status','stream','result','kind','component','evidence_type','outcome','state'}
ALLOWED_EXACT={'process_cpu_seconds_total','process_resident_memory_bytes','process_start_time_seconds'}

def parse_metrics(text: str) -> dict[str,float]:
    values={}
    for line in text.splitlines():
        if line.startswith('#'): continue
        m=NAME.fullmatch(line.strip())
        if not m: continue
        name,raw,val=m.groups()
        if not name.startswith(('vllm:','slaif_')) and name not in ALLOWED_EXACT: continue
        labels=LABEL.findall(raw or '')
        # Reject unknown/high-cardinality label sets; do not silently merge them.
        if any(k not in ALLOWED_LABELS for k,v in labels): continue
        if any(len(v)>512 for k,v in labels): continue
        key=name+('{' + ','.join(f'{k}="{v}"' for k,v in sorted(labels)) + '}' if labels else '')
        value=float(val)
        if not math.isfinite(value): continue
        values[key]=value
    return values

def scrape(url: str, key: str|None=None, timeout: float=5) -> dict:
    headers={'Accept':'text/plain'}
    if key: headers['Authorization']='Bearer '+key
    req=Request(url,headers=headers)
    try:
        with urlopen(req,timeout=timeout) as r:
            b=r.read(8*1024*1024+1)
            if len(b)>8*1024*1024: return {'ok':False,'error':'response_too_large'}
        return {'ok':True,'series':parse_metrics(b.decode('utf-8','replace'))}
    except Exception as e:
        # Never echo URL, response body, authorization, or exception payload.
        return {'ok':False,'error':type(e).__name__}

def total(series: dict[str,float], metric: str) -> float|None:
    vals=[v for k,v in series.items() if k==metric or k.startswith(metric+'{')]
    return sum(vals) if vals else None

def counter_delta(before: dict, after: dict, metric: str) -> dict:
    a={k:v for k,v in before.items() if k==metric or k.startswith(metric+'{')}
    b={k:v for k,v in after.items() if k==metric or k.startswith(metric+'{')}
    if not a or not b: return {'value':None,'status':'unavailable'}
    if a.keys()!=b.keys(): return {'value':None,'status':'series_changed'}
    if any(b[k]<v for k,v in a.items()): return {'value':None,'status':'counter_reset'}
    return {'value':sum(b[k]-v for k,v in a.items()),'status':'ok'}

def histogram_quantile_delta(before: dict, after: dict, base: str, quantile: float=.95) -> dict:
    buckets={}
    # +Inf label value survives parser (numeric sample itself must be finite).
    for k,v in after.items():
        if not k.startswith(base+'_bucket{'): continue
        m=re.search(r'le="([^"]+)"',k)
        if not m or k not in before or v<before[k]: return {'value':None,'status':'unavailable_or_reset'}
        try: edge=float(m.group(1))
        except ValueError: continue
        buckets[edge]=buckets.get(edge,0)+(v-before[k])
    if float('inf') not in buckets or buckets[float('inf')]<=0: return {'value':None,'status':'unavailable'}
    target=buckets[float('inf')]*quantile;previous_edge=0.;previous_n=0.
    for edge,n in sorted(buckets.items()):
        if n>=target:
            if math.isinf(edge): return {'value':previous_edge,'status':'upper_open_bucket_lower_bound'}
            value=edge if n==previous_n else previous_edge+(edge-previous_edge)*(target-previous_n)/(n-previous_n)
            return {'value':value,'status':'histogram_approximation'}
        previous_edge,previous_n=edge,n
    return {'value':None,'status':'unavailable'}
