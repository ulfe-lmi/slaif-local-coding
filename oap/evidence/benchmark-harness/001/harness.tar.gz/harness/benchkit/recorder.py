"""Read-only GPU/vLLM sampler. Works with V100, A100, and other nvidia-smi GPUs."""
from __future__ import annotations
import argparse,concurrent.futures,csv,io,json,os,signal,subprocess,time
from pathlib import Path
from .common import atomic_json,read_env,read_json,sha256,utc
from .metrics import scrape

GPU_FIELDS=('index','uuid','name','memory.total','memory.used','utilization.gpu',
            'utilization.memory','power.draw','temperature.gpu','clocks.sm','clocks.mem')

def nvidia_query(fields: tuple[str,...], mode: str='gpu') -> dict:
    argv=['nvidia-smi',f'--query-{mode}='+','.join(fields),'--format=csv,noheader,nounits']
    try:
        p=subprocess.run(argv,text=True,capture_output=True,timeout=5,check=True)
        rows=[]
        for row in csv.reader(io.StringIO(p.stdout)):
            if len(row)!=len(fields): continue
            item={}
            for k,v in zip(fields,row):
                v=v.strip()
                if v in ('N/A','[N/A]','Not Supported','[Not Supported]',''): item[k]=None
                else:
                    try: item[k]=float(v)
                    except ValueError: item[k]=v
            rows.append(item)
        return {'ok':True,'rows':rows}
    except Exception as e: return {'ok':False,'error':type(e).__name__}

def host_stats() -> dict:
    out={'load_average':list(os.getloadavg())}
    try:
        out['memory_kib']={s[0].rstrip(':'):int(s[1]) for l in Path('/proc/meminfo').read_text().splitlines()
                           if (s:=l.split()) and s[0] in ('MemTotal:','MemAvailable:','SwapTotal:','SwapFree:')}
        line=Path('/proc/stat').read_text().splitlines()[0].split()[1:]
        out['cpu_jiffies']=list(map(int,line))
    except (OSError,ValueError): out['proc_unavailable']=True
    return out

def sample(config: dict, secret: str|None) -> dict:
    start=time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,len(config['lanes']))) as pool:
        futures={x['lane']:pool.submit(scrape,x['metrics_url'],secret) for x in config['lanes']}
        lanes={str(k):f.result() for k,f in futures.items()}
    gpu=nvidia_query(GPU_FIELDS)
    wanted=set(config.get('gpu_uuids',[]))
    if gpu['ok'] and wanted:
        gpu['rows']=[x for x in gpu['rows'] if x['uuid'] in wanted]
        gpu['missing_uuids']=sorted(wanted-{x['uuid'] for x in gpu['rows']})
    # Process NAMES/argv are deliberately excluded; only numeric PID->GPU attribution.
    processes=nvidia_query(('gpu_uuid','pid','used_gpu_memory'),'compute-apps')
    return {'schema':'slaif-telemetry-sample-v1','utc':utc(),'unix_ns':time.time_ns(),
            'monotonic_ns':time.monotonic_ns(),'gpu':gpu,'compute_processes':processes,
            'host':host_stats(),'lanes':lanes,'scrape_duration_seconds':time.monotonic()-start}

def main(argv=None) -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--config',required=True);ap.add_argument('--duration',type=float,default=0)
    ap.add_argument('--once',action='store_true');args=ap.parse_args(argv)
    c=read_json(args.config)
    if 'CHANGE_ME' in json.dumps(c) or '/ABSOLUTE/' in json.dumps(c): ap.error('fill recorder config first')
    out=Path(c['output']);out.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    env=read_env(c['api_key_env_file']) if c.get('api_key_env_file') else {}
    key=env.get('BENCH_BACKEND_API_KEY');stop=False
    def stopping(*_):
        nonlocal stop;stop=True
    signal.signal(signal.SIGINT,stopping);signal.signal(signal.SIGTERM,stopping)
    # Refuse overwrite. Each daemon invocation uses its own output file.
    fd=os.open(out,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    atomic_json(out.with_suffix(out.suffix+'.manifest.json'),{'schema':'slaif-recorder-manifest-v1',
        'started_at':utc(),'config_sha256':sha256(Path(args.config)),'read_only':True,
        'gpu_fields':GPU_FIELDS,'device_family':'discovered_not_assumed','sampling_interval_seconds':c['interval_seconds'],
        'metric_labels_policy':'allowlisted; no request IDs, bodies or credentials'})
    start=time.monotonic();period=float(c['interval_seconds']);next_tick=start
    if period<.2: raise ValueError('sampling period must be at least 0.2 seconds')
    with os.fdopen(fd,'w',buffering=1) as f:
        while not stop:
            f.write(json.dumps(sample(c,key),sort_keys=True)+'\n')
            if args.once or (args.duration and time.monotonic()-start>=args.duration): break
            next_tick+=period
            # Do not fake missed samples or build up a catch-up queue.
            if next_tick<time.monotonic(): next_tick=time.monotonic()
            time.sleep(max(0,next_tick-time.monotonic()))
    return 0
