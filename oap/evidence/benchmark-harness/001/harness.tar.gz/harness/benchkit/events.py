"""Conservative event extraction: unavailable counters never become zero."""
from __future__ import annotations
import json
from pathlib import Path

TOKEN_KEYS = ("input_tokens", "output_tokens", "cached_input_tokens")

def _counter(value):
    return value if isinstance(value, int) and not isinstance(value, bool) and value >= 0 else None

def event_summary(paths: list[Path], usage_semantics: str) -> dict:
    usages = []; thread_ids = set(); tools = {}; image_views = 0; compactions = 0
    unknown = 0; agent_turns = 0; invalid_usage = 0
    for p in paths:
        for line in p.read_text(errors="replace").splitlines():
            try:
                wrapper = json.loads(line)
                e = wrapper.get("event", wrapper)
                if not isinstance(e, dict): raise ValueError("event is not an object")
            except (ValueError, AttributeError):
                unknown += 1; continue
            typ = e.get("type")
            if typ == "thread.started" and isinstance(e.get("thread_id"), str):
                thread_ids.add(e["thread_id"])
            if typ == "turn.completed":
                agent_turns += 1
                if isinstance(e.get("usage"), dict): usages.append(e["usage"])
                else: invalid_usage += 1
            item = e.get("item", {})
            if typ == "item.completed" and isinstance(item, dict):
                kind = str(item.get("type", "unknown")); tools[kind] = tools.get(kind, 0) + 1
                if kind in ("image_view", "view_image"): image_views += 1
            if typ in ("context_compacted", "compacted"): compactions += 1
    totals = None; status = "unavailable_or_uncalibrated"
    if usages and not invalid_usage and usage_semantics in ("per_turn_delta", "session_cumulative"):
        values = {k: [_counter(u.get(k)) for u in usages] for k in TOKEN_KEYS}
        # Input and output are necessary to interpret the total. Cached input is
        # optional and remains null if the installed client does not expose it.
        if all(all(v is not None for v in values[k]) for k in TOKEN_KEYS[:2]):
            monotonic = all(all(b >= a for a, b in zip(vs, vs[1:]))
                            for vs in values.values() if all(v is not None for v in vs))
            if usage_semantics == "per_turn_delta" or monotonic:
                totals = {k: (sum(vs) if usage_semantics == "per_turn_delta" else vs[-1])
                          if all(v is not None for v in vs) else None
                          for k, vs in values.items()}
                status = "calibrated"
            else: status = "cumulative_counter_decreased"
        else: status = "missing_or_invalid_essential_usage"
    return {"thread_ids": sorted(thread_ids), "client_usage_samples": usages,
            "client_usage_semantics": usage_semantics, "client_usage_status": status,
            "client_token_totals": totals, "completed_turns": agent_turns,
            "completed_item_counts": tools, "observed_image_view_events": image_views,
            "observed_stdout_compactions": compactions, "unparsed_lines": unknown,
            "note": "Image-view/compaction absence in exec JSON is not proof of zero activity; calibrate native rollout events."}

def rollout_compactions(home: Path) -> dict:
    structural = 0; notifications = 0; files = 0
    for p in home.rglob("*.jsonl"):
        if p.is_symlink(): continue
        files += 1
        with p.open(errors="replace") as handle:
            for line in handle:
                try: e = json.loads(line)
                except ValueError: continue
                if not isinstance(e, dict): continue
                typ = e.get("type"); payload = e.get("payload", {})
                if typ == "compacted": structural += 1
                elif typ == "event_msg" and isinstance(payload, dict) and payload.get("type") == "context_compacted":
                    notifications += 1
    # The same compaction may have a record AND a notification. Never sum them.
    count = structural if structural else notifications
    return {"count": count, "structural_records": structural,
            "notification_records": notifications, "files_seen": files,
            "count_source": "structural" if structural else "notification" if notifications else "none",
            "status": "observed" if count else "none_observed_or_not_exposed"}
