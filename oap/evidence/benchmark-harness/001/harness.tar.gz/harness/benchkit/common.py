from __future__ import annotations
import contextlib, datetime as dt, hashlib, json, os, re, subprocess, tempfile
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
CONDITIONS = ('DIRECT', 'VISION', 'CACHE', 'BOTH')
TASKS = ('web', 'terminal', 'context')
MODEL_CATALOG_SHA256 = 'c6ad4d996815941a07849ac931f239857614bae255ecab6a566c0e109539f08f'

def utc() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def object_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def read_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text())

def atomic_json(path: Path, value: Any, *, overwrite: bool = False) -> None:
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    if path.exists() and not overwrite: raise FileExistsError(path)
    fd, name=tempfile.mkstemp(dir=path.parent,prefix='.'+path.name)
    try:
        os.fchmod(fd,0o600)
        with os.fdopen(fd,'w') as f:
            json.dump(value,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
        # Refuse accidental overwrite; controller serializes its own writers.
        if path.exists() and not overwrite: raise FileExistsError(path)
        os.replace(name,path)
    finally:
        with contextlib.suppress(FileNotFoundError): os.unlink(name)

def read_env(path: str | Path) -> dict[str,str]:
    p=Path(path)
    if not p.is_file() or p.is_symlink(): raise ValueError('secret env must be a regular non-symlink file')
    if p.stat().st_mode & 0o077: raise ValueError(f'{p}: secrets file must be mode 0600 or stricter')
    result={}
    for line in p.read_text().splitlines():
        if not line.strip() or line.lstrip().startswith('#'): continue
        k,sep,v=line.partition('=')
        if not sep or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',k): raise ValueError('invalid env syntax')
        if '\n' in v or '\r' in v or not v or v.startswith('REPLACE_'): raise ValueError('unset/invalid env value')
        if k in result: raise ValueError('duplicate env key')
        result[k]=v
    return result

def redact(text: str, secrets: dict[str,str]) -> str:
    for value in sorted(secrets.values(),key=len,reverse=True):
        if value: text=text.replace(value,'[REDACTED]')
    return text

def run(argv: list[str], **kwargs: Any) -> subprocess.CompletedProcess:
    return subprocess.run(argv,check=True,text=True,capture_output=True,**kwargs)

def validate_site(site: dict, *, placeholders: bool=False) -> None:
    import ipaddress
    if site.get('schema')!='slaif-benchmark-site-v2-single-lane': raise ValueError('unsupported site schema')
    if site.get('conditions') != list(CONDITIONS): raise ValueError('freeze all four conditions in canonical order')
    if not site.get('tasks') or any(t not in TASKS for t in site['tasks']): raise ValueError('unknown task')
    if len(set(site['tasks'])) != len(site['tasks']): raise ValueError('duplicate task')
    if site.get('execution_mode')!='single-lane-sequential': raise ValueError('execution_mode must be single-lane-sequential')
    if site.get('max_parallel')!=1: raise ValueError('single-lane execution requires max_parallel=1')
    if len(site.get('lanes',[]))!=1: raise ValueError('exactly one measured lane definition required')
    if {x['lane'] for x in site['lanes']} != {0}: raise ValueError('the measured lane must be numbered 0')
    ports=[x[k] for x in site['lanes'] for k in ('adapter_port','app_port')]
    if len(set(ports))!=2: raise ValueError('VM ports overlap')
    for p in ports:
        if not isinstance(p,int) or not 1024<=p<=65535: raise ValueError('invalid VM port')
    if not placeholders:
        if any(x in json.dumps(site) for x in ('CHANGE_ME','/ABSOLUTE/','REPLACE_')):
            raise ValueError('site still contains placeholders; no execution allowed')
        host=ipaddress.ip_address(site['host_lan_ip'])
        if host.is_loopback or host.is_unspecified: raise ValueError('host must be its explicit LAN address, not VM loopback')
        for lane in site['lanes']:
            for key in ('backend_url','metrics_url'):
                u=urlsplit(lane[key])
                if u.scheme not in ('http','https') or u.username or u.password: raise ValueError('invalid URL or credentials in URL')
                if u.hostname!=str(host): raise ValueError('every inference/metrics URL must use the configured host LAN IP')
            if urlsplit(lane['backend_url']).path.rstrip('/')!='/v1': raise ValueError('backend base must end /v1')
        if not re.fullmatch(r'sha256:[0-9a-f]{64}|[^\s]+@sha256:[0-9a-f]{64}',site['subject_worker_image']):
            raise ValueError('worker must be frozen by image ID or registry digest')
        if not re.fullmatch(r'[^\s]+@sha256:[0-9a-f]{64}',site['product']['image']): raise ValueError('product digest required')
        if not Path(site['workspace_root']).is_absolute(): raise ValueError('workspace_root must be absolute')
    if site['codex']['mode']!='exec-resume': raise ValueError('automatic driver supports exec-resume only; native /goal is manual and separate')
    if site['codex']['reasoning_effort']!='xhigh': raise ValueError('subject reasoning_effort must be xhigh')
    if site['codex'].get('additional_config') != {}: raise ValueError('additional Codex overrides are forbidden for the frozen subject configuration')
    if not 0<site['codex']['model_auto_compact_token_limit']<site['context_window_tokens']: raise ValueError('invalid compaction limit')
    catalog_path=ROOT/'config'/'qwen-neumann-models.json'
    if sha256(catalog_path)!=MODEL_CATALOG_SHA256: raise ValueError('model catalog bytes differ from the human-supplied catalog')
    catalog=read_json(catalog_path)
    models=catalog.get('models',[])
    if len(models)!=1 or models[0].get('slug')!=site['served_model']: raise ValueError('model catalog does not match served_model')
    model=models[0]
    if model.get('default_reasoning_level')!='xhigh': raise ValueError('model catalog default reasoning must be xhigh')
    if model.get('context_window')!=site['context_window_tokens'] or model.get('max_context_window')!=site['context_window_tokens']:
        raise ValueError('model catalog context window does not match site')
    if model.get('auto_compact_token_limit')!=site['codex']['model_auto_compact_token_limit']:
        raise ValueError('model catalog compaction limit does not match site')

@contextlib.contextmanager
def lease(path: Path):
    import fcntl
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    with path.open('a+') as f:
        try: fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise RuntimeError(f'lease is held: {path}') from None
        try: yield
        finally: fcntl.flock(f,fcntl.LOCK_UN)

def tree_hashes(root: Path) -> dict[str,str]:
    skip={'.git','.local','runs','state','secrets','__pycache__','.pytest_cache','.venv'}
    out={}
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root)
        if any(x in skip for x in rel.parts) or p.is_symlink(): continue
        if p.is_file() and rel.as_posix() not in ('MANIFEST.sha256','VALIDATION.json'):
            out[rel.as_posix()]=sha256(p)
    return out
