from collections import Counter
import pytest
from benchkit.schedule import make_schedule,validate_schedule
from benchkit.common import CONDITIONS
@pytest.mark.parametrize('tasks', [['web','terminal'],['web','terminal','context']])
@pytest.mark.parametrize('blocks', [4,12,16])
def test_balance(tasks,blocks):
    s=make_schedule(tasks,blocks,11,'main')
    assert s['logical_runs']==4*len(tasks)*blocks
    assert len(s['blocks'])==len(tasks)*blocks
    ids=set();counts=Counter()
    for w in s['blocks']:
        assert {r['condition'] for r in w['runs']}==set(CONDITIONS)
        assert [r['lane'] for r in w['runs']]==[0,0,0,0]
        assert [r['condition'] for r in w['runs']]==w['condition_order']
        assert [r['sequence_position'] for r in w['runs']]==[1,2,3,4]
        assert [r['previous_condition'] for r in w['runs']]==[None,*w['condition_order'][:-1]]
        assert len({r['task_seed'] for r in w['runs']})==1
        for x in w['runs']:
            assert x['run_id'] not in ids;ids.add(x['run_id'])
            counts[x['task'],x['condition']]+=1
    assert set(counts.values())=={blocks}
    for task in tasks:
        task_blocks=[w for w in s['blocks'] if w['task']==task]
        for cycle in range(blocks//4):
            ws=task_blocks[cycle*4:(cycle+1)*4]
            for position in range(4):
                assert {w['condition_order'][position] for w in ws}==set(CONDITIONS)
            transitions=[(a,b) for w in ws for a,b in zip(w['condition_order'],w['condition_order'][1:])]
            assert len(transitions)==12 and len(set(transitions))==12
def test_reproducible():
    assert make_schedule(['web'],4,10,'pilot')==make_schedule(['web'],4,10,'pilot')
    assert make_schedule(['web'],4,10,'pilot')!=make_schedule(['web'],4,11,'pilot')
    assert make_schedule(['web'],4,10,'pilot')['max_parallel']==1
@pytest.mark.parametrize('blocks', [0,-4,1,3,10,15])
def test_reject_unbalanced(blocks):
    with pytest.raises(ValueError):make_schedule(['web'],blocks,1,'main')

@pytest.mark.parametrize('mutation', ['parallel','lane','order','carryover','duplicate'])
def test_reject_malformed_single_lane_schedule(mutation):
    import copy
    schedule=make_schedule(['web'],4,11,'main');bad=copy.deepcopy(schedule)
    if mutation=='parallel':bad['max_parallel']=4
    if mutation=='lane':bad['blocks'][0]['runs'][0]['lane']=1
    if mutation=='order':bad['blocks'][0]['condition_order'].reverse()
    if mutation=='carryover':bad['blocks'][0]['runs'][1]['previous_condition']=None
    if mutation=='duplicate':bad['blocks'][0]['runs'][1]['run_id']=bad['blocks'][0]['runs'][0]['run_id']
    with pytest.raises(ValueError):validate_schedule(bad)
