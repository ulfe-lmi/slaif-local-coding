import copy,datetime as dt,json,os,subprocess,sys
from pathlib import Path
import pytest
from benchkit.common import ROOT,atomic_json,object_hash,sha256
from benchkit.cli import authorize
from benchkit.runner import capture_container_logs,stream_exec,pressure_prompt
from benchkit.schedule import make_schedule
from oracle import Board
from context_judge import score

def test_oracle_flood_win():
    b=Board(3,3,[[0,0]]);b.reveal((2,2));assert b.status=='won' and len(b.revealed)==8

def test_oracle_flag_blocks_and_loss():
    b=Board(3,3,[[0,0]]);b.flag((0,0));b.reveal((0,0));assert b.status=='ready'
    b.flag((0,0));b.reveal((0,0));assert b.status=='lost';old=b.expected();b.reveal((2,2));assert b.expected()==old

def test_context_judge_controls():
    key=json.loads((ROOT/'evaluators/context_answer_key.json').read_text())
    assert score(copy.deepcopy(key),key)['functional_success']
    bad=copy.deepcopy(key);bad['facts'][0]['value']='WRONG';assert not score(bad,key)['functional_success']
    bad=copy.deepcopy(key);bad['facts'].append(bad['facts'][0]);assert not score(bad,key)['functional_success']
    assert score({},key)['facts_correct_with_source']==0

def test_subject_no_judges_or_solutions():
    for t in ('web','terminal','context'):
        d=ROOT/'tasks'/t
        for f in ('AGENTS.md','ARCHITECTURE.md','PROMPT.md','GOAL.md','SLASH_GOAL.txt'):assert (d/f).is_file()
        assert not any(p.suffix=='.py' for p in d.rglob('*'))
        assert len((d/'SLASH_GOAL.txt').read_text())<4000
    assert 'Playwright' in (ROOT/'tasks/web/ARCHITECTURE.md').read_text()
    assert 'Do not use Playwright' in (ROOT/'tasks/terminal/AGENTS.md').read_text()

def test_judge_controls_use_invoking_uid_gid():
    text=(ROOT/'scripts/judge_controls.py').read_text()
    assert "'--user',f'{os.getuid()}:{os.getgid()}'" in text

def test_judge_controls_run_as_vm_operator_not_remapped_container_root():
    text=(ROOT/'scripts/judge_controls.py').read_text()
    assert "'--user',f'{os.getuid()}:{os.getgid()}'" in text

def test_pressure_deterministic(site):
    c={'task_seed':1};a=pressure_prompt(site,c,1)
    assert a==pressure_prompt(site,c,1) and a!=pressure_prompt(site,c,2)
    assert len(a)>=site['context_task']['bytes_per_phase']

def test_approval_binds_stage_and_schedule(tmp_path):
    f=tmp_path/'freeze.json';atomic_json(f,{'x':1});s={'stage':'pilot'}
    a={'schema':'slaif-stage-approval-v2-single-lane','reviewed_by_human':True,'freeze_sha256':sha256(f),'schedule_sha256':object_hash(s),
       'stage':'pilot','allowed_block_ids':['block1'],'parallelism':1,
       'not_after':(dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=1)).isoformat()}
    p=tmp_path/'approval.json';atomic_json(p,a)
    authorize(p,f,s,'block1',1)
    for altered,w,parallel in [({'stage':'main'},'block1',1),(s,'block2',1),(s,'block1',4)]:
        with pytest.raises(ValueError):authorize(p,f,altered,w,parallel)

def test_expired_approval(tmp_path):
    f=tmp_path/'f';atomic_json(f,{});s={'stage':'main'}
    p=tmp_path/'a';atomic_json(p,{'schema':'slaif-stage-approval-v2-single-lane','reviewed_by_human':True,'freeze_sha256':sha256(f),'schedule_sha256':object_hash(s),
      'stage':'main','allowed_block_ids':['b'],'parallelism':1,'not_after':'2000-01-01T00:00:00+00:00'})
    with pytest.raises(ValueError):authorize(p,f,s,'b',1)

def test_stream_exec_real_subprocess_and_redaction(tmp_path):
    import time
    code='import json; print(json.dumps({"type":"thread.started","thread_id":"t1"})); print(json.dumps({"type":"message","text":"SECRET42"}))'
    o=tmp_path/'e';e=tmp_path/'stderr'
    r=stream_exec([sys.executable,'-c',code],'',o,e,time.monotonic()+5,{'key':'SECRET42'},10000)
    assert r['returncode']==0 and r['thread_id']=='t1' and not r['timeout']
    assert 'SECRET42' not in o.read_text() and '[REDACTED]' in o.read_text()

def test_stream_exec_deadline(tmp_path):
    import time
    r=stream_exec([sys.executable,'-c','import time; time.sleep(30)'],'',tmp_path/'e',tmp_path/'err',time.monotonic()+.1,{},1000)
    assert r['timeout']

def test_adapter_log_capture_is_private_bounded_and_redacted(tmp_path,monkeypatch):
    class Result:
        returncode=0;stdout='prefix SECRET42 '+('x'*200);stderr='suffix SECRET42'
    monkeypatch.setattr(subprocess,'run',lambda *a,**k:Result())
    path=tmp_path/'adapter.private.log'
    result=capture_container_logs('owned',path,{'key':'SECRET42'},64)
    assert result['truncated'] and result['bytes']==64
    assert 'SECRET42' not in path.read_text() and path.stat().st_mode&0o777==0o600

def test_schedule_cli(tmp_path):
    out=tmp_path/'s.json'
    p=subprocess.run([sys.executable,str(ROOT/'scripts/bench.py'),'schedule','--tasks','web,terminal','--blocks','4','--out',str(out)],capture_output=True,text=True)
    schedule=json.loads(out.read_text())
    assert p.returncode==0 and schedule['logical_runs']==32 and schedule['max_parallel']==1

def test_inference_cli_requires_execute(site,tmp_path):
    f=tmp_path/'site';atomic_json(f,site)
    p=subprocess.run([sys.executable,str(ROOT/'scripts/bench.py'),'probe','--site',str(f),'--out',str(tmp_path/'p')],capture_output=True,text=True)
    assert p.returncode!=0 and '--execute required' in p.stderr
    assert not (tmp_path/'p').exists()

def test_block_dispatch_is_serial_and_judges_after_generation(site,tmp_path,monkeypatch):
    import benchkit.runner as runner
    site['workspace_root']=str(tmp_path)
    block=make_schedule(['web'],4,7,'pilot')['blocks'][0]
    events=[]
    for case in block['runs']:
        root=tmp_path/case['run_id'];root.mkdir();atomic_json(root/'case.json',case)
    def fake_run(_site,case,_root):
        events.append(('run',case['condition']))
        return {'measurement_valid':True,'case':case,'status':'SUBMITTED'}
    def fake_judge(_site,case,_root):events.append(('judge',case['condition']))
    monkeypatch.setattr(runner,'run_case',fake_run);monkeypatch.setattr(runner,'judge_case',fake_judge)
    results=runner.run_block(site,block,prepared=True)
    assert len(results)==4
    assert events==[('run',x) for x in block['condition_order']]+[('judge',x) for x in block['condition_order']]

def test_block_stops_after_broken_measurement(site,tmp_path,monkeypatch):
    import benchkit.runner as runner
    site['workspace_root']=str(tmp_path)
    block=make_schedule(['web'],4,8,'pilot')['blocks'][0]
    for case in block['runs']:
        root=tmp_path/case['run_id'];root.mkdir();atomic_json(root/'case.json',case)
    called=[]
    def fake_run(_site,case,_root):
        called.append(case['condition'])
        return {'measurement_valid':len(called)==1,'case':case,'status':'INFRASTRUCTURE_ERROR' if len(called)>1 else 'SUBMITTED'}
    monkeypatch.setattr(runner,'run_case',fake_run);monkeypatch.setattr(runner,'judge_case',lambda *_:None)
    assert len(runner.run_block(site,block,prepared=True))==2
    assert called==block['condition_order'][:2]
