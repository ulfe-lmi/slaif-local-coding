from pathlib import Path
import copy,json,sys
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'evaluators')]
@pytest.fixture
def site(tmp_path):
    s=json.loads((ROOT/'config/site.example.json').read_text())
    s.update(host_lan_ip='192.0.2.20',served_model='qwen3.8-27b',model_checkpoint_revision='a'*40,
             vllm_version='existing-version',subject_worker_image='sha256:'+'a'*64,
             codex_version='0.149.0',workspace_root=str(tmp_path/'runs'),secret_env_file=str(tmp_path/'backend.env'))
    s['measurement']['client_usage_semantics']='per_turn_delta'
    lane=s['lanes'][0]
    lane['gpu_uuid']='GPU-measured';lane['backend_url']='http://192.0.2.20:18043/v1'
    lane['metrics_url']='http://192.0.2.20:18043/metrics'
    return s
