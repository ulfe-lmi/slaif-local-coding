import json,math
from pathlib import Path
import pytest
from benchkit.metrics import parse_metrics,counter_delta,histogram_quantile_delta,total
from benchkit.events import event_summary,rollout_compactions
from benchkit.analysis import describe,paired_ratio

def test_prometheus_allowlist():
    text='# TYPE vllm:prompt_tokens_total counter\nvllm:prompt_tokens_total{model_name="test",engine="0"} 100\nvllm:generation_tokens_total{request_id="private"} 9\nslaif_requests_total{endpoint="/v1/responses",route="benchmark",status="200",stream="true"} 3\nunrelated_secret_metric 4\nprocess_cpu_seconds_total 1.5\nvllm:bad NaN\n'
    s=parse_metrics(text)
    assert total(s,'vllm:prompt_tokens_total')==100
    assert total(s,'slaif_requests_total')==3
    assert total(s,'vllm:generation_tokens_total') is None
    assert len(s)==3
@pytest.mark.parametrize('a,b,status,value', [({}, {},'unavailable',None),({'x':1},{'x':4},'ok',3),
  ({'x':4},{'x':1},'counter_reset',None),({'x{a="b"}':1},{'x{a="c"}':2},'series_changed',None)])
def test_counter(a,b,status,value):assert counter_delta(a,b,'x')=={'status':status,'value':value}
def test_histogram():
    a={'h_bucket{le="1"}':0,'h_bucket{le="2"}':0,'h_bucket{le="+Inf"}':0}
    b={'h_bucket{le="1"}':5,'h_bucket{le="2"}':10,'h_bucket{le="+Inf"}':10}
    assert histogram_quantile_delta(a,b,'h',.95)['value']==pytest.approx(1.9)
def events(tmp_path,rows):
    p=tmp_path/'events.jsonl';p.write_text(''.join(json.dumps(x)+'\n' for x in rows));return p

def test_event_totals_and_missing_cache(tmp_path):
    p=events(tmp_path,[{'type':'thread.started','thread_id':'t'}, {'type':'turn.completed','usage':{'input_tokens':3,'output_tokens':2}},
       {'type':'turn.completed','usage':{'input_tokens':4,'output_tokens':5}}])
    x=event_summary([p],'per_turn_delta')
    assert x['client_token_totals']=={'input_tokens':7,'output_tokens':7,'cached_input_tokens':None}
    assert x['thread_ids']==['t']
def test_unknown_usage_does_not_guess(tmp_path):
    p=events(tmp_path,[{'type':'turn.completed','usage':{'input_tokens':3,'output_tokens':2}}])
    assert event_summary([p],'unverified')['client_token_totals'] is None
@pytest.mark.parametrize('usage',[{'output_tokens':2},{'input_tokens':3},{'input_tokens':-1,'output_tokens':2},{'input_tokens':True,'output_tokens':2}])
def test_bad_usage_no_zero(tmp_path,usage):
    p=events(tmp_path,[{'type':'turn.completed','usage':usage}])
    assert event_summary([p],'per_turn_delta')['client_token_totals'] is None
def test_cumulative_not_summed(tmp_path):
    p=events(tmp_path,[{'type':'turn.completed','usage':{'input_tokens':3,'output_tokens':2}},
                     {'type':'turn.completed','usage':{'input_tokens':7,'output_tokens':5}}])
    assert event_summary([p],'session_cumulative')['client_token_totals']['input_tokens']==7
def test_cumulative_reset(tmp_path):
    p=events(tmp_path,[{'type':'turn.completed','usage':{'input_tokens':7,'output_tokens':5}},
                     {'type':'turn.completed','usage':{'input_tokens':3,'output_tokens':2}}])
    assert event_summary([p],'session_cumulative')['client_token_totals'] is None
def test_no_compaction_double_count_or_prose(tmp_path):
    events(tmp_path,[{'type':'compacted'},{'type':'event_msg','payload':{'type':'context_compacted'}},
                    {'type':'message','text':'compacted compacted'}])
    x=rollout_compactions(tmp_path)
    assert x['count']==1 and x['structural_records']==1 and x['notification_records']==1
def test_empty_stats():assert describe([])['mean'] is None
def test_paired_ratio():
    r=paired_ratio([(2,1),(4,2),(6,3)],nboot=100)
    assert r['ratio']==2 and r['ci95']==[2,2]
def test_invalid_ratios_excluded():assert paired_ratio([(0,1),(None,2),(2,1)])['n_pairs']==1
