"""Reference CONTROL only. The control runner adds oracle.py to this package."""
import argparse,curses,json,os
from pathlib import Path
from .oracle import Board
p=argparse.ArgumentParser();p.add_argument('--rows',type=int,default=9);p.add_argument('--cols',type=int,default=9);p.add_argument('--mines',type=int,default=10);p.add_argument('--seed',type=int,default=0);p.add_argument('--test-layout',default='0,0');p.add_argument('--state-file',required=True);a=p.parse_args()
BAD_CONTROL=False
mines=[list(map(int,x.split(','))) for x in a.test_layout.split(';')]
def game(s):
    b=Board(a.rows,a.cols,mines);cur=[0,0];s.keypad(True);curses.curs_set(0)
    while True:
        s.erase();s.addstr(0,0,b.status.upper());s.addstr(1,0,'h/j/k/l move, space reveal, f flag, r restart, q quit')
        for r in range(b.rows):
            for c in range(b.cols):
                pt=(r,c);v='F' if pt in b.flagged else '*' if pt in b.revealed&b.mines else (str(b.count(pt)) if b.count(pt) else '.') if pt in b.revealed else '#'
                s.addstr(2+r,c,v,curses.A_REVERSE if cur==[r,c] else 0)
        s.refresh();state=b.expected();state['cursor']=cur[:];path=Path(a.state_file);tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(state));tmp.replace(path)
        k=s.getch()
        if k==ord('q'):return
        if k==ord('r'):b=Board(a.rows,a.cols,mines);cur=[0,0];continue
        if b.status in ('lost','won'):continue
        if k in (ord('h'),curses.KEY_LEFT):cur[1]=max(0,cur[1]-1)
        elif k in (ord('l'),curses.KEY_RIGHT):cur[1]=min(b.cols-1,cur[1]+1)
        elif k in (ord('j'),curses.KEY_DOWN):cur[0]=min(b.rows-1,cur[0]+1)
        elif k in (ord('k'),curses.KEY_UP):cur[0]=max(0,cur[0]-1)
        elif k==ord('f') and not BAD_CONTROL:b.flag(cur)
        elif k in (32,10,13):b.reveal(cur)
curses.wrapper(game)
