#!/usr/bin/env python3
"""Run positive and deliberately defective controls in the VM subject toolbox, no model calls."""
import argparse,json,os,shutil,subprocess,tempfile,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from benchkit.common import ROOT,atomic_json
p=argparse.ArgumentParser();p.add_argument('--worker-image',required=True);p.add_argument('--out',required=True);p.add_argument('--execute',action='store_true');a=p.parse_args()
if not a.execute:raise SystemExit('explicit --execute required (VM containers only; no vLLM action)')
results=[]
with tempfile.TemporaryDirectory(prefix='slaif-judge-controls-') as tmp:
    for task in ('web','terminal','context'):
        for bad in (False,True):
            root=Path(tmp)/f'{task}-{bad}';work=root/'work';out=root/'out';out.mkdir(parents=True)
            if task=='context':
                work.mkdir();data=json.loads((ROOT/'evaluators/context_answer_key.json').read_text())
                if bad:data['facts'][0]['value']='WRONG'
                (work/'facts.json').write_text(json.dumps(data))
            else:
                shutil.copytree(ROOT/'tests/judge_controls'/task,work)
                if task=='terminal':shutil.copyfile(ROOT/'evaluators/oracle.py',work/'minesweeper/oracle.py')
                if bad:
                    f=work/('index.html' if task=='web' else 'minesweeper/__main__.py')
                    s=f.read_text();s=s.replace('<script>','<script>window.BAD_CONTROL=true;') if task=='web' else s.replace('BAD_CONTROL=False','BAD_CONTROL=True');f.write_text(s)
            cmd=['docker','run','--rm','--network','none','--cap-drop','ALL','--security-opt','no-new-privileges',
                 '--read-only','--tmpfs','/tmp:rw,size=1g','--tmpfs','/dev/shm:rw,size=512m',
                 '--user',f'{os.getuid()}:{os.getgid()}','-e','HOME=/tmp',
                 '-v',f'{work}:/work','-v',f'{out}:/out','-v',f'{ROOT/"evaluators"}:/judge:ro',
                 '-w','/work',a.worker_image,'python3',f'/judge/{task}_judge.py','--work','/work','--output','/out/judge.json']
            proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
            score=json.loads((out/'judge.json').read_text()) if (out/'judge.json').exists() else {'status':'JUDGE_INFRASTRUCTURE_ERROR'}
            expected=not bad;ok=proc.returncode==0 and score.get('functional_success') is expected
            results.append({'task':task,'control':'defective' if bad else 'correct','expected_success':expected,'passed':ok,'judge':score})
atomic_json(Path(a.out),{'model_calls':0,'checks':results,'all_passed':all(x['passed'] for x in results)})
if not all(x['passed'] for x in results):raise SystemExit(1)
