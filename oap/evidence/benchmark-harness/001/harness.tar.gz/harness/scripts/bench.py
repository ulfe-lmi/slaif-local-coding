#!/usr/bin/env python3
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from benchkit.cli import main
if __name__ == '__main__':
    try: raise SystemExit(main())
    except (ValueError, RuntimeError, FileNotFoundError, FileExistsError, PermissionError) as exc:
        print(f"BLOCKED: {exc}", file=sys.stderr)
        raise SystemExit(2)
