#!/usr/bin/env python3
"""Export metadata timelines and an optional cumulative backend-token plot."""
import argparse,csv,json,math,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from benchkit.common import read_json
from benchkit.metrics import counter_delta
p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--out',required=True)
p.add_argument('--plot',action='store_true');a=p.parse_args()
r=Path(a.run);out=Path(a.out)
if out.exists():raise SystemExit('version timeline outputs; destination exists')
out.mkdir(parents=True);record=read_json(r/'result.json');start=record['measurement_start_ns']
before=read_json(r/'metrics-before.json').get('series',{});points=[]
for line in (r/'metrics.jsonl').open():
    x=json.loads(line);series=x.get('backend',{}).get('series',{})
    inp=counter_delta(before,series,'vllm:prompt_tokens_total');gen=counter_delta(before,series,'vllm:generation_tokens_total')
    valid=inp['status']==gen['status']=='ok'
    points.append({'elapsed_seconds':(x['unix_ns']-start)/1e9,'backend_input_tokens':inp['value'],
                   'backend_output_tokens':gen['value'],'backend_gross_tokens':inp['value']+gen['value'] if valid else None,
                   'input_status':inp['status'],'output_status':gen['status']})
if points:
    with (out/'backend_timeline.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(points[0]));w.writeheader();w.writerows(points)
# Extract types/counts, NOT raw tool commands, code, images or prompt content.
events=[]
for f in sorted(r.glob('events-*.jsonl')):
    for line in f.open():
        x=json.loads(line);e=x.get('event',{});item=e.get('item',{})
        if not isinstance(e,dict):continue
        events.append({'elapsed_seconds':(x['unix_ns']-start)/1e9,'event_type':e.get('type'),
                       'item_type':item.get('type') if isinstance(item,dict) else None})
if events:
    with (out/'client_events.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(events[0]));w.writeheader();w.writerows(events)
shots=r/'work/artifacts/screenshot-events.jsonl'
if shots.is_file():
    rows=[]
    for line in shots.open():
        s=json.loads(line);rows.append({k:s.get(k) for k in ('kind','unix_ns','width','height','bytes')})
    if rows:
        with (out/'generated_screenshots.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
if a.plot:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(8,5))
    ax.step([x['elapsed_seconds'] for x in points],
            [x['backend_gross_tokens'] if x['backend_gross_tokens'] is not None else math.nan for x in points],where='post')
    ax.set(xlabel='Elapsed seconds',ylabel='Cumulative backend input + output tokens',
           title=record['case']['run_id'])
    fig.tight_layout();fig.savefig(out/'cumulative_tokens.png',dpi=160);plt.close(fig)
print(out)
