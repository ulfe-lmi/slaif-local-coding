#!/usr/bin/env python3
"""Attach blinded ratings as NEW evidence; never rewrite functional judgments."""
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from benchkit.common import atomic_json,read_json,sha256
p=argparse.ArgumentParser();p.add_argument('--runs',required=True);p.add_argument('--mapping',required=True)
p.add_argument('--ratings',required=True);p.add_argument('--min-raters',type=int,default=2);a=p.parse_args()
if a.min_raters<1:raise SystemExit('at least one rater required')
mapping={x['case']:x['run_id'] for x in read_json(a.mapping)};groups={}
for f in sorted(Path(a.ratings).rglob('rating.json')):
    r=read_json(f);alias=r.get('case');who=r.get('rater');scores=r.get('scores')
    if alias not in mapping:raise SystemExit('rating case is not in the private mapping')
    if not isinstance(who,str) or not who.strip():raise SystemExit('missing rater identity')
    if not isinstance(scores,list) or len(scores)!=5 or any(type(x) is not int or not 0<=x<=4 for x in scores):
        raise SystemExit('all five scores must be integers 0..4')
    if who in [x['rater'] for x in groups.get(alias,[])]:raise SystemExit('duplicate rater/case')
    groups.setdefault(alias,[]).append({'rater':who,'scores':scores,'rating_sha256':sha256(f)})
prepared=[]
for alias,ratings in groups.items():
    if len(ratings)<a.min_raters:raise SystemExit('insufficient independent ratings')
    means=[sum(x['scores'][i] for x in ratings)/len(ratings) for i in range(5)]
    result={'schema':'slaif-visual-rating-v1','run_id':mapping[alias],'n_raters':len(ratings),
            'dimension_means':means,'visual_score':sum(means),'visual_success':sum(means)>=14 and min(means)>=2,
            'aggregation':'predeclared equal-rater mean per dimension; preserve originals','ratings':ratings}
    dest=Path(a.runs)/mapping[alias]/'visual-rating.json'
    if not (dest.parent/'result.json').is_file():raise SystemExit('rating does not resolve to a measured run')
    if dest.exists():raise SystemExit('rating evidence exists; do not overwrite')
    prepared.append((dest,result))
for path,result in prepared:atomic_json(path,result)
print(f'Attached {len(prepared)} visual judgments; original run/functional evidence unchanged.')
