#!/usr/bin/env bash
set -euo pipefail
# VM-only optional build of the subject toolbox. NEVER a vLLM setup script.
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
: "${CODEX_VERSION:?Set an exact Codex version after verifying compatibility (reference: 0.149.0)}"
PLAYWRIGHT_VERSION="${PLAYWRIGHT_VERSION:-1.55.0}"
BASE="mcr.microsoft.com/playwright/python:v${PLAYWRIGHT_VERSION}-noble"
[[ "$CODEX_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo 'Exact Codex version required' >&2; exit 1; }
docker pull "$BASE"
PINNED_BASE="$(docker image inspect "$BASE" --format '{{index .RepoDigests 0}}')"
[[ "$PINNED_BASE" == *@sha256:* ]] || exit 1
docker build --build-arg PLAYWRIGHT_BASE="$PINNED_BASE" \
  --build-arg CODEX_VERSION="$CODEX_VERSION" --build-arg PLAYWRIGHT_VERSION="$PLAYWRIGHT_VERSION" \
  -t slaif-benchmark-subject:local "$ROOT/worker"
mkdir -p "$ROOT/.local"
docker image inspect slaif-benchmark-subject:local > "$ROOT/.local/subject-image-inspect.json"
docker run --rm --network none slaif-benchmark-subject:local codex --version
docker run --rm --network none slaif-benchmark-subject:local python3 -m pip freeze > "$ROOT/.local/subject-pip-freeze.txt"
docker run --rm --network none slaif-benchmark-subject:local npm list -g --depth=0 > "$ROOT/.local/subject-npm-list.txt"
printf '
Put this exact local image ID in config/site.json subject_worker_image:
'
docker image inspect slaif-benchmark-subject:local --format '{{.Id}}'
