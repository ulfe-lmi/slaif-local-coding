#!/usr/bin/env python3
import argparse,json,random,shutil
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--runs',required=True);p.add_argument('--out',required=True);p.add_argument('--seed',type=int,default=391);a=p.parse_args()
out=Path(a.out);out.mkdir(mode=0o700);folders=list(Path(a.runs).glob('*/evaluation'))
random.Random(a.seed).shuffle(folders);mapping=[]
for i,d in enumerate(folders):
    if not (d/'desktop.png').is_file():continue
    alias=f'case-{i:04d}';dest=out/alias;dest.mkdir()
    for name in ('desktop.png','mobile.png'):
        f=d/name
        if f.is_file():shutil.copyfile(f,dest/name)
    (dest/'rating.json').write_text(json.dumps({'case':alias,'rater':'','scores':[None]*5,'notes':''},indent=2)+'\n')
    mapping.append({'case':alias,'run_id':d.parent.name})
# Mapping lives OUTSIDE the rater package.
(out.parent/(out.name+'-PRIVATE-MAPPING.json')).write_text(json.dumps(mapping,indent=2)+'\n')
print('Give only the anonymized directory and VISUAL_RUBRIC.md to the raters.')
