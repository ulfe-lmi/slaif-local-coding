#!/usr/bin/env python3
"""Optional read-only SSH clock measurement; NEVER an inference tunnel."""
import argparse,json,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--host',required=True);p.add_argument('--out',required=True);a=p.parse_args()
if a.host.startswith('-'):raise SystemExit('invalid SSH destination')
rows=[]
for _ in range(7):
    t0=time.time_ns()
    x=subprocess.run(['ssh','-o','BatchMode=yes',a.host,'python3 -c "import time; print(time.time_ns())"'],text=True,capture_output=True,timeout=10,check=True)
    t1=time.time_ns();remote=int(x.stdout.strip());rows.append({'host_minus_vm_ns':remote-(t0+t1)//2,'uncertainty_ms':(t1-t0)/2e6})
best=min(rows,key=lambda x:x['uncertainty_ms']);out=Path(a.out)
if out.exists():raise SystemExit('output exists')
out.write_text(json.dumps({'best':best,'samples':rows,'note':'SSH only reads time; all inference stays on host LAN endpoints. Repeat after campaign to bound drift.'},indent=2)+'\n')
