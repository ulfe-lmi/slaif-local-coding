#!/usr/bin/env python3
"""Explicit VM-admin step. Changes ONLY generated secret-free adapter TOML ownership."""
import argparse,json,os,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--site',required=True);p.add_argument('--execute',action='store_true');a=p.parse_args()
c=json.loads(Path(a.site).read_text());root=Path(c['workspace_root']).resolve()
for case in sorted(root.glob('*/case.json')):
    if case.is_symlink(): raise SystemExit('symlink case refused')
    d=case.parent;f=d/'adapter.toml'
    if not f.exists(): continue
    if f.is_symlink() or not f.resolve().is_relative_to(root): raise SystemExit('unsafe config path')
    print(f'chown 10001:10001; chmod 0600: {f}')
    if a.execute:
        if os.geteuid()!=0: raise SystemExit('explicit admin execution required')
        os.chown(f,10001,10001);os.chmod(f,0o600)
