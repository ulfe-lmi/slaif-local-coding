#!/usr/bin/env python3
"""Validate all generated standalone configurations using the actual frozen product image.
No network, model calls, package installs, or product edits.
"""
import argparse,json,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from benchkit.common import read_json,validate_site,atomic_json
from benchkit.configurations import adapter_toml
p=argparse.ArgumentParser();p.add_argument('--site',required=True);p.add_argument('--out',required=True);a=p.parse_args()
s=read_json(a.site);validate_site(s);rows=[]
code='import sys,tempfile; from pathlib import Path; from slaif_local_coding.config import load_settings; f=tempfile.NamedTemporaryFile(mode="w",suffix=".toml",delete=False); f.write(sys.stdin.read()); f.close(); x=load_settings(Path(f.name)); print("VALID",x.gateway_ingress.mode,x.server.listen_host,x.upstream.base_url,x.compiler.enabled,x.constitution.enabled)'
for condition in ('VISION','CACHE','BOTH'):
    case={'condition':condition,'lane':0,'run_id':'config-check','task':'web'}
    cfg=adapter_toml(s,case)
    r=subprocess.run(['docker','run','--rm','-i','--network','none','--read-only','--tmpfs','/tmp:rw,size=16m',
        '--cap-drop','ALL','--security-opt','no-new-privileges','--entrypoint','/opt/slaif/venv/bin/python',
        s['product']['image'],'-c',code],input=cfg,text=True,capture_output=True)
    rows.append({'condition':condition,'valid':r.returncode==0,'summary':r.stdout.strip(),'returncode':r.returncode})
atomic_json(Path(a.out),{'validation':'actual_frozen_product_config_parser','cases':rows})
if not all(r['valid'] for r in rows):raise SystemExit(1)
