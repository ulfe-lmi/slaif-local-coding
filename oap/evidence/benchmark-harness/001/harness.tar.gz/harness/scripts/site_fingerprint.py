#!/usr/bin/env python3
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from benchkit.common import object_hash,read_json
print(object_hash(read_json(sys.argv[1])))
