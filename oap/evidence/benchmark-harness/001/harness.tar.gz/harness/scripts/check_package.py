#!/usr/bin/env python3
"""Verify archive file hashes and local Markdown links; never contacts a service."""
from pathlib import Path
import argparse,hashlib,json,re,sys
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--strict-parent',action='store_true');a=p.parse_args();root=a.root.resolve();errors=[]
manifest=root/'MANIFEST.sha256'
historical_manifest=root/'MANIFEST.pre-redaction.sha256'
identity=root/'KIT_IDENTITY.json'
if identity.is_file() and not a.strict_parent:
    record=json.loads(identity.read_text())
    parent=historical_manifest if historical_manifest.is_file() else manifest
    actual=hashlib.sha256(parent.read_bytes()).hexdigest() if parent.is_file() else None
    if actual!=record.get('parent_delivery_manifest_sha256'):errors.append('historical parent manifest identity mismatch')
if manifest.is_file():
    for row in manifest.read_text().splitlines():
        digest,rel=row.split('  ',1);target=root/rel
        if not target.resolve().is_relative_to(root):errors.append('manifest path escapes root');continue
        if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest()!=digest:errors.append('hash mismatch: '+rel)
else:errors.append('current MANIFEST.sha256 missing')
for file in root.rglob('*.md'):
    if any(x in file.relative_to(root).parts for x in ('.local','references','runs','.git')):continue
    fenced=False
    for line in file.read_text().splitlines():
        if line.lstrip().startswith('```'):fenced=not fenced;continue
        if fenced:continue
        for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)',line):
            url=link.split()[0].split('#',1)[0]
            if not url or re.match(r'^[a-zA-Z]+:',url):continue
            if not (file.parent/url).exists():errors.append(f'broken local link in {file.relative_to(root)}: {url}')
if errors:
    print('\n'.join(errors));raise SystemExit(1)
print('Current kit hashes, links, and declared historical parent-manifest identity verified.' if identity.is_file() and not a.strict_parent else 'Archive hashes and local Markdown file links verified.')
