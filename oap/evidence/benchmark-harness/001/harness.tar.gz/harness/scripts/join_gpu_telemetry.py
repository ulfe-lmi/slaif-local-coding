#!/usr/bin/env python3
"""Integrate GPU power only with a measured host/VM clock offset and bounded gaps."""
import argparse,json,statistics
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--telemetry',required=True);p.add_argument('--gpu-uuid',required=True)
p.add_argument('--host-minus-vm-ns',type=int,required=True);p.add_argument('--offset-uncertainty-ms',type=float,required=True)
p.add_argument('--max-gap-seconds',type=float,default=3);p.add_argument('--out',required=True);a=p.parse_args()
r=json.loads(Path(a.run).read_text());start=r['measurement_start_ns']+a.host_minus_vm_ns;end=r['measurement_end_ns']+a.host_minus_vm_ns
samples=[]
for line in Path(a.telemetry).open():
    x=json.loads(line)
    for g in x.get('gpu',{}).get('rows',[]):
        if g.get('uuid')==a.gpu_uuid:samples.append((x['unix_ns'],g))
samples.sort(key=lambda x:x[0]);inside=[g for t,g in samples if start<=t<=end]
energy=0.;coverage=0.;gaps=0
for (ta,ga),(tb,gb) in zip(samples,samples[1:]):
    left=max(start,ta);right=min(end,tb)
    if right<=left:continue
    pa,pb=ga.get('power.draw'),gb.get('power.draw')
    if not isinstance(pa,(int,float)) or not isinstance(pb,(int,float)) or (tb-ta)/1e9>a.max_gap_seconds:gaps+=1;continue
    pleft=pa+(pb-pa)*(left-ta)/(tb-ta);pright=pa+(pb-pa)*(right-ta)/(tb-ta)
    seconds=(right-left)/1e9;energy+=(pleft+pright)/2*seconds;coverage+=seconds
valid=a.offset_uncertainty_ms<=100 and coverage>=.99*(end-start)/1e9 and gaps==0
result={'gpu_uuid':a.gpu_uuid,'sample_count':len(inside),'offset_uncertainty_ms':a.offset_uncertainty_ms,
        'covered_seconds':coverage,'window_seconds':(end-start)/1e9,'unusable_intervals':gaps,
        'energy_joules':energy if valid else None,'energy_status':'integrated_gpu_device_energy' if valid else 'unavailable_insufficient_coverage_or_clock_alignment',
        'note':'Not server/VM energy; host CPU and other GPUs are not attributed to this run.'}
for name in ('utilization.gpu','memory.used','temperature.gpu','power.draw'):
    xs=[g[name] for g in inside if isinstance(g.get(name),(int,float))]
    result[name]={'mean':statistics.mean(xs) if xs else None,'max':max(xs) if xs else None}
out=Path(a.out)
if out.exists():raise SystemExit('output exists')
out.write_text(json.dumps(result,indent=2)+'\n')
